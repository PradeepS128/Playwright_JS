// ../../node_modules/.pnpm/svelte@4.2.7/node_modules/svelte/src/shared/version.js
var VERSION = "4.2.7";
var PUBLIC_VERSION = "4";

export {
  VERSION,
  PUBLIC_VERSION
};
//# sourceMappingURL=chunk-NPGCKOZ3.js.map
