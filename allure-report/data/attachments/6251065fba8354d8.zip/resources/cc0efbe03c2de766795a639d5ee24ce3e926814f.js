import * as universal from "/src/routes/reports/[reportId]/+page.ts";
export { universal };
export { default as component } from "/src/routes/reports/[reportId]/+page.svelte";