export const version = "1707111074259";
export let building = false;

export function set_building() {
	building = true;
}