import * as universal from "/src/routes/reports/+page.ts";
export { universal };
export { default as component } from "/src/routes/reports/+page.svelte";