export async function fetchReports() {
  const response = await fetch(`/api/report`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    }
  });
  const reportItems = await response.json();
  return reportItems.list;
}
export async function saveReportTitle(reportId, title, timestamp) {
  const response = await fetch("/api/report", {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      timestamp,
      reportId,
      title
    })
  });
  if (!response.ok) {
    throw new Error("Failed to update chat title");
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlcG9ydC1zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVwb3J0SXRlbSB9IGZyb20gJ3R5cGVzJztcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFJlcG9ydHMoKSB7XHJcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgL2FwaS9yZXBvcnRgLCB7XHJcbiAgICBtZXRob2Q6ICdHRVQnLFxyXG4gICAgaGVhZGVyczoge1xyXG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgfSxcclxuICB9KTtcclxuICBjb25zdCByZXBvcnRJdGVtcyA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICByZXR1cm4gcmVwb3J0SXRlbXMubGlzdCBhcyBSZXBvcnRJdGVtW107XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlUmVwb3J0VGl0bGUocmVwb3J0SWQ6IHN0cmluZywgdGl0bGU6IHN0cmluZywgdGltZXN0YW1wOiBudW1iZXIpIHtcclxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKCcvYXBpL3JlcG9ydCcsIHtcclxuICAgIG1ldGhvZDogJ1BBVENIJyxcclxuICAgIGhlYWRlcnM6IHtcclxuICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgIH0sXHJcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgIHRpbWVzdGFtcCxcclxuICAgICAgcmVwb3J0SWQsXHJcbiAgICAgIHRpdGxlLFxyXG4gICAgfSksXHJcbiAgfSk7XHJcblxyXG4gIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIHVwZGF0ZSBjaGF0IHRpdGxlJyk7XHJcbiAgfVxyXG59XHJcbiJdLCJtYXBwaW5ncyI6IkFBRUEsc0JBQXNCLGVBQWU7QUFDbkMsUUFBTSxXQUFXLE1BQU0sTUFBTSxlQUFlO0FBQUEsSUFDMUMsUUFBUTtBQUFBLElBQ1IsU0FBUztBQUFBLE1BQ1AsZ0JBQWdCO0FBQUEsSUFDbEI7QUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNLGNBQWMsTUFBTSxTQUFTLEtBQUs7QUFDeEMsU0FBTyxZQUFZO0FBQ3JCO0FBRUEsc0JBQXNCLGdCQUFnQixVQUFrQixPQUFlLFdBQW1CO0FBQ3hGLFFBQU0sV0FBVyxNQUFNLE1BQU0sZUFBZTtBQUFBLElBQzFDLFFBQVE7QUFBQSxJQUNSLFNBQVM7QUFBQSxNQUNQLGdCQUFnQjtBQUFBLElBQ2xCO0FBQUEsSUFDQSxNQUFNLEtBQUssVUFBVTtBQUFBLE1BQ25CO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILENBQUM7QUFFRCxNQUFJLENBQUMsU0FBUyxJQUFJO0FBQ2hCLFVBQU0sSUFBSSxNQUFNLDZCQUE2QjtBQUFBLEVBQy9DO0FBQ0Y7IiwibmFtZXMiOltdfQ==