import "/node_modules/.vite/deps/chunk-V3OIBNHJ.js?v=b331fb12";

// ../../node_modules/.pnpm/esm-env@1.0.0/node_modules/esm-env/dev-browser.js
var BROWSER = true;
var DEV = true;
export {
  BROWSER,
  DEV
};
//# sourceMappingURL=esm-env.js.map
