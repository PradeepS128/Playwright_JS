import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/C:/Users/Pradeep/Desktop/fibonalabs_app_pdf/packages/shared/src/lib/components/history/GenerateReport.svelte?svelte&type=style&lang.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Pradeep/Desktop/fibonalabs_app_pdf/packages/shared/src/lib/components/history/GenerateReport.svelte?svelte&type=style&lang.css"
const __vite__css = ".button-gradient-border.s--UauRdxYR9Kc>div.s--UauRdxYR9Kc{background-color:white;height:100%}.filter-radio.s--UauRdxYR9Kc.s--UauRdxYR9Kc:checked{background-color:white;background-image:url('/check-icon.svg');background-size:11px;border:2px solid #8155ff}.s--UauRdxYR9Kc.s--UauRdxYR9Kc{}"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))