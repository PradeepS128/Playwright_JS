import { makeApplyHmr } from "/@fs/C:/Users/Pradeep/Desktop/fibonalabs_app_pdf/node_modules/.pnpm/svelte-hmr@0.15.3_svelte@4.2.7/node_modules/svelte-hmr/runtime/index.js?v=b331fb12"

export const applyHmr = makeApplyHmr(args =>
  Object.assign({}, args, {
    hot: args.m.hot,
  })
)
