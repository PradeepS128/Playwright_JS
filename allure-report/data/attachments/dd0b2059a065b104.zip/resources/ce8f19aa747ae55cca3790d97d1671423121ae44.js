import {
  __commonJS,
  __require
} from "/node_modules/.vite/deps/chunk-V3OIBNHJ.js?v=b331fb12";

// ../../node_modules/.pnpm/punycode@1.4.1/node_modules/punycode/punycode.js
var require_punycode = __commonJS({
  "../../node_modules/.pnpm/punycode@1.4.1/node_modules/punycode/punycode.js"(exports, module) {
    (function(root) {
      var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
      var freeModule = typeof module == "object" && module && !module.nodeType && module;
      var freeGlobal = typeof global == "object" && global;
      if (freeGlobal.global === freeGlobal || freeGlobal.window === freeGlobal || freeGlobal.self === freeGlobal) {
        root = freeGlobal;
      }
      var punycode, maxInt = 2147483647, base = 36, tMin = 1, tMax = 26, skew = 38, damp = 700, initialBias = 72, initialN = 128, delimiter = "-", regexPunycode = /^xn--/, regexNonASCII = /[^\x20-\x7E]/, regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g, errors = {
        "overflow": "Overflow: input needs wider integers to process",
        "not-basic": "Illegal input >= 0x80 (not a basic code point)",
        "invalid-input": "Invalid input"
      }, baseMinusTMin = base - tMin, floor = Math.floor, stringFromCharCode = String.fromCharCode, key;
      function error(type) {
        throw new RangeError(errors[type]);
      }
      function map(array, fn) {
        var length = array.length;
        var result = [];
        while (length--) {
          result[length] = fn(array[length]);
        }
        return result;
      }
      function mapDomain(string, fn) {
        var parts = string.split("@");
        var result = "";
        if (parts.length > 1) {
          result = parts[0] + "@";
          string = parts[1];
        }
        string = string.replace(regexSeparators, ".");
        var labels = string.split(".");
        var encoded = map(labels, fn).join(".");
        return result + encoded;
      }
      function ucs2decode(string) {
        var output = [], counter = 0, length = string.length, value, extra;
        while (counter < length) {
          value = string.charCodeAt(counter++);
          if (value >= 55296 && value <= 56319 && counter < length) {
            extra = string.charCodeAt(counter++);
            if ((extra & 64512) == 56320) {
              output.push(((value & 1023) << 10) + (extra & 1023) + 65536);
            } else {
              output.push(value);
              counter--;
            }
          } else {
            output.push(value);
          }
        }
        return output;
      }
      function ucs2encode(array) {
        return map(array, function(value) {
          var output = "";
          if (value > 65535) {
            value -= 65536;
            output += stringFromCharCode(value >>> 10 & 1023 | 55296);
            value = 56320 | value & 1023;
          }
          output += stringFromCharCode(value);
          return output;
        }).join("");
      }
      function basicToDigit(codePoint) {
        if (codePoint - 48 < 10) {
          return codePoint - 22;
        }
        if (codePoint - 65 < 26) {
          return codePoint - 65;
        }
        if (codePoint - 97 < 26) {
          return codePoint - 97;
        }
        return base;
      }
      function digitToBasic(digit, flag) {
        return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
      }
      function adapt(delta, numPoints, firstTime) {
        var k = 0;
        delta = firstTime ? floor(delta / damp) : delta >> 1;
        delta += floor(delta / numPoints);
        for (; delta > baseMinusTMin * tMax >> 1; k += base) {
          delta = floor(delta / baseMinusTMin);
        }
        return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
      }
      function decode(input) {
        var output = [], inputLength = input.length, out, i = 0, n = initialN, bias = initialBias, basic, j, index, oldi, w, k, digit, t, baseMinusT;
        basic = input.lastIndexOf(delimiter);
        if (basic < 0) {
          basic = 0;
        }
        for (j = 0; j < basic; ++j) {
          if (input.charCodeAt(j) >= 128) {
            error("not-basic");
          }
          output.push(input.charCodeAt(j));
        }
        for (index = basic > 0 ? basic + 1 : 0; index < inputLength; ) {
          for (oldi = i, w = 1, k = base; ; k += base) {
            if (index >= inputLength) {
              error("invalid-input");
            }
            digit = basicToDigit(input.charCodeAt(index++));
            if (digit >= base || digit > floor((maxInt - i) / w)) {
              error("overflow");
            }
            i += digit * w;
            t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
            if (digit < t) {
              break;
            }
            baseMinusT = base - t;
            if (w > floor(maxInt / baseMinusT)) {
              error("overflow");
            }
            w *= baseMinusT;
          }
          out = output.length + 1;
          bias = adapt(i - oldi, out, oldi == 0);
          if (floor(i / out) > maxInt - n) {
            error("overflow");
          }
          n += floor(i / out);
          i %= out;
          output.splice(i++, 0, n);
        }
        return ucs2encode(output);
      }
      function encode(input) {
        var n, delta, handledCPCount, basicLength, bias, j, m, q, k, t, currentValue, output = [], inputLength, handledCPCountPlusOne, baseMinusT, qMinusT;
        input = ucs2decode(input);
        inputLength = input.length;
        n = initialN;
        delta = 0;
        bias = initialBias;
        for (j = 0; j < inputLength; ++j) {
          currentValue = input[j];
          if (currentValue < 128) {
            output.push(stringFromCharCode(currentValue));
          }
        }
        handledCPCount = basicLength = output.length;
        if (basicLength) {
          output.push(delimiter);
        }
        while (handledCPCount < inputLength) {
          for (m = maxInt, j = 0; j < inputLength; ++j) {
            currentValue = input[j];
            if (currentValue >= n && currentValue < m) {
              m = currentValue;
            }
          }
          handledCPCountPlusOne = handledCPCount + 1;
          if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
            error("overflow");
          }
          delta += (m - n) * handledCPCountPlusOne;
          n = m;
          for (j = 0; j < inputLength; ++j) {
            currentValue = input[j];
            if (currentValue < n && ++delta > maxInt) {
              error("overflow");
            }
            if (currentValue == n) {
              for (q = delta, k = base; ; k += base) {
                t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
                if (q < t) {
                  break;
                }
                qMinusT = q - t;
                baseMinusT = base - t;
                output.push(
                  stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0))
                );
                q = floor(qMinusT / baseMinusT);
              }
              output.push(stringFromCharCode(digitToBasic(q, 0)));
              bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
              delta = 0;
              ++handledCPCount;
            }
          }
          ++delta;
          ++n;
        }
        return output.join("");
      }
      function toUnicode(input) {
        return mapDomain(input, function(string) {
          return regexPunycode.test(string) ? decode(string.slice(4).toLowerCase()) : string;
        });
      }
      function toASCII(input) {
        return mapDomain(input, function(string) {
          return regexNonASCII.test(string) ? "xn--" + encode(string) : string;
        });
      }
      punycode = {
        /**
         * A string representing the current Punycode.js version number.
         * @memberOf punycode
         * @type String
         */
        "version": "1.4.1",
        /**
         * An object of methods to convert from JavaScript's internal character
         * representation (UCS-2) to Unicode code points, and back.
         * @see <https://mathiasbynens.be/notes/javascript-encoding>
         * @memberOf punycode
         * @type Object
         */
        "ucs2": {
          "decode": ucs2decode,
          "encode": ucs2encode
        },
        "decode": decode,
        "encode": encode,
        "toASCII": toASCII,
        "toUnicode": toUnicode
      };
      if (typeof define == "function" && typeof define.amd == "object" && define.amd) {
        define("punycode", function() {
          return punycode;
        });
      } else if (freeExports && freeModule) {
        if (module.exports == freeExports) {
          freeModule.exports = punycode;
        } else {
          for (key in punycode) {
            punycode.hasOwnProperty(key) && (freeExports[key] = punycode[key]);
          }
        }
      } else {
        root.punycode = punycode;
      }
    })(exports);
  }
});

// ../../node_modules/.pnpm/has-symbols@1.0.3/node_modules/has-symbols/shams.js
var require_shams = __commonJS({
  "../../node_modules/.pnpm/has-symbols@1.0.3/node_modules/has-symbols/shams.js"(exports, module) {
    "use strict";
    module.exports = function hasSymbols() {
      if (typeof Symbol !== "function" || typeof Object.getOwnPropertySymbols !== "function") {
        return false;
      }
      if (typeof Symbol.iterator === "symbol") {
        return true;
      }
      var obj = {};
      var sym = Symbol("test");
      var symObj = Object(sym);
      if (typeof sym === "string") {
        return false;
      }
      if (Object.prototype.toString.call(sym) !== "[object Symbol]") {
        return false;
      }
      if (Object.prototype.toString.call(symObj) !== "[object Symbol]") {
        return false;
      }
      var symVal = 42;
      obj[sym] = symVal;
      for (sym in obj) {
        return false;
      }
      if (typeof Object.keys === "function" && Object.keys(obj).length !== 0) {
        return false;
      }
      if (typeof Object.getOwnPropertyNames === "function" && Object.getOwnPropertyNames(obj).length !== 0) {
        return false;
      }
      var syms = Object.getOwnPropertySymbols(obj);
      if (syms.length !== 1 || syms[0] !== sym) {
        return false;
      }
      if (!Object.prototype.propertyIsEnumerable.call(obj, sym)) {
        return false;
      }
      if (typeof Object.getOwnPropertyDescriptor === "function") {
        var descriptor = Object.getOwnPropertyDescriptor(obj, sym);
        if (descriptor.value !== symVal || descriptor.enumerable !== true) {
          return false;
        }
      }
      return true;
    };
  }
});

// ../../node_modules/.pnpm/has-symbols@1.0.3/node_modules/has-symbols/index.js
var require_has_symbols = __commonJS({
  "../../node_modules/.pnpm/has-symbols@1.0.3/node_modules/has-symbols/index.js"(exports, module) {
    "use strict";
    var origSymbol = typeof Symbol !== "undefined" && Symbol;
    var hasSymbolSham = require_shams();
    module.exports = function hasNativeSymbols() {
      if (typeof origSymbol !== "function") {
        return false;
      }
      if (typeof Symbol !== "function") {
        return false;
      }
      if (typeof origSymbol("foo") !== "symbol") {
        return false;
      }
      if (typeof Symbol("bar") !== "symbol") {
        return false;
      }
      return hasSymbolSham();
    };
  }
});

// ../../node_modules/.pnpm/has-proto@1.0.1/node_modules/has-proto/index.js
var require_has_proto = __commonJS({
  "../../node_modules/.pnpm/has-proto@1.0.1/node_modules/has-proto/index.js"(exports, module) {
    "use strict";
    var test = {
      foo: {}
    };
    var $Object = Object;
    module.exports = function hasProto() {
      return { __proto__: test }.foo === test.foo && !({ __proto__: null } instanceof $Object);
    };
  }
});

// ../../node_modules/.pnpm/function-bind@1.1.2/node_modules/function-bind/implementation.js
var require_implementation = __commonJS({
  "../../node_modules/.pnpm/function-bind@1.1.2/node_modules/function-bind/implementation.js"(exports, module) {
    "use strict";
    var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
    var toStr = Object.prototype.toString;
    var max = Math.max;
    var funcType = "[object Function]";
    var concatty = function concatty2(a, b) {
      var arr = [];
      for (var i = 0; i < a.length; i += 1) {
        arr[i] = a[i];
      }
      for (var j = 0; j < b.length; j += 1) {
        arr[j + a.length] = b[j];
      }
      return arr;
    };
    var slicy = function slicy2(arrLike, offset) {
      var arr = [];
      for (var i = offset || 0, j = 0; i < arrLike.length; i += 1, j += 1) {
        arr[j] = arrLike[i];
      }
      return arr;
    };
    var joiny = function(arr, joiner) {
      var str = "";
      for (var i = 0; i < arr.length; i += 1) {
        str += arr[i];
        if (i + 1 < arr.length) {
          str += joiner;
        }
      }
      return str;
    };
    module.exports = function bind(that) {
      var target = this;
      if (typeof target !== "function" || toStr.apply(target) !== funcType) {
        throw new TypeError(ERROR_MESSAGE + target);
      }
      var args = slicy(arguments, 1);
      var bound;
      var binder = function() {
        if (this instanceof bound) {
          var result = target.apply(
            this,
            concatty(args, arguments)
          );
          if (Object(result) === result) {
            return result;
          }
          return this;
        }
        return target.apply(
          that,
          concatty(args, arguments)
        );
      };
      var boundLength = max(0, target.length - args.length);
      var boundArgs = [];
      for (var i = 0; i < boundLength; i++) {
        boundArgs[i] = "$" + i;
      }
      bound = Function("binder", "return function (" + joiny(boundArgs, ",") + "){ return binder.apply(this,arguments); }")(binder);
      if (target.prototype) {
        var Empty = function Empty2() {
        };
        Empty.prototype = target.prototype;
        bound.prototype = new Empty();
        Empty.prototype = null;
      }
      return bound;
    };
  }
});

// ../../node_modules/.pnpm/function-bind@1.1.2/node_modules/function-bind/index.js
var require_function_bind = __commonJS({
  "../../node_modules/.pnpm/function-bind@1.1.2/node_modules/function-bind/index.js"(exports, module) {
    "use strict";
    var implementation = require_implementation();
    module.exports = Function.prototype.bind || implementation;
  }
});

// ../../node_modules/.pnpm/hasown@2.0.0/node_modules/hasown/index.js
var require_hasown = __commonJS({
  "../../node_modules/.pnpm/hasown@2.0.0/node_modules/hasown/index.js"(exports, module) {
    "use strict";
    var call = Function.prototype.call;
    var $hasOwn = Object.prototype.hasOwnProperty;
    var bind = require_function_bind();
    module.exports = bind.call(call, $hasOwn);
  }
});

// ../../node_modules/.pnpm/get-intrinsic@1.2.2/node_modules/get-intrinsic/index.js
var require_get_intrinsic = __commonJS({
  "../../node_modules/.pnpm/get-intrinsic@1.2.2/node_modules/get-intrinsic/index.js"(exports, module) {
    "use strict";
    var undefined2;
    var $SyntaxError = SyntaxError;
    var $Function = Function;
    var $TypeError = TypeError;
    var getEvalledConstructor = function(expressionSyntax) {
      try {
        return $Function('"use strict"; return (' + expressionSyntax + ").constructor;")();
      } catch (e) {
      }
    };
    var $gOPD = Object.getOwnPropertyDescriptor;
    if ($gOPD) {
      try {
        $gOPD({}, "");
      } catch (e) {
        $gOPD = null;
      }
    }
    var throwTypeError = function() {
      throw new $TypeError();
    };
    var ThrowTypeError = $gOPD ? function() {
      try {
        arguments.callee;
        return throwTypeError;
      } catch (calleeThrows) {
        try {
          return $gOPD(arguments, "callee").get;
        } catch (gOPDthrows) {
          return throwTypeError;
        }
      }
    }() : throwTypeError;
    var hasSymbols = require_has_symbols()();
    var hasProto = require_has_proto()();
    var getProto = Object.getPrototypeOf || (hasProto ? function(x) {
      return x.__proto__;
    } : null);
    var needsEval = {};
    var TypedArray = typeof Uint8Array === "undefined" || !getProto ? undefined2 : getProto(Uint8Array);
    var INTRINSICS = {
      "%AggregateError%": typeof AggregateError === "undefined" ? undefined2 : AggregateError,
      "%Array%": Array,
      "%ArrayBuffer%": typeof ArrayBuffer === "undefined" ? undefined2 : ArrayBuffer,
      "%ArrayIteratorPrototype%": hasSymbols && getProto ? getProto([][Symbol.iterator]()) : undefined2,
      "%AsyncFromSyncIteratorPrototype%": undefined2,
      "%AsyncFunction%": needsEval,
      "%AsyncGenerator%": needsEval,
      "%AsyncGeneratorFunction%": needsEval,
      "%AsyncIteratorPrototype%": needsEval,
      "%Atomics%": typeof Atomics === "undefined" ? undefined2 : Atomics,
      "%BigInt%": typeof BigInt === "undefined" ? undefined2 : BigInt,
      "%BigInt64Array%": typeof BigInt64Array === "undefined" ? undefined2 : BigInt64Array,
      "%BigUint64Array%": typeof BigUint64Array === "undefined" ? undefined2 : BigUint64Array,
      "%Boolean%": Boolean,
      "%DataView%": typeof DataView === "undefined" ? undefined2 : DataView,
      "%Date%": Date,
      "%decodeURI%": decodeURI,
      "%decodeURIComponent%": decodeURIComponent,
      "%encodeURI%": encodeURI,
      "%encodeURIComponent%": encodeURIComponent,
      "%Error%": Error,
      "%eval%": eval,
      // eslint-disable-line no-eval
      "%EvalError%": EvalError,
      "%Float32Array%": typeof Float32Array === "undefined" ? undefined2 : Float32Array,
      "%Float64Array%": typeof Float64Array === "undefined" ? undefined2 : Float64Array,
      "%FinalizationRegistry%": typeof FinalizationRegistry === "undefined" ? undefined2 : FinalizationRegistry,
      "%Function%": $Function,
      "%GeneratorFunction%": needsEval,
      "%Int8Array%": typeof Int8Array === "undefined" ? undefined2 : Int8Array,
      "%Int16Array%": typeof Int16Array === "undefined" ? undefined2 : Int16Array,
      "%Int32Array%": typeof Int32Array === "undefined" ? undefined2 : Int32Array,
      "%isFinite%": isFinite,
      "%isNaN%": isNaN,
      "%IteratorPrototype%": hasSymbols && getProto ? getProto(getProto([][Symbol.iterator]())) : undefined2,
      "%JSON%": typeof JSON === "object" ? JSON : undefined2,
      "%Map%": typeof Map === "undefined" ? undefined2 : Map,
      "%MapIteratorPrototype%": typeof Map === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Map())[Symbol.iterator]()),
      "%Math%": Math,
      "%Number%": Number,
      "%Object%": Object,
      "%parseFloat%": parseFloat,
      "%parseInt%": parseInt,
      "%Promise%": typeof Promise === "undefined" ? undefined2 : Promise,
      "%Proxy%": typeof Proxy === "undefined" ? undefined2 : Proxy,
      "%RangeError%": RangeError,
      "%ReferenceError%": ReferenceError,
      "%Reflect%": typeof Reflect === "undefined" ? undefined2 : Reflect,
      "%RegExp%": RegExp,
      "%Set%": typeof Set === "undefined" ? undefined2 : Set,
      "%SetIteratorPrototype%": typeof Set === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Set())[Symbol.iterator]()),
      "%SharedArrayBuffer%": typeof SharedArrayBuffer === "undefined" ? undefined2 : SharedArrayBuffer,
      "%String%": String,
      "%StringIteratorPrototype%": hasSymbols && getProto ? getProto(""[Symbol.iterator]()) : undefined2,
      "%Symbol%": hasSymbols ? Symbol : undefined2,
      "%SyntaxError%": $SyntaxError,
      "%ThrowTypeError%": ThrowTypeError,
      "%TypedArray%": TypedArray,
      "%TypeError%": $TypeError,
      "%Uint8Array%": typeof Uint8Array === "undefined" ? undefined2 : Uint8Array,
      "%Uint8ClampedArray%": typeof Uint8ClampedArray === "undefined" ? undefined2 : Uint8ClampedArray,
      "%Uint16Array%": typeof Uint16Array === "undefined" ? undefined2 : Uint16Array,
      "%Uint32Array%": typeof Uint32Array === "undefined" ? undefined2 : Uint32Array,
      "%URIError%": URIError,
      "%WeakMap%": typeof WeakMap === "undefined" ? undefined2 : WeakMap,
      "%WeakRef%": typeof WeakRef === "undefined" ? undefined2 : WeakRef,
      "%WeakSet%": typeof WeakSet === "undefined" ? undefined2 : WeakSet
    };
    if (getProto) {
      try {
        null.error;
      } catch (e) {
        errorProto = getProto(getProto(e));
        INTRINSICS["%Error.prototype%"] = errorProto;
      }
    }
    var errorProto;
    var doEval = function doEval2(name) {
      var value;
      if (name === "%AsyncFunction%") {
        value = getEvalledConstructor("async function () {}");
      } else if (name === "%GeneratorFunction%") {
        value = getEvalledConstructor("function* () {}");
      } else if (name === "%AsyncGeneratorFunction%") {
        value = getEvalledConstructor("async function* () {}");
      } else if (name === "%AsyncGenerator%") {
        var fn = doEval2("%AsyncGeneratorFunction%");
        if (fn) {
          value = fn.prototype;
        }
      } else if (name === "%AsyncIteratorPrototype%") {
        var gen = doEval2("%AsyncGenerator%");
        if (gen && getProto) {
          value = getProto(gen.prototype);
        }
      }
      INTRINSICS[name] = value;
      return value;
    };
    var LEGACY_ALIASES = {
      "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
      "%ArrayPrototype%": ["Array", "prototype"],
      "%ArrayProto_entries%": ["Array", "prototype", "entries"],
      "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
      "%ArrayProto_keys%": ["Array", "prototype", "keys"],
      "%ArrayProto_values%": ["Array", "prototype", "values"],
      "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
      "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
      "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
      "%BooleanPrototype%": ["Boolean", "prototype"],
      "%DataViewPrototype%": ["DataView", "prototype"],
      "%DatePrototype%": ["Date", "prototype"],
      "%ErrorPrototype%": ["Error", "prototype"],
      "%EvalErrorPrototype%": ["EvalError", "prototype"],
      "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
      "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
      "%FunctionPrototype%": ["Function", "prototype"],
      "%Generator%": ["GeneratorFunction", "prototype"],
      "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
      "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
      "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
      "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
      "%JSONParse%": ["JSON", "parse"],
      "%JSONStringify%": ["JSON", "stringify"],
      "%MapPrototype%": ["Map", "prototype"],
      "%NumberPrototype%": ["Number", "prototype"],
      "%ObjectPrototype%": ["Object", "prototype"],
      "%ObjProto_toString%": ["Object", "prototype", "toString"],
      "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
      "%PromisePrototype%": ["Promise", "prototype"],
      "%PromiseProto_then%": ["Promise", "prototype", "then"],
      "%Promise_all%": ["Promise", "all"],
      "%Promise_reject%": ["Promise", "reject"],
      "%Promise_resolve%": ["Promise", "resolve"],
      "%RangeErrorPrototype%": ["RangeError", "prototype"],
      "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
      "%RegExpPrototype%": ["RegExp", "prototype"],
      "%SetPrototype%": ["Set", "prototype"],
      "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
      "%StringPrototype%": ["String", "prototype"],
      "%SymbolPrototype%": ["Symbol", "prototype"],
      "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
      "%TypedArrayPrototype%": ["TypedArray", "prototype"],
      "%TypeErrorPrototype%": ["TypeError", "prototype"],
      "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
      "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
      "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
      "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
      "%URIErrorPrototype%": ["URIError", "prototype"],
      "%WeakMapPrototype%": ["WeakMap", "prototype"],
      "%WeakSetPrototype%": ["WeakSet", "prototype"]
    };
    var bind = require_function_bind();
    var hasOwn = require_hasown();
    var $concat = bind.call(Function.call, Array.prototype.concat);
    var $spliceApply = bind.call(Function.apply, Array.prototype.splice);
    var $replace = bind.call(Function.call, String.prototype.replace);
    var $strSlice = bind.call(Function.call, String.prototype.slice);
    var $exec = bind.call(Function.call, RegExp.prototype.exec);
    var rePropName = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g;
    var reEscapeChar = /\\(\\)?/g;
    var stringToPath = function stringToPath2(string) {
      var first = $strSlice(string, 0, 1);
      var last = $strSlice(string, -1);
      if (first === "%" && last !== "%") {
        throw new $SyntaxError("invalid intrinsic syntax, expected closing `%`");
      } else if (last === "%" && first !== "%") {
        throw new $SyntaxError("invalid intrinsic syntax, expected opening `%`");
      }
      var result = [];
      $replace(string, rePropName, function(match, number, quote, subString) {
        result[result.length] = quote ? $replace(subString, reEscapeChar, "$1") : number || match;
      });
      return result;
    };
    var getBaseIntrinsic = function getBaseIntrinsic2(name, allowMissing) {
      var intrinsicName = name;
      var alias;
      if (hasOwn(LEGACY_ALIASES, intrinsicName)) {
        alias = LEGACY_ALIASES[intrinsicName];
        intrinsicName = "%" + alias[0] + "%";
      }
      if (hasOwn(INTRINSICS, intrinsicName)) {
        var value = INTRINSICS[intrinsicName];
        if (value === needsEval) {
          value = doEval(intrinsicName);
        }
        if (typeof value === "undefined" && !allowMissing) {
          throw new $TypeError("intrinsic " + name + " exists, but is not available. Please file an issue!");
        }
        return {
          alias,
          name: intrinsicName,
          value
        };
      }
      throw new $SyntaxError("intrinsic " + name + " does not exist!");
    };
    module.exports = function GetIntrinsic(name, allowMissing) {
      if (typeof name !== "string" || name.length === 0) {
        throw new $TypeError("intrinsic name must be a non-empty string");
      }
      if (arguments.length > 1 && typeof allowMissing !== "boolean") {
        throw new $TypeError('"allowMissing" argument must be a boolean');
      }
      if ($exec(/^%?[^%]*%?$/, name) === null) {
        throw new $SyntaxError("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
      }
      var parts = stringToPath(name);
      var intrinsicBaseName = parts.length > 0 ? parts[0] : "";
      var intrinsic = getBaseIntrinsic("%" + intrinsicBaseName + "%", allowMissing);
      var intrinsicRealName = intrinsic.name;
      var value = intrinsic.value;
      var skipFurtherCaching = false;
      var alias = intrinsic.alias;
      if (alias) {
        intrinsicBaseName = alias[0];
        $spliceApply(parts, $concat([0, 1], alias));
      }
      for (var i = 1, isOwn = true; i < parts.length; i += 1) {
        var part = parts[i];
        var first = $strSlice(part, 0, 1);
        var last = $strSlice(part, -1);
        if ((first === '"' || first === "'" || first === "`" || (last === '"' || last === "'" || last === "`")) && first !== last) {
          throw new $SyntaxError("property names with quotes must have matching quotes");
        }
        if (part === "constructor" || !isOwn) {
          skipFurtherCaching = true;
        }
        intrinsicBaseName += "." + part;
        intrinsicRealName = "%" + intrinsicBaseName + "%";
        if (hasOwn(INTRINSICS, intrinsicRealName)) {
          value = INTRINSICS[intrinsicRealName];
        } else if (value != null) {
          if (!(part in value)) {
            if (!allowMissing) {
              throw new $TypeError("base intrinsic for " + name + " exists, but the property is not available.");
            }
            return void 0;
          }
          if ($gOPD && i + 1 >= parts.length) {
            var desc = $gOPD(value, part);
            isOwn = !!desc;
            if (isOwn && "get" in desc && !("originalValue" in desc.get)) {
              value = desc.get;
            } else {
              value = value[part];
            }
          } else {
            isOwn = hasOwn(value, part);
            value = value[part];
          }
          if (isOwn && !skipFurtherCaching) {
            INTRINSICS[intrinsicRealName] = value;
          }
        }
      }
      return value;
    };
  }
});

// ../../node_modules/.pnpm/has-property-descriptors@1.0.1/node_modules/has-property-descriptors/index.js
var require_has_property_descriptors = __commonJS({
  "../../node_modules/.pnpm/has-property-descriptors@1.0.1/node_modules/has-property-descriptors/index.js"(exports, module) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var $defineProperty = GetIntrinsic("%Object.defineProperty%", true);
    var hasPropertyDescriptors = function hasPropertyDescriptors2() {
      if ($defineProperty) {
        try {
          $defineProperty({}, "a", { value: 1 });
          return true;
        } catch (e) {
          return false;
        }
      }
      return false;
    };
    hasPropertyDescriptors.hasArrayLengthDefineBug = function hasArrayLengthDefineBug() {
      if (!hasPropertyDescriptors()) {
        return null;
      }
      try {
        return $defineProperty([], "length", { value: 1 }).length !== 1;
      } catch (e) {
        return true;
      }
    };
    module.exports = hasPropertyDescriptors;
  }
});

// ../../node_modules/.pnpm/gopd@1.0.1/node_modules/gopd/index.js
var require_gopd = __commonJS({
  "../../node_modules/.pnpm/gopd@1.0.1/node_modules/gopd/index.js"(exports, module) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var $gOPD = GetIntrinsic("%Object.getOwnPropertyDescriptor%", true);
    if ($gOPD) {
      try {
        $gOPD([], "length");
      } catch (e) {
        $gOPD = null;
      }
    }
    module.exports = $gOPD;
  }
});

// ../../node_modules/.pnpm/define-data-property@1.1.1/node_modules/define-data-property/index.js
var require_define_data_property = __commonJS({
  "../../node_modules/.pnpm/define-data-property@1.1.1/node_modules/define-data-property/index.js"(exports, module) {
    "use strict";
    var hasPropertyDescriptors = require_has_property_descriptors()();
    var GetIntrinsic = require_get_intrinsic();
    var $defineProperty = hasPropertyDescriptors && GetIntrinsic("%Object.defineProperty%", true);
    if ($defineProperty) {
      try {
        $defineProperty({}, "a", { value: 1 });
      } catch (e) {
        $defineProperty = false;
      }
    }
    var $SyntaxError = GetIntrinsic("%SyntaxError%");
    var $TypeError = GetIntrinsic("%TypeError%");
    var gopd = require_gopd();
    module.exports = function defineDataProperty(obj, property, value) {
      if (!obj || typeof obj !== "object" && typeof obj !== "function") {
        throw new $TypeError("`obj` must be an object or a function`");
      }
      if (typeof property !== "string" && typeof property !== "symbol") {
        throw new $TypeError("`property` must be a string or a symbol`");
      }
      if (arguments.length > 3 && typeof arguments[3] !== "boolean" && arguments[3] !== null) {
        throw new $TypeError("`nonEnumerable`, if provided, must be a boolean or null");
      }
      if (arguments.length > 4 && typeof arguments[4] !== "boolean" && arguments[4] !== null) {
        throw new $TypeError("`nonWritable`, if provided, must be a boolean or null");
      }
      if (arguments.length > 5 && typeof arguments[5] !== "boolean" && arguments[5] !== null) {
        throw new $TypeError("`nonConfigurable`, if provided, must be a boolean or null");
      }
      if (arguments.length > 6 && typeof arguments[6] !== "boolean") {
        throw new $TypeError("`loose`, if provided, must be a boolean");
      }
      var nonEnumerable = arguments.length > 3 ? arguments[3] : null;
      var nonWritable = arguments.length > 4 ? arguments[4] : null;
      var nonConfigurable = arguments.length > 5 ? arguments[5] : null;
      var loose = arguments.length > 6 ? arguments[6] : false;
      var desc = !!gopd && gopd(obj, property);
      if ($defineProperty) {
        $defineProperty(obj, property, {
          configurable: nonConfigurable === null && desc ? desc.configurable : !nonConfigurable,
          enumerable: nonEnumerable === null && desc ? desc.enumerable : !nonEnumerable,
          value,
          writable: nonWritable === null && desc ? desc.writable : !nonWritable
        });
      } else if (loose || !nonEnumerable && !nonWritable && !nonConfigurable) {
        obj[property] = value;
      } else {
        throw new $SyntaxError("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.");
      }
    };
  }
});

// ../../node_modules/.pnpm/set-function-length@1.1.1/node_modules/set-function-length/index.js
var require_set_function_length = __commonJS({
  "../../node_modules/.pnpm/set-function-length@1.1.1/node_modules/set-function-length/index.js"(exports, module) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var define2 = require_define_data_property();
    var hasDescriptors = require_has_property_descriptors()();
    var gOPD = require_gopd();
    var $TypeError = GetIntrinsic("%TypeError%");
    var $floor = GetIntrinsic("%Math.floor%");
    module.exports = function setFunctionLength(fn, length) {
      if (typeof fn !== "function") {
        throw new $TypeError("`fn` is not a function");
      }
      if (typeof length !== "number" || length < 0 || length > 4294967295 || $floor(length) !== length) {
        throw new $TypeError("`length` must be a positive 32-bit integer");
      }
      var loose = arguments.length > 2 && !!arguments[2];
      var functionLengthIsConfigurable = true;
      var functionLengthIsWritable = true;
      if ("length" in fn && gOPD) {
        var desc = gOPD(fn, "length");
        if (desc && !desc.configurable) {
          functionLengthIsConfigurable = false;
        }
        if (desc && !desc.writable) {
          functionLengthIsWritable = false;
        }
      }
      if (functionLengthIsConfigurable || functionLengthIsWritable || !loose) {
        if (hasDescriptors) {
          define2(fn, "length", length, true, true);
        } else {
          define2(fn, "length", length);
        }
      }
      return fn;
    };
  }
});

// ../../node_modules/.pnpm/call-bind@1.0.5/node_modules/call-bind/index.js
var require_call_bind = __commonJS({
  "../../node_modules/.pnpm/call-bind@1.0.5/node_modules/call-bind/index.js"(exports, module) {
    "use strict";
    var bind = require_function_bind();
    var GetIntrinsic = require_get_intrinsic();
    var setFunctionLength = require_set_function_length();
    var $TypeError = GetIntrinsic("%TypeError%");
    var $apply = GetIntrinsic("%Function.prototype.apply%");
    var $call = GetIntrinsic("%Function.prototype.call%");
    var $reflectApply = GetIntrinsic("%Reflect.apply%", true) || bind.call($call, $apply);
    var $defineProperty = GetIntrinsic("%Object.defineProperty%", true);
    var $max = GetIntrinsic("%Math.max%");
    if ($defineProperty) {
      try {
        $defineProperty({}, "a", { value: 1 });
      } catch (e) {
        $defineProperty = null;
      }
    }
    module.exports = function callBind(originalFunction) {
      if (typeof originalFunction !== "function") {
        throw new $TypeError("a function is required");
      }
      var func = $reflectApply(bind, $call, arguments);
      return setFunctionLength(
        func,
        1 + $max(0, originalFunction.length - (arguments.length - 1)),
        true
      );
    };
    var applyBind = function applyBind2() {
      return $reflectApply(bind, $apply, arguments);
    };
    if ($defineProperty) {
      $defineProperty(module.exports, "apply", { value: applyBind });
    } else {
      module.exports.apply = applyBind;
    }
  }
});

// ../../node_modules/.pnpm/call-bind@1.0.5/node_modules/call-bind/callBound.js
var require_callBound = __commonJS({
  "../../node_modules/.pnpm/call-bind@1.0.5/node_modules/call-bind/callBound.js"(exports, module) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var callBind = require_call_bind();
    var $indexOf = callBind(GetIntrinsic("String.prototype.indexOf"));
    module.exports = function callBoundIntrinsic(name, allowMissing) {
      var intrinsic = GetIntrinsic(name, !!allowMissing);
      if (typeof intrinsic === "function" && $indexOf(name, ".prototype.") > -1) {
        return callBind(intrinsic);
      }
      return intrinsic;
    };
  }
});

// (disabled):../../node_modules/.pnpm/object-inspect@1.13.1/node_modules/object-inspect/util.inspect
var require_util = __commonJS({
  "(disabled):../../node_modules/.pnpm/object-inspect@1.13.1/node_modules/object-inspect/util.inspect"() {
  }
});

// ../../node_modules/.pnpm/object-inspect@1.13.1/node_modules/object-inspect/index.js
var require_object_inspect = __commonJS({
  "../../node_modules/.pnpm/object-inspect@1.13.1/node_modules/object-inspect/index.js"(exports, module) {
    var hasMap = typeof Map === "function" && Map.prototype;
    var mapSizeDescriptor = Object.getOwnPropertyDescriptor && hasMap ? Object.getOwnPropertyDescriptor(Map.prototype, "size") : null;
    var mapSize = hasMap && mapSizeDescriptor && typeof mapSizeDescriptor.get === "function" ? mapSizeDescriptor.get : null;
    var mapForEach = hasMap && Map.prototype.forEach;
    var hasSet = typeof Set === "function" && Set.prototype;
    var setSizeDescriptor = Object.getOwnPropertyDescriptor && hasSet ? Object.getOwnPropertyDescriptor(Set.prototype, "size") : null;
    var setSize = hasSet && setSizeDescriptor && typeof setSizeDescriptor.get === "function" ? setSizeDescriptor.get : null;
    var setForEach = hasSet && Set.prototype.forEach;
    var hasWeakMap = typeof WeakMap === "function" && WeakMap.prototype;
    var weakMapHas = hasWeakMap ? WeakMap.prototype.has : null;
    var hasWeakSet = typeof WeakSet === "function" && WeakSet.prototype;
    var weakSetHas = hasWeakSet ? WeakSet.prototype.has : null;
    var hasWeakRef = typeof WeakRef === "function" && WeakRef.prototype;
    var weakRefDeref = hasWeakRef ? WeakRef.prototype.deref : null;
    var booleanValueOf = Boolean.prototype.valueOf;
    var objectToString = Object.prototype.toString;
    var functionToString = Function.prototype.toString;
    var $match = String.prototype.match;
    var $slice = String.prototype.slice;
    var $replace = String.prototype.replace;
    var $toUpperCase = String.prototype.toUpperCase;
    var $toLowerCase = String.prototype.toLowerCase;
    var $test = RegExp.prototype.test;
    var $concat = Array.prototype.concat;
    var $join = Array.prototype.join;
    var $arrSlice = Array.prototype.slice;
    var $floor = Math.floor;
    var bigIntValueOf = typeof BigInt === "function" ? BigInt.prototype.valueOf : null;
    var gOPS = Object.getOwnPropertySymbols;
    var symToString = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? Symbol.prototype.toString : null;
    var hasShammedSymbols = typeof Symbol === "function" && typeof Symbol.iterator === "object";
    var toStringTag = typeof Symbol === "function" && Symbol.toStringTag && (typeof Symbol.toStringTag === hasShammedSymbols ? "object" : "symbol") ? Symbol.toStringTag : null;
    var isEnumerable = Object.prototype.propertyIsEnumerable;
    var gPO = (typeof Reflect === "function" ? Reflect.getPrototypeOf : Object.getPrototypeOf) || ([].__proto__ === Array.prototype ? function(O) {
      return O.__proto__;
    } : null);
    function addNumericSeparator(num, str) {
      if (num === Infinity || num === -Infinity || num !== num || num && num > -1e3 && num < 1e3 || $test.call(/e/, str)) {
        return str;
      }
      var sepRegex = /[0-9](?=(?:[0-9]{3})+(?![0-9]))/g;
      if (typeof num === "number") {
        var int = num < 0 ? -$floor(-num) : $floor(num);
        if (int !== num) {
          var intStr = String(int);
          var dec = $slice.call(str, intStr.length + 1);
          return $replace.call(intStr, sepRegex, "$&_") + "." + $replace.call($replace.call(dec, /([0-9]{3})/g, "$&_"), /_$/, "");
        }
      }
      return $replace.call(str, sepRegex, "$&_");
    }
    var utilInspect = require_util();
    var inspectCustom = utilInspect.custom;
    var inspectSymbol = isSymbol(inspectCustom) ? inspectCustom : null;
    module.exports = function inspect_(obj, options, depth, seen) {
      var opts = options || {};
      if (has(opts, "quoteStyle") && (opts.quoteStyle !== "single" && opts.quoteStyle !== "double")) {
        throw new TypeError('option "quoteStyle" must be "single" or "double"');
      }
      if (has(opts, "maxStringLength") && (typeof opts.maxStringLength === "number" ? opts.maxStringLength < 0 && opts.maxStringLength !== Infinity : opts.maxStringLength !== null)) {
        throw new TypeError('option "maxStringLength", if provided, must be a positive integer, Infinity, or `null`');
      }
      var customInspect = has(opts, "customInspect") ? opts.customInspect : true;
      if (typeof customInspect !== "boolean" && customInspect !== "symbol") {
        throw new TypeError("option \"customInspect\", if provided, must be `true`, `false`, or `'symbol'`");
      }
      if (has(opts, "indent") && opts.indent !== null && opts.indent !== "	" && !(parseInt(opts.indent, 10) === opts.indent && opts.indent > 0)) {
        throw new TypeError('option "indent" must be "\\t", an integer > 0, or `null`');
      }
      if (has(opts, "numericSeparator") && typeof opts.numericSeparator !== "boolean") {
        throw new TypeError('option "numericSeparator", if provided, must be `true` or `false`');
      }
      var numericSeparator = opts.numericSeparator;
      if (typeof obj === "undefined") {
        return "undefined";
      }
      if (obj === null) {
        return "null";
      }
      if (typeof obj === "boolean") {
        return obj ? "true" : "false";
      }
      if (typeof obj === "string") {
        return inspectString(obj, opts);
      }
      if (typeof obj === "number") {
        if (obj === 0) {
          return Infinity / obj > 0 ? "0" : "-0";
        }
        var str = String(obj);
        return numericSeparator ? addNumericSeparator(obj, str) : str;
      }
      if (typeof obj === "bigint") {
        var bigIntStr = String(obj) + "n";
        return numericSeparator ? addNumericSeparator(obj, bigIntStr) : bigIntStr;
      }
      var maxDepth = typeof opts.depth === "undefined" ? 5 : opts.depth;
      if (typeof depth === "undefined") {
        depth = 0;
      }
      if (depth >= maxDepth && maxDepth > 0 && typeof obj === "object") {
        return isArray(obj) ? "[Array]" : "[Object]";
      }
      var indent = getIndent(opts, depth);
      if (typeof seen === "undefined") {
        seen = [];
      } else if (indexOf(seen, obj) >= 0) {
        return "[Circular]";
      }
      function inspect(value, from, noIndent) {
        if (from) {
          seen = $arrSlice.call(seen);
          seen.push(from);
        }
        if (noIndent) {
          var newOpts = {
            depth: opts.depth
          };
          if (has(opts, "quoteStyle")) {
            newOpts.quoteStyle = opts.quoteStyle;
          }
          return inspect_(value, newOpts, depth + 1, seen);
        }
        return inspect_(value, opts, depth + 1, seen);
      }
      if (typeof obj === "function" && !isRegExp(obj)) {
        var name = nameOf(obj);
        var keys = arrObjKeys(obj, inspect);
        return "[Function" + (name ? ": " + name : " (anonymous)") + "]" + (keys.length > 0 ? " { " + $join.call(keys, ", ") + " }" : "");
      }
      if (isSymbol(obj)) {
        var symString = hasShammedSymbols ? $replace.call(String(obj), /^(Symbol\(.*\))_[^)]*$/, "$1") : symToString.call(obj);
        return typeof obj === "object" && !hasShammedSymbols ? markBoxed(symString) : symString;
      }
      if (isElement(obj)) {
        var s = "<" + $toLowerCase.call(String(obj.nodeName));
        var attrs = obj.attributes || [];
        for (var i = 0; i < attrs.length; i++) {
          s += " " + attrs[i].name + "=" + wrapQuotes(quote(attrs[i].value), "double", opts);
        }
        s += ">";
        if (obj.childNodes && obj.childNodes.length) {
          s += "...";
        }
        s += "</" + $toLowerCase.call(String(obj.nodeName)) + ">";
        return s;
      }
      if (isArray(obj)) {
        if (obj.length === 0) {
          return "[]";
        }
        var xs = arrObjKeys(obj, inspect);
        if (indent && !singleLineValues(xs)) {
          return "[" + indentedJoin(xs, indent) + "]";
        }
        return "[ " + $join.call(xs, ", ") + " ]";
      }
      if (isError(obj)) {
        var parts = arrObjKeys(obj, inspect);
        if (!("cause" in Error.prototype) && "cause" in obj && !isEnumerable.call(obj, "cause")) {
          return "{ [" + String(obj) + "] " + $join.call($concat.call("[cause]: " + inspect(obj.cause), parts), ", ") + " }";
        }
        if (parts.length === 0) {
          return "[" + String(obj) + "]";
        }
        return "{ [" + String(obj) + "] " + $join.call(parts, ", ") + " }";
      }
      if (typeof obj === "object" && customInspect) {
        if (inspectSymbol && typeof obj[inspectSymbol] === "function" && utilInspect) {
          return utilInspect(obj, { depth: maxDepth - depth });
        } else if (customInspect !== "symbol" && typeof obj.inspect === "function") {
          return obj.inspect();
        }
      }
      if (isMap(obj)) {
        var mapParts = [];
        if (mapForEach) {
          mapForEach.call(obj, function(value, key) {
            mapParts.push(inspect(key, obj, true) + " => " + inspect(value, obj));
          });
        }
        return collectionOf("Map", mapSize.call(obj), mapParts, indent);
      }
      if (isSet(obj)) {
        var setParts = [];
        if (setForEach) {
          setForEach.call(obj, function(value) {
            setParts.push(inspect(value, obj));
          });
        }
        return collectionOf("Set", setSize.call(obj), setParts, indent);
      }
      if (isWeakMap(obj)) {
        return weakCollectionOf("WeakMap");
      }
      if (isWeakSet(obj)) {
        return weakCollectionOf("WeakSet");
      }
      if (isWeakRef(obj)) {
        return weakCollectionOf("WeakRef");
      }
      if (isNumber(obj)) {
        return markBoxed(inspect(Number(obj)));
      }
      if (isBigInt(obj)) {
        return markBoxed(inspect(bigIntValueOf.call(obj)));
      }
      if (isBoolean(obj)) {
        return markBoxed(booleanValueOf.call(obj));
      }
      if (isString(obj)) {
        return markBoxed(inspect(String(obj)));
      }
      if (typeof window !== "undefined" && obj === window) {
        return "{ [object Window] }";
      }
      if (obj === global) {
        return "{ [object globalThis] }";
      }
      if (!isDate(obj) && !isRegExp(obj)) {
        var ys = arrObjKeys(obj, inspect);
        var isPlainObject = gPO ? gPO(obj) === Object.prototype : obj instanceof Object || obj.constructor === Object;
        var protoTag = obj instanceof Object ? "" : "null prototype";
        var stringTag = !isPlainObject && toStringTag && Object(obj) === obj && toStringTag in obj ? $slice.call(toStr(obj), 8, -1) : protoTag ? "Object" : "";
        var constructorTag = isPlainObject || typeof obj.constructor !== "function" ? "" : obj.constructor.name ? obj.constructor.name + " " : "";
        var tag = constructorTag + (stringTag || protoTag ? "[" + $join.call($concat.call([], stringTag || [], protoTag || []), ": ") + "] " : "");
        if (ys.length === 0) {
          return tag + "{}";
        }
        if (indent) {
          return tag + "{" + indentedJoin(ys, indent) + "}";
        }
        return tag + "{ " + $join.call(ys, ", ") + " }";
      }
      return String(obj);
    };
    function wrapQuotes(s, defaultStyle, opts) {
      var quoteChar = (opts.quoteStyle || defaultStyle) === "double" ? '"' : "'";
      return quoteChar + s + quoteChar;
    }
    function quote(s) {
      return $replace.call(String(s), /"/g, "&quot;");
    }
    function isArray(obj) {
      return toStr(obj) === "[object Array]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isDate(obj) {
      return toStr(obj) === "[object Date]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isRegExp(obj) {
      return toStr(obj) === "[object RegExp]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isError(obj) {
      return toStr(obj) === "[object Error]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isString(obj) {
      return toStr(obj) === "[object String]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isNumber(obj) {
      return toStr(obj) === "[object Number]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isBoolean(obj) {
      return toStr(obj) === "[object Boolean]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isSymbol(obj) {
      if (hasShammedSymbols) {
        return obj && typeof obj === "object" && obj instanceof Symbol;
      }
      if (typeof obj === "symbol") {
        return true;
      }
      if (!obj || typeof obj !== "object" || !symToString) {
        return false;
      }
      try {
        symToString.call(obj);
        return true;
      } catch (e) {
      }
      return false;
    }
    function isBigInt(obj) {
      if (!obj || typeof obj !== "object" || !bigIntValueOf) {
        return false;
      }
      try {
        bigIntValueOf.call(obj);
        return true;
      } catch (e) {
      }
      return false;
    }
    var hasOwn = Object.prototype.hasOwnProperty || function(key) {
      return key in this;
    };
    function has(obj, key) {
      return hasOwn.call(obj, key);
    }
    function toStr(obj) {
      return objectToString.call(obj);
    }
    function nameOf(f) {
      if (f.name) {
        return f.name;
      }
      var m = $match.call(functionToString.call(f), /^function\s*([\w$]+)/);
      if (m) {
        return m[1];
      }
      return null;
    }
    function indexOf(xs, x) {
      if (xs.indexOf) {
        return xs.indexOf(x);
      }
      for (var i = 0, l = xs.length; i < l; i++) {
        if (xs[i] === x) {
          return i;
        }
      }
      return -1;
    }
    function isMap(x) {
      if (!mapSize || !x || typeof x !== "object") {
        return false;
      }
      try {
        mapSize.call(x);
        try {
          setSize.call(x);
        } catch (s) {
          return true;
        }
        return x instanceof Map;
      } catch (e) {
      }
      return false;
    }
    function isWeakMap(x) {
      if (!weakMapHas || !x || typeof x !== "object") {
        return false;
      }
      try {
        weakMapHas.call(x, weakMapHas);
        try {
          weakSetHas.call(x, weakSetHas);
        } catch (s) {
          return true;
        }
        return x instanceof WeakMap;
      } catch (e) {
      }
      return false;
    }
    function isWeakRef(x) {
      if (!weakRefDeref || !x || typeof x !== "object") {
        return false;
      }
      try {
        weakRefDeref.call(x);
        return true;
      } catch (e) {
      }
      return false;
    }
    function isSet(x) {
      if (!setSize || !x || typeof x !== "object") {
        return false;
      }
      try {
        setSize.call(x);
        try {
          mapSize.call(x);
        } catch (m) {
          return true;
        }
        return x instanceof Set;
      } catch (e) {
      }
      return false;
    }
    function isWeakSet(x) {
      if (!weakSetHas || !x || typeof x !== "object") {
        return false;
      }
      try {
        weakSetHas.call(x, weakSetHas);
        try {
          weakMapHas.call(x, weakMapHas);
        } catch (s) {
          return true;
        }
        return x instanceof WeakSet;
      } catch (e) {
      }
      return false;
    }
    function isElement(x) {
      if (!x || typeof x !== "object") {
        return false;
      }
      if (typeof HTMLElement !== "undefined" && x instanceof HTMLElement) {
        return true;
      }
      return typeof x.nodeName === "string" && typeof x.getAttribute === "function";
    }
    function inspectString(str, opts) {
      if (str.length > opts.maxStringLength) {
        var remaining = str.length - opts.maxStringLength;
        var trailer = "... " + remaining + " more character" + (remaining > 1 ? "s" : "");
        return inspectString($slice.call(str, 0, opts.maxStringLength), opts) + trailer;
      }
      var s = $replace.call($replace.call(str, /(['\\])/g, "\\$1"), /[\x00-\x1f]/g, lowbyte);
      return wrapQuotes(s, "single", opts);
    }
    function lowbyte(c) {
      var n = c.charCodeAt(0);
      var x = {
        8: "b",
        9: "t",
        10: "n",
        12: "f",
        13: "r"
      }[n];
      if (x) {
        return "\\" + x;
      }
      return "\\x" + (n < 16 ? "0" : "") + $toUpperCase.call(n.toString(16));
    }
    function markBoxed(str) {
      return "Object(" + str + ")";
    }
    function weakCollectionOf(type) {
      return type + " { ? }";
    }
    function collectionOf(type, size, entries, indent) {
      var joinedEntries = indent ? indentedJoin(entries, indent) : $join.call(entries, ", ");
      return type + " (" + size + ") {" + joinedEntries + "}";
    }
    function singleLineValues(xs) {
      for (var i = 0; i < xs.length; i++) {
        if (indexOf(xs[i], "\n") >= 0) {
          return false;
        }
      }
      return true;
    }
    function getIndent(opts, depth) {
      var baseIndent;
      if (opts.indent === "	") {
        baseIndent = "	";
      } else if (typeof opts.indent === "number" && opts.indent > 0) {
        baseIndent = $join.call(Array(opts.indent + 1), " ");
      } else {
        return null;
      }
      return {
        base: baseIndent,
        prev: $join.call(Array(depth + 1), baseIndent)
      };
    }
    function indentedJoin(xs, indent) {
      if (xs.length === 0) {
        return "";
      }
      var lineJoiner = "\n" + indent.prev + indent.base;
      return lineJoiner + $join.call(xs, "," + lineJoiner) + "\n" + indent.prev;
    }
    function arrObjKeys(obj, inspect) {
      var isArr = isArray(obj);
      var xs = [];
      if (isArr) {
        xs.length = obj.length;
        for (var i = 0; i < obj.length; i++) {
          xs[i] = has(obj, i) ? inspect(obj[i], obj) : "";
        }
      }
      var syms = typeof gOPS === "function" ? gOPS(obj) : [];
      var symMap;
      if (hasShammedSymbols) {
        symMap = {};
        for (var k = 0; k < syms.length; k++) {
          symMap["$" + syms[k]] = syms[k];
        }
      }
      for (var key in obj) {
        if (!has(obj, key)) {
          continue;
        }
        if (isArr && String(Number(key)) === key && key < obj.length) {
          continue;
        }
        if (hasShammedSymbols && symMap["$" + key] instanceof Symbol) {
          continue;
        } else if ($test.call(/[^\w$]/, key)) {
          xs.push(inspect(key, obj) + ": " + inspect(obj[key], obj));
        } else {
          xs.push(key + ": " + inspect(obj[key], obj));
        }
      }
      if (typeof gOPS === "function") {
        for (var j = 0; j < syms.length; j++) {
          if (isEnumerable.call(obj, syms[j])) {
            xs.push("[" + inspect(syms[j]) + "]: " + inspect(obj[syms[j]], obj));
          }
        }
      }
      return xs;
    }
  }
});

// ../../node_modules/.pnpm/side-channel@1.0.4/node_modules/side-channel/index.js
var require_side_channel = __commonJS({
  "../../node_modules/.pnpm/side-channel@1.0.4/node_modules/side-channel/index.js"(exports, module) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var callBound = require_callBound();
    var inspect = require_object_inspect();
    var $TypeError = GetIntrinsic("%TypeError%");
    var $WeakMap = GetIntrinsic("%WeakMap%", true);
    var $Map = GetIntrinsic("%Map%", true);
    var $weakMapGet = callBound("WeakMap.prototype.get", true);
    var $weakMapSet = callBound("WeakMap.prototype.set", true);
    var $weakMapHas = callBound("WeakMap.prototype.has", true);
    var $mapGet = callBound("Map.prototype.get", true);
    var $mapSet = callBound("Map.prototype.set", true);
    var $mapHas = callBound("Map.prototype.has", true);
    var listGetNode = function(list, key) {
      for (var prev = list, curr; (curr = prev.next) !== null; prev = curr) {
        if (curr.key === key) {
          prev.next = curr.next;
          curr.next = list.next;
          list.next = curr;
          return curr;
        }
      }
    };
    var listGet = function(objects, key) {
      var node = listGetNode(objects, key);
      return node && node.value;
    };
    var listSet = function(objects, key, value) {
      var node = listGetNode(objects, key);
      if (node) {
        node.value = value;
      } else {
        objects.next = {
          // eslint-disable-line no-param-reassign
          key,
          next: objects.next,
          value
        };
      }
    };
    var listHas = function(objects, key) {
      return !!listGetNode(objects, key);
    };
    module.exports = function getSideChannel() {
      var $wm;
      var $m;
      var $o;
      var channel = {
        assert: function(key) {
          if (!channel.has(key)) {
            throw new $TypeError("Side channel does not contain " + inspect(key));
          }
        },
        get: function(key) {
          if ($WeakMap && key && (typeof key === "object" || typeof key === "function")) {
            if ($wm) {
              return $weakMapGet($wm, key);
            }
          } else if ($Map) {
            if ($m) {
              return $mapGet($m, key);
            }
          } else {
            if ($o) {
              return listGet($o, key);
            }
          }
        },
        has: function(key) {
          if ($WeakMap && key && (typeof key === "object" || typeof key === "function")) {
            if ($wm) {
              return $weakMapHas($wm, key);
            }
          } else if ($Map) {
            if ($m) {
              return $mapHas($m, key);
            }
          } else {
            if ($o) {
              return listHas($o, key);
            }
          }
          return false;
        },
        set: function(key, value) {
          if ($WeakMap && key && (typeof key === "object" || typeof key === "function")) {
            if (!$wm) {
              $wm = new $WeakMap();
            }
            $weakMapSet($wm, key, value);
          } else if ($Map) {
            if (!$m) {
              $m = new $Map();
            }
            $mapSet($m, key, value);
          } else {
            if (!$o) {
              $o = { key: {}, next: null };
            }
            listSet($o, key, value);
          }
        }
      };
      return channel;
    };
  }
});

// ../../node_modules/.pnpm/qs@6.11.2/node_modules/qs/lib/formats.js
var require_formats = __commonJS({
  "../../node_modules/.pnpm/qs@6.11.2/node_modules/qs/lib/formats.js"(exports, module) {
    "use strict";
    var replace = String.prototype.replace;
    var percentTwenties = /%20/g;
    var Format = {
      RFC1738: "RFC1738",
      RFC3986: "RFC3986"
    };
    module.exports = {
      "default": Format.RFC3986,
      formatters: {
        RFC1738: function(value) {
          return replace.call(value, percentTwenties, "+");
        },
        RFC3986: function(value) {
          return String(value);
        }
      },
      RFC1738: Format.RFC1738,
      RFC3986: Format.RFC3986
    };
  }
});

// ../../node_modules/.pnpm/qs@6.11.2/node_modules/qs/lib/utils.js
var require_utils = __commonJS({
  "../../node_modules/.pnpm/qs@6.11.2/node_modules/qs/lib/utils.js"(exports, module) {
    "use strict";
    var formats = require_formats();
    var has = Object.prototype.hasOwnProperty;
    var isArray = Array.isArray;
    var hexTable = function() {
      var array = [];
      for (var i = 0; i < 256; ++i) {
        array.push("%" + ((i < 16 ? "0" : "") + i.toString(16)).toUpperCase());
      }
      return array;
    }();
    var compactQueue = function compactQueue2(queue) {
      while (queue.length > 1) {
        var item = queue.pop();
        var obj = item.obj[item.prop];
        if (isArray(obj)) {
          var compacted = [];
          for (var j = 0; j < obj.length; ++j) {
            if (typeof obj[j] !== "undefined") {
              compacted.push(obj[j]);
            }
          }
          item.obj[item.prop] = compacted;
        }
      }
    };
    var arrayToObject = function arrayToObject2(source, options) {
      var obj = options && options.plainObjects ? /* @__PURE__ */ Object.create(null) : {};
      for (var i = 0; i < source.length; ++i) {
        if (typeof source[i] !== "undefined") {
          obj[i] = source[i];
        }
      }
      return obj;
    };
    var merge = function merge2(target, source, options) {
      if (!source) {
        return target;
      }
      if (typeof source !== "object") {
        if (isArray(target)) {
          target.push(source);
        } else if (target && typeof target === "object") {
          if (options && (options.plainObjects || options.allowPrototypes) || !has.call(Object.prototype, source)) {
            target[source] = true;
          }
        } else {
          return [target, source];
        }
        return target;
      }
      if (!target || typeof target !== "object") {
        return [target].concat(source);
      }
      var mergeTarget = target;
      if (isArray(target) && !isArray(source)) {
        mergeTarget = arrayToObject(target, options);
      }
      if (isArray(target) && isArray(source)) {
        source.forEach(function(item, i) {
          if (has.call(target, i)) {
            var targetItem = target[i];
            if (targetItem && typeof targetItem === "object" && item && typeof item === "object") {
              target[i] = merge2(targetItem, item, options);
            } else {
              target.push(item);
            }
          } else {
            target[i] = item;
          }
        });
        return target;
      }
      return Object.keys(source).reduce(function(acc, key) {
        var value = source[key];
        if (has.call(acc, key)) {
          acc[key] = merge2(acc[key], value, options);
        } else {
          acc[key] = value;
        }
        return acc;
      }, mergeTarget);
    };
    var assign = function assignSingleSource(target, source) {
      return Object.keys(source).reduce(function(acc, key) {
        acc[key] = source[key];
        return acc;
      }, target);
    };
    var decode = function(str, decoder, charset) {
      var strWithoutPlus = str.replace(/\+/g, " ");
      if (charset === "iso-8859-1") {
        return strWithoutPlus.replace(/%[0-9a-f]{2}/gi, unescape);
      }
      try {
        return decodeURIComponent(strWithoutPlus);
      } catch (e) {
        return strWithoutPlus;
      }
    };
    var encode = function encode2(str, defaultEncoder, charset, kind, format) {
      if (str.length === 0) {
        return str;
      }
      var string = str;
      if (typeof str === "symbol") {
        string = Symbol.prototype.toString.call(str);
      } else if (typeof str !== "string") {
        string = String(str);
      }
      if (charset === "iso-8859-1") {
        return escape(string).replace(/%u[0-9a-f]{4}/gi, function($0) {
          return "%26%23" + parseInt($0.slice(2), 16) + "%3B";
        });
      }
      var out = "";
      for (var i = 0; i < string.length; ++i) {
        var c = string.charCodeAt(i);
        if (c === 45 || c === 46 || c === 95 || c === 126 || c >= 48 && c <= 57 || c >= 65 && c <= 90 || c >= 97 && c <= 122 || format === formats.RFC1738 && (c === 40 || c === 41)) {
          out += string.charAt(i);
          continue;
        }
        if (c < 128) {
          out = out + hexTable[c];
          continue;
        }
        if (c < 2048) {
          out = out + (hexTable[192 | c >> 6] + hexTable[128 | c & 63]);
          continue;
        }
        if (c < 55296 || c >= 57344) {
          out = out + (hexTable[224 | c >> 12] + hexTable[128 | c >> 6 & 63] + hexTable[128 | c & 63]);
          continue;
        }
        i += 1;
        c = 65536 + ((c & 1023) << 10 | string.charCodeAt(i) & 1023);
        out += hexTable[240 | c >> 18] + hexTable[128 | c >> 12 & 63] + hexTable[128 | c >> 6 & 63] + hexTable[128 | c & 63];
      }
      return out;
    };
    var compact = function compact2(value) {
      var queue = [{ obj: { o: value }, prop: "o" }];
      var refs = [];
      for (var i = 0; i < queue.length; ++i) {
        var item = queue[i];
        var obj = item.obj[item.prop];
        var keys = Object.keys(obj);
        for (var j = 0; j < keys.length; ++j) {
          var key = keys[j];
          var val = obj[key];
          if (typeof val === "object" && val !== null && refs.indexOf(val) === -1) {
            queue.push({ obj, prop: key });
            refs.push(val);
          }
        }
      }
      compactQueue(queue);
      return value;
    };
    var isRegExp = function isRegExp2(obj) {
      return Object.prototype.toString.call(obj) === "[object RegExp]";
    };
    var isBuffer = function isBuffer2(obj) {
      if (!obj || typeof obj !== "object") {
        return false;
      }
      return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
    };
    var combine = function combine2(a, b) {
      return [].concat(a, b);
    };
    var maybeMap = function maybeMap2(val, fn) {
      if (isArray(val)) {
        var mapped = [];
        for (var i = 0; i < val.length; i += 1) {
          mapped.push(fn(val[i]));
        }
        return mapped;
      }
      return fn(val);
    };
    module.exports = {
      arrayToObject,
      assign,
      combine,
      compact,
      decode,
      encode,
      isBuffer,
      isRegExp,
      maybeMap,
      merge
    };
  }
});

// ../../node_modules/.pnpm/qs@6.11.2/node_modules/qs/lib/stringify.js
var require_stringify = __commonJS({
  "../../node_modules/.pnpm/qs@6.11.2/node_modules/qs/lib/stringify.js"(exports, module) {
    "use strict";
    var getSideChannel = require_side_channel();
    var utils = require_utils();
    var formats = require_formats();
    var has = Object.prototype.hasOwnProperty;
    var arrayPrefixGenerators = {
      brackets: function brackets(prefix) {
        return prefix + "[]";
      },
      comma: "comma",
      indices: function indices(prefix, key) {
        return prefix + "[" + key + "]";
      },
      repeat: function repeat(prefix) {
        return prefix;
      }
    };
    var isArray = Array.isArray;
    var push = Array.prototype.push;
    var pushToArray = function(arr, valueOrArray) {
      push.apply(arr, isArray(valueOrArray) ? valueOrArray : [valueOrArray]);
    };
    var toISO = Date.prototype.toISOString;
    var defaultFormat = formats["default"];
    var defaults = {
      addQueryPrefix: false,
      allowDots: false,
      charset: "utf-8",
      charsetSentinel: false,
      delimiter: "&",
      encode: true,
      encoder: utils.encode,
      encodeValuesOnly: false,
      format: defaultFormat,
      formatter: formats.formatters[defaultFormat],
      // deprecated
      indices: false,
      serializeDate: function serializeDate(date) {
        return toISO.call(date);
      },
      skipNulls: false,
      strictNullHandling: false
    };
    var isNonNullishPrimitive = function isNonNullishPrimitive2(v) {
      return typeof v === "string" || typeof v === "number" || typeof v === "boolean" || typeof v === "symbol" || typeof v === "bigint";
    };
    var sentinel = {};
    var stringify = function stringify2(object, prefix, generateArrayPrefix, commaRoundTrip, strictNullHandling, skipNulls, encoder, filter, sort, allowDots, serializeDate, format, formatter, encodeValuesOnly, charset, sideChannel) {
      var obj = object;
      var tmpSc = sideChannel;
      var step = 0;
      var findFlag = false;
      while ((tmpSc = tmpSc.get(sentinel)) !== void 0 && !findFlag) {
        var pos = tmpSc.get(object);
        step += 1;
        if (typeof pos !== "undefined") {
          if (pos === step) {
            throw new RangeError("Cyclic object value");
          } else {
            findFlag = true;
          }
        }
        if (typeof tmpSc.get(sentinel) === "undefined") {
          step = 0;
        }
      }
      if (typeof filter === "function") {
        obj = filter(prefix, obj);
      } else if (obj instanceof Date) {
        obj = serializeDate(obj);
      } else if (generateArrayPrefix === "comma" && isArray(obj)) {
        obj = utils.maybeMap(obj, function(value2) {
          if (value2 instanceof Date) {
            return serializeDate(value2);
          }
          return value2;
        });
      }
      if (obj === null) {
        if (strictNullHandling) {
          return encoder && !encodeValuesOnly ? encoder(prefix, defaults.encoder, charset, "key", format) : prefix;
        }
        obj = "";
      }
      if (isNonNullishPrimitive(obj) || utils.isBuffer(obj)) {
        if (encoder) {
          var keyValue = encodeValuesOnly ? prefix : encoder(prefix, defaults.encoder, charset, "key", format);
          return [formatter(keyValue) + "=" + formatter(encoder(obj, defaults.encoder, charset, "value", format))];
        }
        return [formatter(prefix) + "=" + formatter(String(obj))];
      }
      var values = [];
      if (typeof obj === "undefined") {
        return values;
      }
      var objKeys;
      if (generateArrayPrefix === "comma" && isArray(obj)) {
        if (encodeValuesOnly && encoder) {
          obj = utils.maybeMap(obj, encoder);
        }
        objKeys = [{ value: obj.length > 0 ? obj.join(",") || null : void 0 }];
      } else if (isArray(filter)) {
        objKeys = filter;
      } else {
        var keys = Object.keys(obj);
        objKeys = sort ? keys.sort(sort) : keys;
      }
      var adjustedPrefix = commaRoundTrip && isArray(obj) && obj.length === 1 ? prefix + "[]" : prefix;
      for (var j = 0; j < objKeys.length; ++j) {
        var key = objKeys[j];
        var value = typeof key === "object" && typeof key.value !== "undefined" ? key.value : obj[key];
        if (skipNulls && value === null) {
          continue;
        }
        var keyPrefix = isArray(obj) ? typeof generateArrayPrefix === "function" ? generateArrayPrefix(adjustedPrefix, key) : adjustedPrefix : adjustedPrefix + (allowDots ? "." + key : "[" + key + "]");
        sideChannel.set(object, step);
        var valueSideChannel = getSideChannel();
        valueSideChannel.set(sentinel, sideChannel);
        pushToArray(values, stringify2(
          value,
          keyPrefix,
          generateArrayPrefix,
          commaRoundTrip,
          strictNullHandling,
          skipNulls,
          generateArrayPrefix === "comma" && encodeValuesOnly && isArray(obj) ? null : encoder,
          filter,
          sort,
          allowDots,
          serializeDate,
          format,
          formatter,
          encodeValuesOnly,
          charset,
          valueSideChannel
        ));
      }
      return values;
    };
    var normalizeStringifyOptions = function normalizeStringifyOptions2(opts) {
      if (!opts) {
        return defaults;
      }
      if (opts.encoder !== null && typeof opts.encoder !== "undefined" && typeof opts.encoder !== "function") {
        throw new TypeError("Encoder has to be a function.");
      }
      var charset = opts.charset || defaults.charset;
      if (typeof opts.charset !== "undefined" && opts.charset !== "utf-8" && opts.charset !== "iso-8859-1") {
        throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
      }
      var format = formats["default"];
      if (typeof opts.format !== "undefined") {
        if (!has.call(formats.formatters, opts.format)) {
          throw new TypeError("Unknown format option provided.");
        }
        format = opts.format;
      }
      var formatter = formats.formatters[format];
      var filter = defaults.filter;
      if (typeof opts.filter === "function" || isArray(opts.filter)) {
        filter = opts.filter;
      }
      return {
        addQueryPrefix: typeof opts.addQueryPrefix === "boolean" ? opts.addQueryPrefix : defaults.addQueryPrefix,
        allowDots: typeof opts.allowDots === "undefined" ? defaults.allowDots : !!opts.allowDots,
        charset,
        charsetSentinel: typeof opts.charsetSentinel === "boolean" ? opts.charsetSentinel : defaults.charsetSentinel,
        delimiter: typeof opts.delimiter === "undefined" ? defaults.delimiter : opts.delimiter,
        encode: typeof opts.encode === "boolean" ? opts.encode : defaults.encode,
        encoder: typeof opts.encoder === "function" ? opts.encoder : defaults.encoder,
        encodeValuesOnly: typeof opts.encodeValuesOnly === "boolean" ? opts.encodeValuesOnly : defaults.encodeValuesOnly,
        filter,
        format,
        formatter,
        serializeDate: typeof opts.serializeDate === "function" ? opts.serializeDate : defaults.serializeDate,
        skipNulls: typeof opts.skipNulls === "boolean" ? opts.skipNulls : defaults.skipNulls,
        sort: typeof opts.sort === "function" ? opts.sort : null,
        strictNullHandling: typeof opts.strictNullHandling === "boolean" ? opts.strictNullHandling : defaults.strictNullHandling
      };
    };
    module.exports = function(object, opts) {
      var obj = object;
      var options = normalizeStringifyOptions(opts);
      var objKeys;
      var filter;
      if (typeof options.filter === "function") {
        filter = options.filter;
        obj = filter("", obj);
      } else if (isArray(options.filter)) {
        filter = options.filter;
        objKeys = filter;
      }
      var keys = [];
      if (typeof obj !== "object" || obj === null) {
        return "";
      }
      var arrayFormat;
      if (opts && opts.arrayFormat in arrayPrefixGenerators) {
        arrayFormat = opts.arrayFormat;
      } else if (opts && "indices" in opts) {
        arrayFormat = opts.indices ? "indices" : "repeat";
      } else {
        arrayFormat = "indices";
      }
      var generateArrayPrefix = arrayPrefixGenerators[arrayFormat];
      if (opts && "commaRoundTrip" in opts && typeof opts.commaRoundTrip !== "boolean") {
        throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
      }
      var commaRoundTrip = generateArrayPrefix === "comma" && opts && opts.commaRoundTrip;
      if (!objKeys) {
        objKeys = Object.keys(obj);
      }
      if (options.sort) {
        objKeys.sort(options.sort);
      }
      var sideChannel = getSideChannel();
      for (var i = 0; i < objKeys.length; ++i) {
        var key = objKeys[i];
        if (options.skipNulls && obj[key] === null) {
          continue;
        }
        pushToArray(keys, stringify(
          obj[key],
          key,
          generateArrayPrefix,
          commaRoundTrip,
          options.strictNullHandling,
          options.skipNulls,
          options.encode ? options.encoder : null,
          options.filter,
          options.sort,
          options.allowDots,
          options.serializeDate,
          options.format,
          options.formatter,
          options.encodeValuesOnly,
          options.charset,
          sideChannel
        ));
      }
      var joined = keys.join(options.delimiter);
      var prefix = options.addQueryPrefix === true ? "?" : "";
      if (options.charsetSentinel) {
        if (options.charset === "iso-8859-1") {
          prefix += "utf8=%26%2310003%3B&";
        } else {
          prefix += "utf8=%E2%9C%93&";
        }
      }
      return joined.length > 0 ? prefix + joined : "";
    };
  }
});

// ../../node_modules/.pnpm/qs@6.11.2/node_modules/qs/lib/parse.js
var require_parse = __commonJS({
  "../../node_modules/.pnpm/qs@6.11.2/node_modules/qs/lib/parse.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    var has = Object.prototype.hasOwnProperty;
    var isArray = Array.isArray;
    var defaults = {
      allowDots: false,
      allowPrototypes: false,
      allowSparse: false,
      arrayLimit: 20,
      charset: "utf-8",
      charsetSentinel: false,
      comma: false,
      decoder: utils.decode,
      delimiter: "&",
      depth: 5,
      ignoreQueryPrefix: false,
      interpretNumericEntities: false,
      parameterLimit: 1e3,
      parseArrays: true,
      plainObjects: false,
      strictNullHandling: false
    };
    var interpretNumericEntities = function(str) {
      return str.replace(/&#(\d+);/g, function($0, numberStr) {
        return String.fromCharCode(parseInt(numberStr, 10));
      });
    };
    var parseArrayValue = function(val, options) {
      if (val && typeof val === "string" && options.comma && val.indexOf(",") > -1) {
        return val.split(",");
      }
      return val;
    };
    var isoSentinel = "utf8=%26%2310003%3B";
    var charsetSentinel = "utf8=%E2%9C%93";
    var parseValues = function parseQueryStringValues(str, options) {
      var obj = { __proto__: null };
      var cleanStr = options.ignoreQueryPrefix ? str.replace(/^\?/, "") : str;
      var limit = options.parameterLimit === Infinity ? void 0 : options.parameterLimit;
      var parts = cleanStr.split(options.delimiter, limit);
      var skipIndex = -1;
      var i;
      var charset = options.charset;
      if (options.charsetSentinel) {
        for (i = 0; i < parts.length; ++i) {
          if (parts[i].indexOf("utf8=") === 0) {
            if (parts[i] === charsetSentinel) {
              charset = "utf-8";
            } else if (parts[i] === isoSentinel) {
              charset = "iso-8859-1";
            }
            skipIndex = i;
            i = parts.length;
          }
        }
      }
      for (i = 0; i < parts.length; ++i) {
        if (i === skipIndex) {
          continue;
        }
        var part = parts[i];
        var bracketEqualsPos = part.indexOf("]=");
        var pos = bracketEqualsPos === -1 ? part.indexOf("=") : bracketEqualsPos + 1;
        var key, val;
        if (pos === -1) {
          key = options.decoder(part, defaults.decoder, charset, "key");
          val = options.strictNullHandling ? null : "";
        } else {
          key = options.decoder(part.slice(0, pos), defaults.decoder, charset, "key");
          val = utils.maybeMap(
            parseArrayValue(part.slice(pos + 1), options),
            function(encodedVal) {
              return options.decoder(encodedVal, defaults.decoder, charset, "value");
            }
          );
        }
        if (val && options.interpretNumericEntities && charset === "iso-8859-1") {
          val = interpretNumericEntities(val);
        }
        if (part.indexOf("[]=") > -1) {
          val = isArray(val) ? [val] : val;
        }
        if (has.call(obj, key)) {
          obj[key] = utils.combine(obj[key], val);
        } else {
          obj[key] = val;
        }
      }
      return obj;
    };
    var parseObject = function(chain, val, options, valuesParsed) {
      var leaf = valuesParsed ? val : parseArrayValue(val, options);
      for (var i = chain.length - 1; i >= 0; --i) {
        var obj;
        var root = chain[i];
        if (root === "[]" && options.parseArrays) {
          obj = [].concat(leaf);
        } else {
          obj = options.plainObjects ? /* @__PURE__ */ Object.create(null) : {};
          var cleanRoot = root.charAt(0) === "[" && root.charAt(root.length - 1) === "]" ? root.slice(1, -1) : root;
          var index = parseInt(cleanRoot, 10);
          if (!options.parseArrays && cleanRoot === "") {
            obj = { 0: leaf };
          } else if (!isNaN(index) && root !== cleanRoot && String(index) === cleanRoot && index >= 0 && (options.parseArrays && index <= options.arrayLimit)) {
            obj = [];
            obj[index] = leaf;
          } else if (cleanRoot !== "__proto__") {
            obj[cleanRoot] = leaf;
          }
        }
        leaf = obj;
      }
      return leaf;
    };
    var parseKeys = function parseQueryStringKeys(givenKey, val, options, valuesParsed) {
      if (!givenKey) {
        return;
      }
      var key = options.allowDots ? givenKey.replace(/\.([^.[]+)/g, "[$1]") : givenKey;
      var brackets = /(\[[^[\]]*])/;
      var child = /(\[[^[\]]*])/g;
      var segment = options.depth > 0 && brackets.exec(key);
      var parent = segment ? key.slice(0, segment.index) : key;
      var keys = [];
      if (parent) {
        if (!options.plainObjects && has.call(Object.prototype, parent)) {
          if (!options.allowPrototypes) {
            return;
          }
        }
        keys.push(parent);
      }
      var i = 0;
      while (options.depth > 0 && (segment = child.exec(key)) !== null && i < options.depth) {
        i += 1;
        if (!options.plainObjects && has.call(Object.prototype, segment[1].slice(1, -1))) {
          if (!options.allowPrototypes) {
            return;
          }
        }
        keys.push(segment[1]);
      }
      if (segment) {
        keys.push("[" + key.slice(segment.index) + "]");
      }
      return parseObject(keys, val, options, valuesParsed);
    };
    var normalizeParseOptions = function normalizeParseOptions2(opts) {
      if (!opts) {
        return defaults;
      }
      if (opts.decoder !== null && opts.decoder !== void 0 && typeof opts.decoder !== "function") {
        throw new TypeError("Decoder has to be a function.");
      }
      if (typeof opts.charset !== "undefined" && opts.charset !== "utf-8" && opts.charset !== "iso-8859-1") {
        throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
      }
      var charset = typeof opts.charset === "undefined" ? defaults.charset : opts.charset;
      return {
        allowDots: typeof opts.allowDots === "undefined" ? defaults.allowDots : !!opts.allowDots,
        allowPrototypes: typeof opts.allowPrototypes === "boolean" ? opts.allowPrototypes : defaults.allowPrototypes,
        allowSparse: typeof opts.allowSparse === "boolean" ? opts.allowSparse : defaults.allowSparse,
        arrayLimit: typeof opts.arrayLimit === "number" ? opts.arrayLimit : defaults.arrayLimit,
        charset,
        charsetSentinel: typeof opts.charsetSentinel === "boolean" ? opts.charsetSentinel : defaults.charsetSentinel,
        comma: typeof opts.comma === "boolean" ? opts.comma : defaults.comma,
        decoder: typeof opts.decoder === "function" ? opts.decoder : defaults.decoder,
        delimiter: typeof opts.delimiter === "string" || utils.isRegExp(opts.delimiter) ? opts.delimiter : defaults.delimiter,
        // eslint-disable-next-line no-implicit-coercion, no-extra-parens
        depth: typeof opts.depth === "number" || opts.depth === false ? +opts.depth : defaults.depth,
        ignoreQueryPrefix: opts.ignoreQueryPrefix === true,
        interpretNumericEntities: typeof opts.interpretNumericEntities === "boolean" ? opts.interpretNumericEntities : defaults.interpretNumericEntities,
        parameterLimit: typeof opts.parameterLimit === "number" ? opts.parameterLimit : defaults.parameterLimit,
        parseArrays: opts.parseArrays !== false,
        plainObjects: typeof opts.plainObjects === "boolean" ? opts.plainObjects : defaults.plainObjects,
        strictNullHandling: typeof opts.strictNullHandling === "boolean" ? opts.strictNullHandling : defaults.strictNullHandling
      };
    };
    module.exports = function(str, opts) {
      var options = normalizeParseOptions(opts);
      if (str === "" || str === null || typeof str === "undefined") {
        return options.plainObjects ? /* @__PURE__ */ Object.create(null) : {};
      }
      var tempObj = typeof str === "string" ? parseValues(str, options) : str;
      var obj = options.plainObjects ? /* @__PURE__ */ Object.create(null) : {};
      var keys = Object.keys(tempObj);
      for (var i = 0; i < keys.length; ++i) {
        var key = keys[i];
        var newObj = parseKeys(key, tempObj[key], options, typeof str === "string");
        obj = utils.merge(obj, newObj, options);
      }
      if (options.allowSparse === true) {
        return obj;
      }
      return utils.compact(obj);
    };
  }
});

// ../../node_modules/.pnpm/qs@6.11.2/node_modules/qs/lib/index.js
var require_lib = __commonJS({
  "../../node_modules/.pnpm/qs@6.11.2/node_modules/qs/lib/index.js"(exports, module) {
    "use strict";
    var stringify = require_stringify();
    var parse = require_parse();
    var formats = require_formats();
    module.exports = {
      formats,
      parse,
      stringify
    };
  }
});

// ../../node_modules/.pnpm/url@0.11.3/node_modules/url/url.js
var require_url = __commonJS({
  "../../node_modules/.pnpm/url@0.11.3/node_modules/url/url.js"(exports) {
    "use strict";
    var punycode = require_punycode();
    function Url() {
      this.protocol = null;
      this.slashes = null;
      this.auth = null;
      this.host = null;
      this.port = null;
      this.hostname = null;
      this.hash = null;
      this.search = null;
      this.query = null;
      this.pathname = null;
      this.path = null;
      this.href = null;
    }
    var protocolPattern = /^([a-z0-9.+-]+:)/i;
    var portPattern = /:[0-9]*$/;
    var simplePathPattern = /^(\/\/?(?!\/)[^?\s]*)(\?[^\s]*)?$/;
    var delims = [
      "<",
      ">",
      '"',
      "`",
      " ",
      "\r",
      "\n",
      "	"
    ];
    var unwise = [
      "{",
      "}",
      "|",
      "\\",
      "^",
      "`"
    ].concat(delims);
    var autoEscape = ["'"].concat(unwise);
    var nonHostChars = [
      "%",
      "/",
      "?",
      ";",
      "#"
    ].concat(autoEscape);
    var hostEndingChars = [
      "/",
      "?",
      "#"
    ];
    var hostnameMaxLen = 255;
    var hostnamePartPattern = /^[+a-z0-9A-Z_-]{0,63}$/;
    var hostnamePartStart = /^([+a-z0-9A-Z_-]{0,63})(.*)$/;
    var unsafeProtocol = {
      javascript: true,
      "javascript:": true
    };
    var hostlessProtocol = {
      javascript: true,
      "javascript:": true
    };
    var slashedProtocol = {
      http: true,
      https: true,
      ftp: true,
      gopher: true,
      file: true,
      "http:": true,
      "https:": true,
      "ftp:": true,
      "gopher:": true,
      "file:": true
    };
    var querystring = require_lib();
    function urlParse(url, parseQueryString, slashesDenoteHost) {
      if (url && typeof url === "object" && url instanceof Url) {
        return url;
      }
      var u = new Url();
      u.parse(url, parseQueryString, slashesDenoteHost);
      return u;
    }
    Url.prototype.parse = function(url, parseQueryString, slashesDenoteHost) {
      if (typeof url !== "string") {
        throw new TypeError("Parameter 'url' must be a string, not " + typeof url);
      }
      var queryIndex = url.indexOf("?"), splitter = queryIndex !== -1 && queryIndex < url.indexOf("#") ? "?" : "#", uSplit = url.split(splitter), slashRegex = /\\/g;
      uSplit[0] = uSplit[0].replace(slashRegex, "/");
      url = uSplit.join(splitter);
      var rest = url;
      rest = rest.trim();
      if (!slashesDenoteHost && url.split("#").length === 1) {
        var simplePath = simplePathPattern.exec(rest);
        if (simplePath) {
          this.path = rest;
          this.href = rest;
          this.pathname = simplePath[1];
          if (simplePath[2]) {
            this.search = simplePath[2];
            if (parseQueryString) {
              this.query = querystring.parse(this.search.substr(1));
            } else {
              this.query = this.search.substr(1);
            }
          } else if (parseQueryString) {
            this.search = "";
            this.query = {};
          }
          return this;
        }
      }
      var proto = protocolPattern.exec(rest);
      if (proto) {
        proto = proto[0];
        var lowerProto = proto.toLowerCase();
        this.protocol = lowerProto;
        rest = rest.substr(proto.length);
      }
      if (slashesDenoteHost || proto || rest.match(/^\/\/[^@/]+@[^@/]+/)) {
        var slashes = rest.substr(0, 2) === "//";
        if (slashes && !(proto && hostlessProtocol[proto])) {
          rest = rest.substr(2);
          this.slashes = true;
        }
      }
      if (!hostlessProtocol[proto] && (slashes || proto && !slashedProtocol[proto])) {
        var hostEnd = -1;
        for (var i = 0; i < hostEndingChars.length; i++) {
          var hec = rest.indexOf(hostEndingChars[i]);
          if (hec !== -1 && (hostEnd === -1 || hec < hostEnd)) {
            hostEnd = hec;
          }
        }
        var auth, atSign;
        if (hostEnd === -1) {
          atSign = rest.lastIndexOf("@");
        } else {
          atSign = rest.lastIndexOf("@", hostEnd);
        }
        if (atSign !== -1) {
          auth = rest.slice(0, atSign);
          rest = rest.slice(atSign + 1);
          this.auth = decodeURIComponent(auth);
        }
        hostEnd = -1;
        for (var i = 0; i < nonHostChars.length; i++) {
          var hec = rest.indexOf(nonHostChars[i]);
          if (hec !== -1 && (hostEnd === -1 || hec < hostEnd)) {
            hostEnd = hec;
          }
        }
        if (hostEnd === -1) {
          hostEnd = rest.length;
        }
        this.host = rest.slice(0, hostEnd);
        rest = rest.slice(hostEnd);
        this.parseHost();
        this.hostname = this.hostname || "";
        var ipv6Hostname = this.hostname[0] === "[" && this.hostname[this.hostname.length - 1] === "]";
        if (!ipv6Hostname) {
          var hostparts = this.hostname.split(/\./);
          for (var i = 0, l = hostparts.length; i < l; i++) {
            var part = hostparts[i];
            if (!part) {
              continue;
            }
            if (!part.match(hostnamePartPattern)) {
              var newpart = "";
              for (var j = 0, k = part.length; j < k; j++) {
                if (part.charCodeAt(j) > 127) {
                  newpart += "x";
                } else {
                  newpart += part[j];
                }
              }
              if (!newpart.match(hostnamePartPattern)) {
                var validParts = hostparts.slice(0, i);
                var notHost = hostparts.slice(i + 1);
                var bit = part.match(hostnamePartStart);
                if (bit) {
                  validParts.push(bit[1]);
                  notHost.unshift(bit[2]);
                }
                if (notHost.length) {
                  rest = "/" + notHost.join(".") + rest;
                }
                this.hostname = validParts.join(".");
                break;
              }
            }
          }
        }
        if (this.hostname.length > hostnameMaxLen) {
          this.hostname = "";
        } else {
          this.hostname = this.hostname.toLowerCase();
        }
        if (!ipv6Hostname) {
          this.hostname = punycode.toASCII(this.hostname);
        }
        var p = this.port ? ":" + this.port : "";
        var h = this.hostname || "";
        this.host = h + p;
        this.href += this.host;
        if (ipv6Hostname) {
          this.hostname = this.hostname.substr(1, this.hostname.length - 2);
          if (rest[0] !== "/") {
            rest = "/" + rest;
          }
        }
      }
      if (!unsafeProtocol[lowerProto]) {
        for (var i = 0, l = autoEscape.length; i < l; i++) {
          var ae = autoEscape[i];
          if (rest.indexOf(ae) === -1) {
            continue;
          }
          var esc = encodeURIComponent(ae);
          if (esc === ae) {
            esc = escape(ae);
          }
          rest = rest.split(ae).join(esc);
        }
      }
      var hash = rest.indexOf("#");
      if (hash !== -1) {
        this.hash = rest.substr(hash);
        rest = rest.slice(0, hash);
      }
      var qm = rest.indexOf("?");
      if (qm !== -1) {
        this.search = rest.substr(qm);
        this.query = rest.substr(qm + 1);
        if (parseQueryString) {
          this.query = querystring.parse(this.query);
        }
        rest = rest.slice(0, qm);
      } else if (parseQueryString) {
        this.search = "";
        this.query = {};
      }
      if (rest) {
        this.pathname = rest;
      }
      if (slashedProtocol[lowerProto] && this.hostname && !this.pathname) {
        this.pathname = "/";
      }
      if (this.pathname || this.search) {
        var p = this.pathname || "";
        var s = this.search || "";
        this.path = p + s;
      }
      this.href = this.format();
      return this;
    };
    function urlFormat(obj) {
      if (typeof obj === "string") {
        obj = urlParse(obj);
      }
      if (!(obj instanceof Url)) {
        return Url.prototype.format.call(obj);
      }
      return obj.format();
    }
    Url.prototype.format = function() {
      var auth = this.auth || "";
      if (auth) {
        auth = encodeURIComponent(auth);
        auth = auth.replace(/%3A/i, ":");
        auth += "@";
      }
      var protocol = this.protocol || "", pathname = this.pathname || "", hash = this.hash || "", host = false, query = "";
      if (this.host) {
        host = auth + this.host;
      } else if (this.hostname) {
        host = auth + (this.hostname.indexOf(":") === -1 ? this.hostname : "[" + this.hostname + "]");
        if (this.port) {
          host += ":" + this.port;
        }
      }
      if (this.query && typeof this.query === "object" && Object.keys(this.query).length) {
        query = querystring.stringify(this.query, {
          arrayFormat: "repeat",
          addQueryPrefix: false
        });
      }
      var search = this.search || query && "?" + query || "";
      if (protocol && protocol.substr(-1) !== ":") {
        protocol += ":";
      }
      if (this.slashes || (!protocol || slashedProtocol[protocol]) && host !== false) {
        host = "//" + (host || "");
        if (pathname && pathname.charAt(0) !== "/") {
          pathname = "/" + pathname;
        }
      } else if (!host) {
        host = "";
      }
      if (hash && hash.charAt(0) !== "#") {
        hash = "#" + hash;
      }
      if (search && search.charAt(0) !== "?") {
        search = "?" + search;
      }
      pathname = pathname.replace(/[?#]/g, function(match) {
        return encodeURIComponent(match);
      });
      search = search.replace("#", "%23");
      return protocol + host + pathname + search + hash;
    };
    function urlResolve(source, relative) {
      return urlParse(source, false, true).resolve(relative);
    }
    Url.prototype.resolve = function(relative) {
      return this.resolveObject(urlParse(relative, false, true)).format();
    };
    function urlResolveObject(source, relative) {
      if (!source) {
        return relative;
      }
      return urlParse(source, false, true).resolveObject(relative);
    }
    Url.prototype.resolveObject = function(relative) {
      if (typeof relative === "string") {
        var rel = new Url();
        rel.parse(relative, false, true);
        relative = rel;
      }
      var result = new Url();
      var tkeys = Object.keys(this);
      for (var tk = 0; tk < tkeys.length; tk++) {
        var tkey = tkeys[tk];
        result[tkey] = this[tkey];
      }
      result.hash = relative.hash;
      if (relative.href === "") {
        result.href = result.format();
        return result;
      }
      if (relative.slashes && !relative.protocol) {
        var rkeys = Object.keys(relative);
        for (var rk = 0; rk < rkeys.length; rk++) {
          var rkey = rkeys[rk];
          if (rkey !== "protocol") {
            result[rkey] = relative[rkey];
          }
        }
        if (slashedProtocol[result.protocol] && result.hostname && !result.pathname) {
          result.pathname = "/";
          result.path = result.pathname;
        }
        result.href = result.format();
        return result;
      }
      if (relative.protocol && relative.protocol !== result.protocol) {
        if (!slashedProtocol[relative.protocol]) {
          var keys = Object.keys(relative);
          for (var v = 0; v < keys.length; v++) {
            var k = keys[v];
            result[k] = relative[k];
          }
          result.href = result.format();
          return result;
        }
        result.protocol = relative.protocol;
        if (!relative.host && !hostlessProtocol[relative.protocol]) {
          var relPath = (relative.pathname || "").split("/");
          while (relPath.length && !(relative.host = relPath.shift())) {
          }
          if (!relative.host) {
            relative.host = "";
          }
          if (!relative.hostname) {
            relative.hostname = "";
          }
          if (relPath[0] !== "") {
            relPath.unshift("");
          }
          if (relPath.length < 2) {
            relPath.unshift("");
          }
          result.pathname = relPath.join("/");
        } else {
          result.pathname = relative.pathname;
        }
        result.search = relative.search;
        result.query = relative.query;
        result.host = relative.host || "";
        result.auth = relative.auth;
        result.hostname = relative.hostname || relative.host;
        result.port = relative.port;
        if (result.pathname || result.search) {
          var p = result.pathname || "";
          var s = result.search || "";
          result.path = p + s;
        }
        result.slashes = result.slashes || relative.slashes;
        result.href = result.format();
        return result;
      }
      var isSourceAbs = result.pathname && result.pathname.charAt(0) === "/", isRelAbs = relative.host || relative.pathname && relative.pathname.charAt(0) === "/", mustEndAbs = isRelAbs || isSourceAbs || result.host && relative.pathname, removeAllDots = mustEndAbs, srcPath = result.pathname && result.pathname.split("/") || [], relPath = relative.pathname && relative.pathname.split("/") || [], psychotic = result.protocol && !slashedProtocol[result.protocol];
      if (psychotic) {
        result.hostname = "";
        result.port = null;
        if (result.host) {
          if (srcPath[0] === "") {
            srcPath[0] = result.host;
          } else {
            srcPath.unshift(result.host);
          }
        }
        result.host = "";
        if (relative.protocol) {
          relative.hostname = null;
          relative.port = null;
          if (relative.host) {
            if (relPath[0] === "") {
              relPath[0] = relative.host;
            } else {
              relPath.unshift(relative.host);
            }
          }
          relative.host = null;
        }
        mustEndAbs = mustEndAbs && (relPath[0] === "" || srcPath[0] === "");
      }
      if (isRelAbs) {
        result.host = relative.host || relative.host === "" ? relative.host : result.host;
        result.hostname = relative.hostname || relative.hostname === "" ? relative.hostname : result.hostname;
        result.search = relative.search;
        result.query = relative.query;
        srcPath = relPath;
      } else if (relPath.length) {
        if (!srcPath) {
          srcPath = [];
        }
        srcPath.pop();
        srcPath = srcPath.concat(relPath);
        result.search = relative.search;
        result.query = relative.query;
      } else if (relative.search != null) {
        if (psychotic) {
          result.host = srcPath.shift();
          result.hostname = result.host;
          var authInHost = result.host && result.host.indexOf("@") > 0 ? result.host.split("@") : false;
          if (authInHost) {
            result.auth = authInHost.shift();
            result.hostname = authInHost.shift();
            result.host = result.hostname;
          }
        }
        result.search = relative.search;
        result.query = relative.query;
        if (result.pathname !== null || result.search !== null) {
          result.path = (result.pathname ? result.pathname : "") + (result.search ? result.search : "");
        }
        result.href = result.format();
        return result;
      }
      if (!srcPath.length) {
        result.pathname = null;
        if (result.search) {
          result.path = "/" + result.search;
        } else {
          result.path = null;
        }
        result.href = result.format();
        return result;
      }
      var last = srcPath.slice(-1)[0];
      var hasTrailingSlash = (result.host || relative.host || srcPath.length > 1) && (last === "." || last === "..") || last === "";
      var up = 0;
      for (var i = srcPath.length; i >= 0; i--) {
        last = srcPath[i];
        if (last === ".") {
          srcPath.splice(i, 1);
        } else if (last === "..") {
          srcPath.splice(i, 1);
          up++;
        } else if (up) {
          srcPath.splice(i, 1);
          up--;
        }
      }
      if (!mustEndAbs && !removeAllDots) {
        for (; up--; up) {
          srcPath.unshift("..");
        }
      }
      if (mustEndAbs && srcPath[0] !== "" && (!srcPath[0] || srcPath[0].charAt(0) !== "/")) {
        srcPath.unshift("");
      }
      if (hasTrailingSlash && srcPath.join("/").substr(-1) !== "/") {
        srcPath.push("");
      }
      var isAbsolute = srcPath[0] === "" || srcPath[0] && srcPath[0].charAt(0) === "/";
      if (psychotic) {
        result.hostname = isAbsolute ? "" : srcPath.length ? srcPath.shift() : "";
        result.host = result.hostname;
        var authInHost = result.host && result.host.indexOf("@") > 0 ? result.host.split("@") : false;
        if (authInHost) {
          result.auth = authInHost.shift();
          result.hostname = authInHost.shift();
          result.host = result.hostname;
        }
      }
      mustEndAbs = mustEndAbs || result.host && srcPath.length;
      if (mustEndAbs && !isAbsolute) {
        srcPath.unshift("");
      }
      if (srcPath.length > 0) {
        result.pathname = srcPath.join("/");
      } else {
        result.pathname = null;
        result.path = null;
      }
      if (result.pathname !== null || result.search !== null) {
        result.path = (result.pathname ? result.pathname : "") + (result.search ? result.search : "");
      }
      result.auth = relative.auth || result.auth;
      result.slashes = result.slashes || relative.slashes;
      result.href = result.format();
      return result;
    };
    Url.prototype.parseHost = function() {
      var host = this.host;
      var port = portPattern.exec(host);
      if (port) {
        port = port[0];
        if (port !== ":") {
          this.port = port.substr(1);
        }
        host = host.substr(0, host.length - port.length);
      }
      if (host) {
        this.hostname = host;
      }
    };
    exports.parse = urlParse;
    exports.resolve = urlResolve;
    exports.resolveObject = urlResolveObject;
    exports.format = urlFormat;
    exports.Url = Url;
  }
});

// ../../node_modules/.pnpm/xmlserializer@0.6.1/node_modules/xmlserializer/xmlserializer.js
var require_xmlserializer = __commonJS({
  "../../node_modules/.pnpm/xmlserializer@0.6.1/node_modules/xmlserializer/xmlserializer.js"(exports, module) {
    (function(root, factory) {
      if (typeof define === "function" && define.amd) {
        define([], factory);
      } else if (typeof module === "object" && module.exports) {
        module.exports = factory();
      } else {
        root.xmlserializer = factory();
      }
    })(exports, function() {
      var removeInvalidCharacters = function(content) {
        return content.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, "");
      };
      var serializeAttributeValue = function(value) {
        return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
      };
      var serializeTextContent = function(content) {
        return content.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      };
      var serializeAttribute = function(attr) {
        var value = attr.value;
        return " " + attr.name + '="' + serializeAttributeValue(value) + '"';
      };
      var getTagName = function(node) {
        var tagName = node.tagName;
        if (node.namespaceURI === "http://www.w3.org/1999/xhtml") {
          tagName = tagName.toLowerCase();
        }
        return tagName;
      };
      var serializeNamespace = function(node, isRootNode) {
        var nodeHasXmlnsAttr = Array.prototype.map.call(node.attributes || node.attrs, function(attr) {
          return attr.name;
        }).indexOf("xmlns") >= 0;
        if (!nodeHasXmlnsAttr && (isRootNode || node.namespaceURI !== node.parentNode.namespaceURI)) {
          return ' xmlns="' + node.namespaceURI + '"';
        } else {
          return "";
        }
      };
      var serializeChildren = function(node) {
        return Array.prototype.map.call(node.childNodes, function(childNode) {
          return nodeTreeToXHTML(childNode);
        }).join("");
      };
      var serializeTag = function(node, isRootNode) {
        var output = "<" + getTagName(node);
        output += serializeNamespace(node, isRootNode);
        Array.prototype.forEach.call(node.attributes || node.attrs, function(attr) {
          output += serializeAttribute(attr);
        });
        if (node.childNodes.length > 0) {
          output += ">";
          output += serializeChildren(node);
          output += "</" + getTagName(node) + ">";
        } else {
          output += "/>";
        }
        return output;
      };
      var serializeText = function(node) {
        var text = node.nodeValue || node.value || "";
        return serializeTextContent(text);
      };
      var serializeComment = function(node) {
        return "<!--" + node.data.replace(/-/g, "&#45;") + "-->";
      };
      var serializeCDATA = function(node) {
        return "<![CDATA[" + node.nodeValue + "]]>";
      };
      var nodeTreeToXHTML = function(node, options) {
        var isRootNode = options && options.rootNode;
        if (node.nodeName === "#document" || node.nodeName === "#document-fragment") {
          return serializeChildren(node);
        } else {
          if (node.tagName) {
            return serializeTag(node, isRootNode);
          } else if (node.nodeName === "#text") {
            return serializeText(node);
          } else if (node.nodeName === "#comment") {
            return serializeComment(node);
          } else if (node.nodeName === "#cdata-section") {
            return serializeCDATA(node);
          }
        }
      };
      return {
        serializeToString: function(node) {
          return removeInvalidCharacters(nodeTreeToXHTML(node, { rootNode: true }));
        }
      };
    });
  }
});

// ../../node_modules/.pnpm/sane-domparser-error@0.2.0/node_modules/sane-domparser-error/index.js
var require_sane_domparser_error = __commonJS({
  "../../node_modules/.pnpm/sane-domparser-error@0.2.0/node_modules/sane-domparser-error/index.js"(exports) {
    "use strict";
    var innerXML = function(node) {
      var s = new XMLSerializer();
      return Array.prototype.map.call(node.childNodes, function(node2) {
        return s.serializeToString(node2);
      }).join("");
    };
    var getParseError = function(doc) {
      if (doc.documentElement.tagName === "parsererror" && doc.documentElement.namespaceURI === "http://www.mozilla.org/newlayout/xml/parsererror.xml") {
        return doc.documentElement;
      }
      if ((doc.documentElement.tagName === "xml" || doc.documentElement.tagName === "html") && doc.documentElement.childNodes && doc.documentElement.childNodes.length > 0 && doc.documentElement.childNodes[0].nodeName === "parsererror") {
        return doc.documentElement.childNodes[0];
      }
      if (doc.documentElement.tagName === "html" && doc.documentElement.childNodes && doc.documentElement.childNodes.length > 0 && doc.documentElement.childNodes[0].nodeName === "body" && doc.documentElement.childNodes[0].childNodes && doc.documentElement.childNodes[0].childNodes.length && doc.documentElement.childNodes[0].childNodes[0].nodeName === "parsererror") {
        return doc.documentElement.childNodes[0].childNodes[0];
      }
      return void 0;
    };
    var errorMessagePatterns = [
      // Chrome, Safari, PhantomJS
      new RegExp("^<h3[^>]*>This page contains the following errors:</h3><div[^>]*>(.+?)\n?</div>"),
      // Firefox
      new RegExp("^(.+)\n")
    ];
    var extractParseError = function(errorNode) {
      var content = innerXML(errorNode);
      var i, match;
      for (i = 0; i < errorMessagePatterns.length; i++) {
        match = errorMessagePatterns[i].exec(content);
        if (match) {
          return match[1];
        }
      }
      return void 0;
    };
    var failOnParseError = function(doc) {
      var errorMessage;
      if (doc === null) {
        throw new Error("Parse error");
      }
      var parseError = getParseError(doc);
      if (parseError !== void 0) {
        errorMessage = extractParseError(parseError) || "Parse error";
        throw new Error(errorMessage);
      }
    };
    exports.failOnParseError = function(doc) {
      failOnParseError(doc);
      return doc;
    };
  }
});

// ../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/util.js
var require_util2 = __commonJS({
  "../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/util.js"(exports) {
    "use strict";
    var url = require_url();
    exports.getDocumentBaseUrl = function(doc) {
      if (doc.baseURI !== "about:blank") {
        return doc.baseURI;
      }
      return null;
    };
    exports.clone = function(object) {
      var theClone = {}, i;
      for (i in object) {
        if (object.hasOwnProperty(i)) {
          theClone[i] = object[i];
        }
      }
      return theClone;
    };
    exports.cloneArray = function(nodeList) {
      return Array.prototype.slice.apply(nodeList, [0]);
    };
    exports.joinUrl = function(baseUrl, relUrl) {
      if (!baseUrl) {
        return relUrl;
      }
      return url.resolve(baseUrl, relUrl);
    };
    exports.isDataUri = function(url2) {
      return /^data:/.test(url2);
    };
    exports.collectAndReportErrors = function(promises) {
      var errors = [];
      return Promise.all(
        promises.map(function(promise) {
          return promise.catch(function(e) {
            errors.push(e);
          });
        })
      ).then(function() {
        return errors;
      });
    };
    var lastCacheDate = null;
    var getUncachableURL = function(url2, cache) {
      if (cache === false || cache === "none" || cache === "repeated") {
        if (lastCacheDate === null || cache !== "repeated") {
          lastCacheDate = Date.now();
        }
        return url2 + "?_=" + lastCacheDate;
      } else {
        return url2;
      }
    };
    exports.ajax = function(url2, options) {
      return new Promise(function(resolve, reject) {
        var ajaxRequest = new window.XMLHttpRequest(), joinedUrl = exports.joinUrl(options.baseUrl, url2), augmentedUrl;
        var doReject = function() {
          reject({
            msg: "Unable to load url",
            url: joinedUrl
          });
        };
        augmentedUrl = getUncachableURL(joinedUrl, options.cache);
        ajaxRequest.addEventListener(
          "load",
          function() {
            if (ajaxRequest.status === 200 || ajaxRequest.status === 0) {
              resolve(ajaxRequest.response);
            } else {
              doReject();
            }
          },
          false
        );
        ajaxRequest.addEventListener("error", doReject, false);
        try {
          ajaxRequest.open("GET", augmentedUrl, true);
          ajaxRequest.overrideMimeType(options.mimeType);
          ajaxRequest.send(null);
        } catch (e) {
          doReject();
        }
      });
    };
    exports.binaryAjax = function(url2, options) {
      var ajaxOptions = exports.clone(options);
      ajaxOptions.mimeType = "text/plain; charset=x-user-defined";
      return exports.ajax(url2, ajaxOptions).then(function(content) {
        var binaryContent = "";
        for (var i = 0; i < content.length; i++) {
          binaryContent += String.fromCharCode(content.charCodeAt(i) & 255);
        }
        return binaryContent;
      });
    };
    var detectMimeType = function(content) {
      var startsWith = function(string, substring) {
        return string.substring(0, substring.length) === substring;
      };
      if (startsWith(content, "<?xml") || startsWith(content, "<svg")) {
        return "image/svg+xml";
      }
      return "image/png";
    };
    exports.getDataURIForImageURL = function(url2, options) {
      return exports.binaryAjax(url2, options).then(function(content) {
        var base64Content = btoa(content), mimeType = detectMimeType(content);
        return "data:" + mimeType + ";base64," + base64Content;
      });
    };
    var uniqueIdList = [];
    var constantUniqueIdFor = function(element) {
      if (uniqueIdList.indexOf(element) < 0) {
        uniqueIdList.push(element);
      }
      return uniqueIdList.indexOf(element);
    };
    exports.memoize = function(func, hasher, memo) {
      if (typeof memo !== "object") {
        throw new Error("cacheBucket is not an object");
      }
      return function() {
        var args = Array.prototype.slice.call(arguments);
        var argumentHash = hasher(args), funcHash = constantUniqueIdFor(func), retValue;
        if (memo[funcHash] && memo[funcHash][argumentHash]) {
          return memo[funcHash][argumentHash];
        } else {
          retValue = func.apply(null, args);
          memo[funcHash] = memo[funcHash] || {};
          memo[funcHash][argumentHash] = retValue;
          return retValue;
        }
      };
    };
  }
});

// ../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/inlineImage.js
var require_inlineImage = __commonJS({
  "../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/inlineImage.js"(exports) {
    "use strict";
    var util = require_util2();
    var encodeImageAsDataURI = function(image, options) {
      var url = null;
      if (image.hasAttribute("src")) {
        url = image.getAttribute("src");
      } else if (image.hasAttributeNS("http://www.w3.org/1999/xlink", "href")) {
        url = image.getAttributeNS("http://www.w3.org/1999/xlink", "href");
      } else if (image.hasAttribute("href")) {
        url = image.getAttribute("href");
      }
      var documentBase = util.getDocumentBaseUrl(image.ownerDocument), ajaxOptions = util.clone(options);
      if (!ajaxOptions.baseUrl && documentBase) {
        ajaxOptions.baseUrl = documentBase;
      }
      return util.getDataURIForImageURL(url, ajaxOptions).then(
        function(dataURI) {
          return dataURI;
        },
        function(e) {
          throw {
            resourceType: "image",
            url: e.url,
            msg: "Unable to load image " + e.url
          };
        }
      );
    };
    var filterExternalImages = function(images) {
      return images.filter(function(image) {
        var url = null;
        if (image.hasAttribute("src")) {
          url = image.getAttribute("src");
        } else if (image.hasAttributeNS("http://www.w3.org/1999/xlink", "href")) {
          url = image.getAttributeNS("http://www.w3.org/1999/xlink", "href");
        } else if (image.hasAttribute("href")) {
          url = image.getAttribute("href");
        }
        return url !== null && !util.isDataUri(url);
      });
    };
    var filterInputsForImageType = function(inputs) {
      return Array.prototype.filter.call(inputs, function(input) {
        return input.type === "image";
      });
    };
    var toArray = function(arrayLike) {
      return Array.prototype.slice.call(arrayLike);
    };
    exports.inline = function(doc, options) {
      var images = toArray(doc.getElementsByTagName("img")), svgImages = toArray(doc.getElementsByTagName("image")), imageInputs = filterInputsForImageType(doc.getElementsByTagName("input"));
      images = images.concat(svgImages);
      images = images.concat(imageInputs);
      var externalImages = filterExternalImages(images);
      return util.collectAndReportErrors(
        externalImages.map(function(image) {
          return encodeImageAsDataURI(image, options).then(function(dataURI) {
            if (!!image.attributes.src) {
              image.attributes.src.value = dataURI;
            } else if (!!image.attributes["xlink:href"]) {
              image.attributes["xlink:href"].value = dataURI;
            } else if (!!image.attributes.href) {
              image.attributes.href.value = dataURI;
            }
          });
        })
      );
    };
  }
});

// ../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/inlineScript.js
var require_inlineScript = __commonJS({
  "../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/inlineScript.js"(exports) {
    "use strict";
    var util = require_util2();
    var loadLinkedScript = function(script, options) {
      var src = script.attributes.src.value, documentBase = util.getDocumentBaseUrl(script.ownerDocument), ajaxOptions = util.clone(options);
      if (!ajaxOptions.baseUrl && documentBase) {
        ajaxOptions.baseUrl = documentBase;
      }
      return util.ajax(src, ajaxOptions).catch(function(e) {
        throw {
          resourceType: "script",
          url: e.url,
          msg: "Unable to load script " + e.url
        };
      });
    };
    var escapeClosingTags = function(text) {
      return text.replace(/<\//g, "<\\/");
    };
    var substituteExternalScriptWithInline = function(scriptNode, jsCode) {
      scriptNode.attributes.removeNamedItem("src");
      scriptNode.textContent = escapeClosingTags(jsCode);
    };
    var getScripts = function(doc) {
      var scripts = doc.getElementsByTagName("script");
      return Array.prototype.filter.call(scripts, function(script) {
        return !!script.attributes.src;
      });
    };
    exports.inline = function(doc, options) {
      var scripts = getScripts(doc);
      return util.collectAndReportErrors(
        scripts.map(function(script) {
          return loadLinkedScript(script, options).then(function(jsCode) {
            substituteExternalScriptWithInline(script, jsCode);
          });
        })
      );
    };
  }
});

// ../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/cssSupport.js
var require_cssSupport = __commonJS({
  "../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/cssSupport.js"(exports) {
    "use strict";
    exports.unquoteString = function(quotedUrl) {
      var doubleQuoteRegex = /^"(.*)"$/, singleQuoteRegex = /^'(.*)'$/;
      if (doubleQuoteRegex.test(quotedUrl)) {
        return quotedUrl.replace(doubleQuoteRegex, "$1");
      } else {
        if (singleQuoteRegex.test(quotedUrl)) {
          return quotedUrl.replace(singleQuoteRegex, "$1");
        } else {
          return quotedUrl;
        }
      }
    };
    exports.rulesForCssText = function(styleContent) {
      var doc = document.implementation.createHTMLDocument(""), styleElement = document.createElement("style"), rules;
      styleElement.textContent = styleContent;
      doc.body.appendChild(styleElement);
      rules = styleElement.sheet.cssRules;
      return Array.prototype.slice.call(rules);
    };
    exports.cssRulesToText = function(cssRules) {
      return cssRules.reduce(function(cssText, rule) {
        return cssText + rule.cssText;
      }, "");
    };
    exports.exchangeRule = function(cssRules, rule, newRuleText) {
      var ruleIdx = cssRules.indexOf(rule);
      cssRules[ruleIdx] = exports.rulesForCssText(newRuleText)[0];
    };
    exports.changeFontFaceRuleSrc = function(cssRules, rule, newSrc) {
      var newRuleText = "@font-face { font-family: " + rule.style.getPropertyValue("font-family") + "; ";
      if (rule.style.getPropertyValue("font-style")) {
        newRuleText += "font-style: " + rule.style.getPropertyValue("font-style") + "; ";
      }
      if (rule.style.getPropertyValue("font-weight")) {
        newRuleText += "font-weight: " + rule.style.getPropertyValue("font-weight") + "; ";
      }
      if (rule.style.getPropertyValue("unicode-range")) {
        newRuleText += "unicode-range: " + rule.style.getPropertyValue("unicode-range") + "; ";
      }
      newRuleText += "src: " + newSrc + "}";
      exports.exchangeRule(cssRules, rule, newRuleText);
    };
  }
});

// ../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/backgroundValueParser.js
var require_backgroundValueParser = __commonJS({
  "../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/backgroundValueParser.js"(exports) {
    "use strict";
    var cssSupport = require_cssSupport();
    var trimCSSWhitespace = function(url) {
      var whitespaceRegex = /^[\t\r\f\n ]*(.+?)[\t\r\f\n ]*$/;
      return url.replace(whitespaceRegex, "$1");
    };
    exports.extractCssUrl = function(cssUrl) {
      var urlRegex = /^url\(("[^"]+"|'[^']+'|[^\)]+)\)/, quotedUrl;
      if (!urlRegex.test(cssUrl)) {
        throw new Error("Invalid url");
      }
      quotedUrl = urlRegex.exec(cssUrl)[1];
      return cssSupport.unquoteString(trimCSSWhitespace(quotedUrl));
    };
    var sliceBackgroundDeclaration = function(backgroundDeclarationText) {
      var functionParamRegexS = `\\s*(?:"[^"]*"|'[^']*'|[^\\(]+)\\s*`, valueRegexS = "(url\\(" + functionParamRegexS + "\\)|[^,\\s]+)", simpleSingularBackgroundRegexS = "(?:\\s*" + valueRegexS + ")+", simpleBackgroundRegexS = "^\\s*(" + simpleSingularBackgroundRegexS + ")(?:\\s*,\\s*(" + simpleSingularBackgroundRegexS + "))*\\s*$", simpleSingularBackgroundRegex = new RegExp(
        simpleSingularBackgroundRegexS,
        "g"
      ), outerRepeatedMatch, backgroundLayers = [], getValues = function(singularBackgroundDeclaration) {
        var valueRegex = new RegExp(valueRegexS, "g"), backgroundValues = [], repeatedMatch;
        repeatedMatch = valueRegex.exec(singularBackgroundDeclaration);
        while (repeatedMatch) {
          backgroundValues.push(repeatedMatch[1]);
          repeatedMatch = valueRegex.exec(singularBackgroundDeclaration);
        }
        return backgroundValues;
      };
      if (backgroundDeclarationText.match(new RegExp(simpleBackgroundRegexS))) {
        outerRepeatedMatch = simpleSingularBackgroundRegex.exec(
          backgroundDeclarationText
        );
        while (outerRepeatedMatch) {
          backgroundLayers.push(getValues(outerRepeatedMatch[0]));
          outerRepeatedMatch = simpleSingularBackgroundRegex.exec(
            backgroundDeclarationText
          );
        }
        return backgroundLayers;
      }
      return [];
    };
    var findBackgroundImageUrlInValues = function(values) {
      var i, url;
      for (i = 0; i < values.length; i++) {
        try {
          url = exports.extractCssUrl(values[i]);
          return {
            url,
            idx: i
          };
        } catch (e) {
        }
      }
    };
    exports.parse = function(backgroundValue) {
      var backgroundLayers = sliceBackgroundDeclaration(backgroundValue);
      return backgroundLayers.map(function(backgroundLayerValues) {
        var urlMatch = findBackgroundImageUrlInValues(backgroundLayerValues);
        if (urlMatch) {
          return {
            preUrl: backgroundLayerValues.slice(0, urlMatch.idx),
            url: urlMatch.url,
            postUrl: backgroundLayerValues.slice(urlMatch.idx + 1)
          };
        } else {
          return {
            preUrl: backgroundLayerValues
          };
        }
      });
    };
    exports.serialize = function(parsedBackground) {
      var backgroundLayers = parsedBackground.map(function(backgroundLayer) {
        var values = [].concat(backgroundLayer.preUrl);
        if (backgroundLayer.url) {
          values.push('url("' + backgroundLayer.url + '")');
        }
        if (backgroundLayer.postUrl) {
          values = values.concat(backgroundLayer.postUrl);
        }
        return values.join(" ");
      });
      return backgroundLayers.join(", ");
    };
  }
});

// ../../node_modules/.pnpm/css-font-face-src@1.0.0/node_modules/css-font-face-src/dist/css-font-face-src.js
var require_css_font_face_src = __commonJS({
  "../../node_modules/.pnpm/css-font-face-src@1.0.0/node_modules/css-font-face-src/dist/css-font-face-src.js"(exports, module) {
    (function(f) {
      if (typeof exports === "object" && typeof module !== "undefined") {
        module.exports = f();
      } else if (typeof define === "function" && define.amd) {
        define([], f);
      } else {
        var g;
        if (typeof window !== "undefined") {
          g = window;
        } else if (typeof global !== "undefined") {
          g = global;
        } else if (typeof self !== "undefined") {
          g = self;
        } else {
          g = this;
        }
        g.cssFontFaceSrc = f();
      }
    })(function() {
      var define2, module2, exports2;
      return function e(t, n, r) {
        function s(o2, u) {
          if (!n[o2]) {
            if (!t[o2]) {
              var a = typeof __require == "function" && __require;
              if (!u && a)
                return a(o2, true);
              if (i)
                return i(o2, true);
              var f = new Error("Cannot find module '" + o2 + "'");
              throw f.code = "MODULE_NOT_FOUND", f;
            }
            var l = n[o2] = { exports: {} };
            t[o2][0].call(l.exports, function(e2) {
              var n2 = t[o2][1][e2];
              return s(n2 ? n2 : e2);
            }, l, l.exports, e, t, n, r);
          }
          return n[o2].exports;
        }
        var i = typeof __require == "function" && __require;
        for (var o = 0; o < r.length; o++)
          s(r[o]);
        return s;
      }({ 1: [function(_dereq_, module3, exports3) {
        "use strict";
        function peg$subclass(child, parent) {
          function ctor() {
            this.constructor = child;
          }
          ctor.prototype = parent.prototype;
          child.prototype = new ctor();
        }
        function peg$SyntaxError(message, expected, found, location) {
          this.message = message;
          this.expected = expected;
          this.found = found;
          this.location = location;
          this.name = "SyntaxError";
          if (typeof Error.captureStackTrace === "function") {
            Error.captureStackTrace(this, peg$SyntaxError);
          }
        }
        peg$subclass(peg$SyntaxError, Error);
        peg$SyntaxError.buildMessage = function(expected, found) {
          var DESCRIBE_EXPECTATION_FNS = {
            literal: function(expectation) {
              return '"' + literalEscape(expectation.text) + '"';
            },
            "class": function(expectation) {
              var escapedParts = "", i;
              for (i = 0; i < expectation.parts.length; i++) {
                escapedParts += expectation.parts[i] instanceof Array ? classEscape(expectation.parts[i][0]) + "-" + classEscape(expectation.parts[i][1]) : classEscape(expectation.parts[i]);
              }
              return "[" + (expectation.inverted ? "^" : "") + escapedParts + "]";
            },
            any: function(expectation) {
              return "any character";
            },
            end: function(expectation) {
              return "end of input";
            },
            other: function(expectation) {
              return expectation.description;
            }
          };
          function hex(ch) {
            return ch.charCodeAt(0).toString(16).toUpperCase();
          }
          function literalEscape(s) {
            return s.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\0/g, "\\0").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/[\x00-\x0F]/g, function(ch) {
              return "\\x0" + hex(ch);
            }).replace(/[\x10-\x1F\x7F-\x9F]/g, function(ch) {
              return "\\x" + hex(ch);
            });
          }
          function classEscape(s) {
            return s.replace(/\\/g, "\\\\").replace(/\]/g, "\\]").replace(/\^/g, "\\^").replace(/-/g, "\\-").replace(/\0/g, "\\0").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/[\x00-\x0F]/g, function(ch) {
              return "\\x0" + hex(ch);
            }).replace(/[\x10-\x1F\x7F-\x9F]/g, function(ch) {
              return "\\x" + hex(ch);
            });
          }
          function describeExpectation(expectation) {
            return DESCRIBE_EXPECTATION_FNS[expectation.type](expectation);
          }
          function describeExpected(expected2) {
            var descriptions = new Array(expected2.length), i, j;
            for (i = 0; i < expected2.length; i++) {
              descriptions[i] = describeExpectation(expected2[i]);
            }
            descriptions.sort();
            if (descriptions.length > 0) {
              for (i = 1, j = 1; i < descriptions.length; i++) {
                if (descriptions[i - 1] !== descriptions[i]) {
                  descriptions[j] = descriptions[i];
                  j++;
                }
              }
              descriptions.length = j;
            }
            switch (descriptions.length) {
              case 1:
                return descriptions[0];
              case 2:
                return descriptions[0] + " or " + descriptions[1];
              default:
                return descriptions.slice(0, -1).join(", ") + ", or " + descriptions[descriptions.length - 1];
            }
          }
          function describeFound(found2) {
            return found2 ? '"' + literalEscape(found2) + '"' : "end of input";
          }
          return "Expected " + describeExpected(expected) + " but " + describeFound(found) + " found.";
        };
        function peg$parse(input, options) {
          options = options !== void 0 ? options : {};
          var peg$FAILED = {}, peg$startRuleFunctions = { start: peg$parsestart }, peg$startRuleFunction = peg$parsestart, peg$c0 = "", peg$c1 = function() {
            return [];
          }, peg$c2 = ",", peg$c3 = peg$literalExpectation(",", false), peg$c4 = function(x, xs) {
            return [x].concat(xs);
          }, peg$c5 = function(entry) {
            return [entry];
          }, peg$c6 = function(url, format) {
            return { url, format };
          }, peg$c7 = function(url) {
            return { url };
          }, peg$c8 = "url(", peg$c9 = peg$literalExpectation("url(", false), peg$c10 = ")", peg$c11 = peg$literalExpectation(")", false), peg$c12 = function(value) {
            return value;
          }, peg$c13 = "format(", peg$c14 = peg$literalExpectation("format(", false), peg$c15 = "local(", peg$c16 = peg$literalExpectation("local(", false), peg$c17 = function(value) {
            return { local: value };
          }, peg$c18 = /^[^)]/, peg$c19 = peg$classExpectation([")"], true, false), peg$c20 = function(chars) {
            return util.extractValue(chars.join(""));
          }, peg$c21 = /^[ \t\r\n\f]/, peg$c22 = peg$classExpectation([" ", "	", "\r", "\n", "\f"], false, false), peg$currPos = 0, peg$savedPos = 0, peg$posDetailsCache = [{ line: 1, column: 1 }], peg$maxFailPos = 0, peg$maxFailExpected = [], peg$silentFails = 0, peg$result;
          if ("startRule" in options) {
            if (!(options.startRule in peg$startRuleFunctions)) {
              throw new Error(`Can't start parsing from rule "` + options.startRule + '".');
            }
            peg$startRuleFunction = peg$startRuleFunctions[options.startRule];
          }
          function text() {
            return input.substring(peg$savedPos, peg$currPos);
          }
          function location() {
            return peg$computeLocation(peg$savedPos, peg$currPos);
          }
          function expected(description, location2) {
            location2 = location2 !== void 0 ? location2 : peg$computeLocation(peg$savedPos, peg$currPos);
            throw peg$buildStructuredError(
              [peg$otherExpectation(description)],
              input.substring(peg$savedPos, peg$currPos),
              location2
            );
          }
          function error(message, location2) {
            location2 = location2 !== void 0 ? location2 : peg$computeLocation(peg$savedPos, peg$currPos);
            throw peg$buildSimpleError(message, location2);
          }
          function peg$literalExpectation(text2, ignoreCase) {
            return { type: "literal", text: text2, ignoreCase };
          }
          function peg$classExpectation(parts, inverted, ignoreCase) {
            return { type: "class", parts, inverted, ignoreCase };
          }
          function peg$anyExpectation() {
            return { type: "any" };
          }
          function peg$endExpectation() {
            return { type: "end" };
          }
          function peg$otherExpectation(description) {
            return { type: "other", description };
          }
          function peg$computePosDetails(pos) {
            var details = peg$posDetailsCache[pos], p;
            if (details) {
              return details;
            } else {
              p = pos - 1;
              while (!peg$posDetailsCache[p]) {
                p--;
              }
              details = peg$posDetailsCache[p];
              details = {
                line: details.line,
                column: details.column
              };
              while (p < pos) {
                if (input.charCodeAt(p) === 10) {
                  details.line++;
                  details.column = 1;
                } else {
                  details.column++;
                }
                p++;
              }
              peg$posDetailsCache[pos] = details;
              return details;
            }
          }
          function peg$computeLocation(startPos, endPos) {
            var startPosDetails = peg$computePosDetails(startPos), endPosDetails = peg$computePosDetails(endPos);
            return {
              start: {
                offset: startPos,
                line: startPosDetails.line,
                column: startPosDetails.column
              },
              end: {
                offset: endPos,
                line: endPosDetails.line,
                column: endPosDetails.column
              }
            };
          }
          function peg$fail(expected2) {
            if (peg$currPos < peg$maxFailPos) {
              return;
            }
            if (peg$currPos > peg$maxFailPos) {
              peg$maxFailPos = peg$currPos;
              peg$maxFailExpected = [];
            }
            peg$maxFailExpected.push(expected2);
          }
          function peg$buildSimpleError(message, location2) {
            return new peg$SyntaxError(message, null, null, location2);
          }
          function peg$buildStructuredError(expected2, found, location2) {
            return new peg$SyntaxError(
              peg$SyntaxError.buildMessage(expected2, found),
              expected2,
              found,
              location2
            );
          }
          function peg$parsestart() {
            var s0, s1;
            s0 = peg$parsesourceEntries();
            if (s0 === peg$FAILED) {
              s0 = peg$currPos;
              s1 = peg$c0;
              if (s1 !== peg$FAILED) {
                peg$savedPos = s0;
                s1 = peg$c1();
              }
              s0 = s1;
            }
            return s0;
          }
          function peg$parsesourceEntries() {
            var s0, s1, s2, s3, s4, s5;
            s0 = peg$currPos;
            s1 = peg$parsesourceEntry();
            if (s1 !== peg$FAILED) {
              s2 = [];
              s3 = peg$parsewhitespace();
              while (s3 !== peg$FAILED) {
                s2.push(s3);
                s3 = peg$parsewhitespace();
              }
              if (s2 !== peg$FAILED) {
                if (input.charCodeAt(peg$currPos) === 44) {
                  s3 = peg$c2;
                  peg$currPos++;
                } else {
                  s3 = peg$FAILED;
                  if (peg$silentFails === 0) {
                    peg$fail(peg$c3);
                  }
                }
                if (s3 !== peg$FAILED) {
                  s4 = [];
                  s5 = peg$parsewhitespace();
                  while (s5 !== peg$FAILED) {
                    s4.push(s5);
                    s5 = peg$parsewhitespace();
                  }
                  if (s4 !== peg$FAILED) {
                    s5 = peg$parsesourceEntries();
                    if (s5 !== peg$FAILED) {
                      peg$savedPos = s0;
                      s1 = peg$c4(s1, s5);
                      s0 = s1;
                    } else {
                      peg$currPos = s0;
                      s0 = peg$FAILED;
                    }
                  } else {
                    peg$currPos = s0;
                    s0 = peg$FAILED;
                  }
                } else {
                  peg$currPos = s0;
                  s0 = peg$FAILED;
                }
              } else {
                peg$currPos = s0;
                s0 = peg$FAILED;
              }
            } else {
              peg$currPos = s0;
              s0 = peg$FAILED;
            }
            if (s0 === peg$FAILED) {
              s0 = peg$currPos;
              s1 = peg$parsesourceEntry();
              if (s1 !== peg$FAILED) {
                peg$savedPos = s0;
                s1 = peg$c5(s1);
              }
              s0 = s1;
            }
            return s0;
          }
          function peg$parsesourceEntry() {
            var s0;
            s0 = peg$parseurlEntry();
            if (s0 === peg$FAILED) {
              s0 = peg$parselocalEntry();
            }
            return s0;
          }
          function peg$parseurlEntry() {
            var s0, s1, s2, s3;
            s0 = peg$currPos;
            s1 = peg$parseurl();
            if (s1 !== peg$FAILED) {
              s2 = [];
              s3 = peg$parsewhitespace();
              if (s3 !== peg$FAILED) {
                while (s3 !== peg$FAILED) {
                  s2.push(s3);
                  s3 = peg$parsewhitespace();
                }
              } else {
                s2 = peg$FAILED;
              }
              if (s2 !== peg$FAILED) {
                s3 = peg$parseformat();
                if (s3 !== peg$FAILED) {
                  peg$savedPos = s0;
                  s1 = peg$c6(s1, s3);
                  s0 = s1;
                } else {
                  peg$currPos = s0;
                  s0 = peg$FAILED;
                }
              } else {
                peg$currPos = s0;
                s0 = peg$FAILED;
              }
            } else {
              peg$currPos = s0;
              s0 = peg$FAILED;
            }
            if (s0 === peg$FAILED) {
              s0 = peg$currPos;
              s1 = peg$parseurl();
              if (s1 !== peg$FAILED) {
                peg$savedPos = s0;
                s1 = peg$c7(s1);
              }
              s0 = s1;
            }
            return s0;
          }
          function peg$parseurl() {
            var s0, s1, s2, s3;
            s0 = peg$currPos;
            if (input.substr(peg$currPos, 4) === peg$c8) {
              s1 = peg$c8;
              peg$currPos += 4;
            } else {
              s1 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$c9);
              }
            }
            if (s1 !== peg$FAILED) {
              s2 = peg$parsevalue();
              if (s2 !== peg$FAILED) {
                if (input.charCodeAt(peg$currPos) === 41) {
                  s3 = peg$c10;
                  peg$currPos++;
                } else {
                  s3 = peg$FAILED;
                  if (peg$silentFails === 0) {
                    peg$fail(peg$c11);
                  }
                }
                if (s3 !== peg$FAILED) {
                  peg$savedPos = s0;
                  s1 = peg$c12(s2);
                  s0 = s1;
                } else {
                  peg$currPos = s0;
                  s0 = peg$FAILED;
                }
              } else {
                peg$currPos = s0;
                s0 = peg$FAILED;
              }
            } else {
              peg$currPos = s0;
              s0 = peg$FAILED;
            }
            return s0;
          }
          function peg$parseformat() {
            var s0, s1, s2, s3;
            s0 = peg$currPos;
            if (input.substr(peg$currPos, 7) === peg$c13) {
              s1 = peg$c13;
              peg$currPos += 7;
            } else {
              s1 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$c14);
              }
            }
            if (s1 !== peg$FAILED) {
              s2 = peg$parsevalue();
              if (s2 !== peg$FAILED) {
                if (input.charCodeAt(peg$currPos) === 41) {
                  s3 = peg$c10;
                  peg$currPos++;
                } else {
                  s3 = peg$FAILED;
                  if (peg$silentFails === 0) {
                    peg$fail(peg$c11);
                  }
                }
                if (s3 !== peg$FAILED) {
                  peg$savedPos = s0;
                  s1 = peg$c12(s2);
                  s0 = s1;
                } else {
                  peg$currPos = s0;
                  s0 = peg$FAILED;
                }
              } else {
                peg$currPos = s0;
                s0 = peg$FAILED;
              }
            } else {
              peg$currPos = s0;
              s0 = peg$FAILED;
            }
            return s0;
          }
          function peg$parselocalEntry() {
            var s0, s1, s2, s3;
            s0 = peg$currPos;
            if (input.substr(peg$currPos, 6) === peg$c15) {
              s1 = peg$c15;
              peg$currPos += 6;
            } else {
              s1 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$c16);
              }
            }
            if (s1 !== peg$FAILED) {
              s2 = peg$parsevalue();
              if (s2 !== peg$FAILED) {
                if (input.charCodeAt(peg$currPos) === 41) {
                  s3 = peg$c10;
                  peg$currPos++;
                } else {
                  s3 = peg$FAILED;
                  if (peg$silentFails === 0) {
                    peg$fail(peg$c11);
                  }
                }
                if (s3 !== peg$FAILED) {
                  peg$savedPos = s0;
                  s1 = peg$c17(s2);
                  s0 = s1;
                } else {
                  peg$currPos = s0;
                  s0 = peg$FAILED;
                }
              } else {
                peg$currPos = s0;
                s0 = peg$FAILED;
              }
            } else {
              peg$currPos = s0;
              s0 = peg$FAILED;
            }
            return s0;
          }
          function peg$parsevalue() {
            var s0, s1, s2;
            s0 = peg$currPos;
            s1 = [];
            if (peg$c18.test(input.charAt(peg$currPos))) {
              s2 = input.charAt(peg$currPos);
              peg$currPos++;
            } else {
              s2 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$c19);
              }
            }
            if (s2 !== peg$FAILED) {
              while (s2 !== peg$FAILED) {
                s1.push(s2);
                if (peg$c18.test(input.charAt(peg$currPos))) {
                  s2 = input.charAt(peg$currPos);
                  peg$currPos++;
                } else {
                  s2 = peg$FAILED;
                  if (peg$silentFails === 0) {
                    peg$fail(peg$c19);
                  }
                }
              }
            } else {
              s1 = peg$FAILED;
            }
            if (s1 !== peg$FAILED) {
              peg$savedPos = s0;
              s1 = peg$c20(s1);
            }
            s0 = s1;
            return s0;
          }
          function peg$parsewhitespace() {
            var s0;
            if (peg$c21.test(input.charAt(peg$currPos))) {
              s0 = input.charAt(peg$currPos);
              peg$currPos++;
            } else {
              s0 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$c22);
              }
            }
            return s0;
          }
          var util = _dereq_("../util");
          peg$result = peg$startRuleFunction();
          if (peg$result !== peg$FAILED && peg$currPos === input.length) {
            return peg$result;
          } else {
            if (peg$result !== peg$FAILED && peg$currPos < input.length) {
              peg$fail(peg$endExpectation());
            }
            throw peg$buildStructuredError(
              peg$maxFailExpected,
              peg$maxFailPos < input.length ? input.charAt(peg$maxFailPos) : null,
              peg$maxFailPos < input.length ? peg$computeLocation(peg$maxFailPos, peg$maxFailPos + 1) : peg$computeLocation(peg$maxFailPos, peg$maxFailPos)
            );
          }
        }
        module3.exports = {
          SyntaxError: peg$SyntaxError,
          parse: peg$parse
        };
      }, { "../util": 3 }], 2: [function(_dereq_, module3, exports3) {
        var grammar = _dereq_("./grammar");
        exports3.SyntaxError = function(message, offset) {
          this.message = message;
          this.offset = offset;
        };
        exports3.parse = function(fontFaceSourceValue) {
          try {
            return grammar.parse(fontFaceSourceValue);
          } catch (e) {
            throw new exports3.SyntaxError(e.message, e.offset);
          }
        };
        exports3.serialize = function(parsedFontFaceSources) {
          return parsedFontFaceSources.map(function(sourceItem) {
            var itemValue;
            if (sourceItem.url) {
              itemValue = 'url("' + sourceItem.url + '")';
              if (sourceItem.format) {
                itemValue += ' format("' + sourceItem.format + '")';
              }
            } else {
              itemValue = 'local("' + sourceItem.local + '")';
            }
            return itemValue;
          }).join(", ");
        };
      }, { "./grammar": 1 }], 3: [function(_dereq_, module3, exports3) {
        var trimCSSWhitespace = function(value) {
          var whitespaceRegex = /^[\t\r\f\n ]*(.+?)[\t\r\f\n ]*$/;
          return value.replace(whitespaceRegex, "$1");
        };
        var unquoteString = function(quotedUrl) {
          var doubleQuoteRegex = /^"(.*)"$/, singleQuoteRegex = /^'(.*)'$/;
          if (doubleQuoteRegex.test(quotedUrl)) {
            return quotedUrl.replace(doubleQuoteRegex, "$1");
          } else {
            if (singleQuoteRegex.test(quotedUrl)) {
              return quotedUrl.replace(singleQuoteRegex, "$1");
            } else {
              return quotedUrl;
            }
          }
        };
        exports3.extractValue = function(value) {
          return unquoteString(trimCSSWhitespace(value));
        };
      }, {}] }, {}, [2])(2);
    });
  }
});

// ../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/inlineCss.js
var require_inlineCss = __commonJS({
  "../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/inlineCss.js"(exports) {
    "use strict";
    var util = require_util2();
    var cssSupport = require_cssSupport();
    var backgroundValueParser = require_backgroundValueParser();
    var fontFaceSrcValueParser = require_css_font_face_src();
    var updateCssPropertyValue = function(rule, property, value) {
      rule.style.setProperty(
        property,
        value,
        rule.style.getPropertyPriority(property)
      );
    };
    var findBackgroundImageRules = function(cssRules) {
      return cssRules.filter(function(rule) {
        return rule.type === window.CSSRule.STYLE_RULE && (rule.style.getPropertyValue("background-image") || rule.style.getPropertyValue("background"));
      });
    };
    var findBackgroundDeclarations = function(rules) {
      var backgroundDeclarations = [];
      rules.forEach(function(rule) {
        if (rule.style.getPropertyValue("background-image")) {
          backgroundDeclarations.push({
            property: "background-image",
            value: rule.style.getPropertyValue("background-image"),
            rule
          });
        } else if (rule.style.getPropertyValue("background")) {
          backgroundDeclarations.push({
            property: "background",
            value: rule.style.getPropertyValue("background"),
            rule
          });
        }
      });
      return backgroundDeclarations;
    };
    var findFontFaceRules = function(cssRules) {
      return cssRules.filter(function(rule) {
        return rule.type === window.CSSRule.FONT_FACE_RULE && rule.style.getPropertyValue("src");
      });
    };
    var findCSSImportRules = function(cssRules) {
      return cssRules.filter(function(rule) {
        return rule.type === window.CSSRule.IMPORT_RULE && rule.href;
      });
    };
    var findExternalBackgroundUrls = function(parsedBackground) {
      var matchIndices = [];
      parsedBackground.forEach(function(backgroundLayer, i) {
        if (backgroundLayer.url && !util.isDataUri(backgroundLayer.url)) {
          matchIndices.push(i);
        }
      });
      return matchIndices;
    };
    var findExternalFontFaceUrls = function(parsedFontFaceSources) {
      var sourceIndices = [];
      parsedFontFaceSources.forEach(function(sourceItem, i) {
        if (sourceItem.url && !util.isDataUri(sourceItem.url)) {
          sourceIndices.push(i);
        }
      });
      return sourceIndices;
    };
    exports.adjustPathsOfCssResources = function(baseUrl, cssRules) {
      var backgroundRules = findBackgroundImageRules(cssRules), backgroundDeclarations = findBackgroundDeclarations(backgroundRules), change = false;
      backgroundDeclarations.forEach(function(declaration) {
        var parsedBackground = backgroundValueParser.parse(declaration.value), externalBackgroundIndices = findExternalBackgroundUrls(parsedBackground), backgroundValue;
        if (externalBackgroundIndices.length > 0) {
          externalBackgroundIndices.forEach(function(backgroundLayerIndex) {
            var relativeUrl = parsedBackground[backgroundLayerIndex].url, url = util.joinUrl(baseUrl, relativeUrl);
            parsedBackground[backgroundLayerIndex].url = url;
          });
          backgroundValue = backgroundValueParser.serialize(parsedBackground);
          updateCssPropertyValue(
            declaration.rule,
            declaration.property,
            backgroundValue
          );
          change = true;
        }
      });
      findFontFaceRules(cssRules).forEach(function(rule) {
        var fontFaceSrcDeclaration = rule.style.getPropertyValue("src"), parsedFontFaceSources, externalFontFaceUrlIndices;
        try {
          parsedFontFaceSources = fontFaceSrcValueParser.parse(
            fontFaceSrcDeclaration
          );
        } catch (e) {
          return;
        }
        externalFontFaceUrlIndices = findExternalFontFaceUrls(
          parsedFontFaceSources
        );
        if (externalFontFaceUrlIndices.length > 0) {
          externalFontFaceUrlIndices.forEach(function(fontFaceUrlIndex) {
            var relativeUrl = parsedFontFaceSources[fontFaceUrlIndex].url, url = util.joinUrl(baseUrl, relativeUrl);
            parsedFontFaceSources[fontFaceUrlIndex].url = url;
          });
          cssSupport.changeFontFaceRuleSrc(
            cssRules,
            rule,
            fontFaceSrcValueParser.serialize(parsedFontFaceSources)
          );
          change = true;
        }
      });
      findCSSImportRules(cssRules).forEach(function(rule) {
        var cssUrl = rule.href, url = util.joinUrl(baseUrl, cssUrl);
        cssSupport.exchangeRule(cssRules, rule, "@import url(" + url + ");");
        change = true;
      });
      return change;
    };
    var substituteRule = function(cssRules, rule, newCssRules) {
      var position = cssRules.indexOf(rule);
      cssRules.splice(position, 1);
      newCssRules.forEach(function(newRule, i) {
        cssRules.splice(position + i, 0, newRule);
      });
    };
    var loadAndInlineCSSImport = function(cssRules, rule, alreadyLoadedCssUrls, options) {
      var url = rule.href, cssHrefRelativeToDoc;
      url = cssSupport.unquoteString(url);
      cssHrefRelativeToDoc = util.joinUrl(options.baseUrl, url);
      if (alreadyLoadedCssUrls.indexOf(cssHrefRelativeToDoc) >= 0) {
        substituteRule(cssRules, rule, []);
        return Promise.resolve([]);
      } else {
        alreadyLoadedCssUrls.push(cssHrefRelativeToDoc);
      }
      return util.ajax(url, options).then(
        function(cssText) {
          var externalCssRules = cssSupport.rulesForCssText(cssText);
          return exports.loadCSSImportsForRules(externalCssRules, alreadyLoadedCssUrls, options).then(function(result) {
            exports.adjustPathsOfCssResources(url, externalCssRules);
            substituteRule(cssRules, rule, externalCssRules);
            return result.errors;
          });
        },
        function(e) {
          throw {
            resourceType: "stylesheet",
            url: e.url,
            msg: "Unable to load stylesheet " + e.url
          };
        }
      );
    };
    exports.loadCSSImportsForRules = function(cssRules, alreadyLoadedCssUrls, options) {
      var rulesToInline = findCSSImportRules(cssRules), errors = [], hasChanges = false;
      return Promise.all(
        rulesToInline.map(function(rule) {
          return loadAndInlineCSSImport(
            cssRules,
            rule,
            alreadyLoadedCssUrls,
            options
          ).then(
            function(moreErrors) {
              errors = errors.concat(moreErrors);
              hasChanges = true;
            },
            function(e) {
              errors.push(e);
            }
          );
        })
      ).then(function() {
        return {
          hasChanges,
          errors
        };
      });
    };
    var loadAndInlineBackgroundImages = function(backgroundValue, options) {
      var parsedBackground = backgroundValueParser.parse(backgroundValue), externalBackgroundLayerIndices = findExternalBackgroundUrls(
        parsedBackground
      ), hasChanges = false;
      return util.collectAndReportErrors(
        externalBackgroundLayerIndices.map(function(backgroundLayerIndex) {
          var url = parsedBackground[backgroundLayerIndex].url;
          return util.getDataURIForImageURL(url, options).then(
            function(dataURI) {
              parsedBackground[backgroundLayerIndex].url = dataURI;
              hasChanges = true;
            },
            function(e) {
              throw {
                resourceType: "backgroundImage",
                url: e.url,
                msg: "Unable to load background-image " + e.url
              };
            }
          );
        })
      ).then(function(errors) {
        return {
          backgroundValue: backgroundValueParser.serialize(parsedBackground),
          hasChanges,
          errors
        };
      });
    };
    var iterateOverRulesAndInlineBackgroundImages = function(cssRules, options) {
      var rulesToInline = findBackgroundImageRules(cssRules), backgroundDeclarations = findBackgroundDeclarations(rulesToInline), errors = [], cssHasChanges = false;
      return Promise.all(
        backgroundDeclarations.map(function(declaration) {
          return loadAndInlineBackgroundImages(declaration.value, options).then(
            function(result) {
              if (result.hasChanges) {
                updateCssPropertyValue(
                  declaration.rule,
                  declaration.property,
                  result.backgroundValue
                );
                cssHasChanges = true;
              }
              errors = errors.concat(result.errors);
            }
          );
        })
      ).then(function() {
        return {
          hasChanges: cssHasChanges,
          errors
        };
      });
    };
    var loadAndInlineFontFace = function(srcDeclarationValue, options) {
      var hasChanges = false, parsedFontFaceSources, externalFontFaceUrlIndices;
      try {
        parsedFontFaceSources = fontFaceSrcValueParser.parse(srcDeclarationValue);
      } catch (e) {
        parsedFontFaceSources = [];
      }
      externalFontFaceUrlIndices = findExternalFontFaceUrls(parsedFontFaceSources);
      return util.collectAndReportErrors(
        externalFontFaceUrlIndices.map(function(urlIndex) {
          var fontSrc = parsedFontFaceSources[urlIndex], format = fontSrc.format || "woff";
          return util.binaryAjax(fontSrc.url, options).then(
            function(content) {
              var base64Content = btoa(content);
              fontSrc.url = "data:font/" + format + ";base64," + base64Content;
              hasChanges = true;
            },
            function(e) {
              throw {
                resourceType: "fontFace",
                url: e.url,
                msg: "Unable to load font-face " + e.url
              };
            }
          );
        })
      ).then(function(errors) {
        return {
          srcDeclarationValue: fontFaceSrcValueParser.serialize(
            parsedFontFaceSources
          ),
          hasChanges,
          errors
        };
      });
    };
    var iterateOverRulesAndInlineFontFace = function(cssRules, options) {
      var rulesToInline = findFontFaceRules(cssRules), errors = [], hasChanges = false;
      return Promise.all(
        rulesToInline.map(function(rule) {
          var srcDeclarationValue = rule.style.getPropertyValue("src");
          return loadAndInlineFontFace(srcDeclarationValue, options).then(function(result) {
            if (result.hasChanges) {
              cssSupport.changeFontFaceRuleSrc(
                cssRules,
                rule,
                result.srcDeclarationValue
              );
              hasChanges = true;
            }
            errors = errors.concat(result.errors);
          });
        })
      ).then(function() {
        return {
          hasChanges,
          errors
        };
      });
    };
    exports.loadAndInlineCSSResourcesForRules = function(cssRules, options) {
      var hasChanges = false, errors = [];
      return Promise.all(
        [
          iterateOverRulesAndInlineBackgroundImages,
          iterateOverRulesAndInlineFontFace
        ].map(function(func) {
          return func(cssRules, options).then(function(result) {
            hasChanges = hasChanges || result.hasChanges;
            errors = errors.concat(result.errors);
          });
        })
      ).then(function() {
        return {
          hasChanges,
          errors
        };
      });
    };
  }
});

// ../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/inline.js
var require_inline = __commonJS({
  "../../node_modules/.pnpm/inlineresources@1.0.1/node_modules/inlineresources/src/inline.js"(exports) {
    "use strict";
    var util = require_util2();
    var inlineImage = require_inlineImage();
    var inlineScript = require_inlineScript();
    var inlineCss = require_inlineCss();
    var cssSupport = require_cssSupport();
    var getUrlBasePath = function(url) {
      return util.joinUrl(url, ".");
    };
    var parameterHashFunction = function(params) {
      var a = params.map(function(param, idx) {
        if (idx === params.length - 1) {
          param = {
            // Two different HTML pages on the same path level have the same base path, but a different URL
            baseUrl: getUrlBasePath(param.baseUrl)
          };
        }
        return JSON.stringify(param);
      });
      return a;
    };
    var memoizeFunctionOnCaching = function(func, options) {
      if (options.cache !== false && options.cache !== "none" && options.cacheBucket) {
        return util.memoize(func, parameterHashFunction, options.cacheBucket);
      } else {
        return func;
      }
    };
    var requestExternalsForStylesheet = function(styleContent, alreadyLoadedCssUrls, options) {
      var cssRules = cssSupport.rulesForCssText(styleContent);
      return inlineCss.loadCSSImportsForRules(cssRules, alreadyLoadedCssUrls, options).then(function(cssImportResult) {
        return inlineCss.loadAndInlineCSSResourcesForRules(cssRules, options).then(function(cssResourcesResult) {
          var errors = cssImportResult.errors.concat(cssResourcesResult.errors), hasChanges = cssImportResult.hasChanges || cssResourcesResult.hasChanges;
          if (hasChanges) {
            styleContent = cssSupport.cssRulesToText(cssRules);
          }
          return {
            hasChanges,
            content: styleContent,
            errors
          };
        });
      });
    };
    var loadAndInlineCssForStyle = function(style, options, alreadyLoadedCssUrls) {
      var styleContent = style.textContent, processExternals = memoizeFunctionOnCaching(
        requestExternalsForStylesheet,
        options
      );
      return processExternals(styleContent, alreadyLoadedCssUrls, options).then(
        function(result) {
          if (result.hasChanges) {
            style.childNodes[0].nodeValue = result.content;
          }
          return util.cloneArray(result.errors);
        }
      );
    };
    var getCssStyleElements = function(doc) {
      var styles = doc.getElementsByTagName("style");
      return Array.prototype.filter.call(styles, function(style) {
        return !style.attributes.type || style.attributes.type.value === "text/css";
      });
    };
    exports.loadAndInlineStyles = function(doc, options) {
      var styles = getCssStyleElements(doc), allErrors = [], alreadyLoadedCssUrls = [], inlineOptions;
      inlineOptions = util.clone(options);
      inlineOptions.baseUrl = inlineOptions.baseUrl || util.getDocumentBaseUrl(doc);
      return Promise.all(
        styles.map(function(style) {
          return loadAndInlineCssForStyle(
            style,
            inlineOptions,
            alreadyLoadedCssUrls
          ).then(function(errors) {
            allErrors = allErrors.concat(errors);
          });
        })
      ).then(function() {
        return allErrors;
      });
    };
    var substituteLinkWithInlineStyle = function(oldLinkNode, styleContent) {
      var parent = oldLinkNode.parentNode, styleNode;
      styleContent = styleContent.trim();
      if (styleContent) {
        styleNode = oldLinkNode.ownerDocument.createElement("style");
        styleNode.type = "text/css";
        styleNode.appendChild(
          oldLinkNode.ownerDocument.createTextNode(styleContent)
        );
        parent.insertBefore(styleNode, oldLinkNode);
      }
      parent.removeChild(oldLinkNode);
    };
    var requestStylesheetAndInlineResources = function(url, options) {
      return util.ajax(url, options).then(function(content) {
        var cssRules = cssSupport.rulesForCssText(content);
        return {
          content,
          cssRules
        };
      }).then(function(result) {
        var hasChangesFromPathAdjustment = inlineCss.adjustPathsOfCssResources(
          url,
          result.cssRules
        );
        return {
          content: result.content,
          cssRules: result.cssRules,
          hasChanges: hasChangesFromPathAdjustment
        };
      }).then(function(result) {
        return inlineCss.loadCSSImportsForRules(result.cssRules, [], options).then(function(cssImportResult) {
          return {
            content: result.content,
            cssRules: result.cssRules,
            hasChanges: result.hasChanges || cssImportResult.hasChanges,
            errors: cssImportResult.errors
          };
        });
      }).then(function(result) {
        return inlineCss.loadAndInlineCSSResourcesForRules(result.cssRules, options).then(function(cssResourcesResult) {
          return {
            content: result.content,
            cssRules: result.cssRules,
            hasChanges: result.hasChanges || cssResourcesResult.hasChanges,
            errors: result.errors.concat(cssResourcesResult.errors)
          };
        });
      }).then(function(result) {
        var content = result.content;
        if (result.hasChanges) {
          content = cssSupport.cssRulesToText(result.cssRules);
        }
        return {
          content,
          errors: result.errors
        };
      });
    };
    var loadLinkedCSS = function(link, options) {
      var cssHref = link.attributes.href.value, documentBaseUrl = util.getDocumentBaseUrl(link.ownerDocument), ajaxOptions = util.clone(options);
      if (!ajaxOptions.baseUrl && documentBaseUrl) {
        ajaxOptions.baseUrl = documentBaseUrl;
      }
      var processStylesheet = memoizeFunctionOnCaching(
        requestStylesheetAndInlineResources,
        options
      );
      return processStylesheet(cssHref, ajaxOptions).then(function(result) {
        return {
          content: result.content,
          errors: util.cloneArray(result.errors)
        };
      });
    };
    var getCssStylesheetLinks = function(doc) {
      var links = doc.getElementsByTagName("link");
      return Array.prototype.filter.call(links, function(link) {
        return link.attributes.rel && link.attributes.rel.value === "stylesheet" && (!link.attributes.type || link.attributes.type.value === "text/css");
      });
    };
    exports.loadAndInlineCssLinks = function(doc, options) {
      var links = getCssStylesheetLinks(doc), errors = [];
      return Promise.all(
        links.map(function(link) {
          return loadLinkedCSS(link, options).then(
            function(result) {
              substituteLinkWithInlineStyle(link, result.content + "\n");
              errors = errors.concat(result.errors);
            },
            function(e) {
              errors.push({
                resourceType: "stylesheet",
                url: e.url,
                msg: "Unable to load stylesheet " + e.url
              });
            }
          );
        })
      ).then(function() {
        return errors;
      });
    };
    exports.loadAndInlineImages = inlineImage.inline;
    exports.loadAndInlineScript = inlineScript.inline;
    exports.inlineReferences = function(doc, options) {
      var allErrors = [], inlineFuncs = [
        exports.loadAndInlineImages,
        exports.loadAndInlineStyles,
        exports.loadAndInlineCssLinks
      ];
      if (options.inlineScripts !== false) {
        inlineFuncs.push(exports.loadAndInlineScript);
      }
      return Promise.all(
        inlineFuncs.map(function(func) {
          return func(doc, options).then(function(errors) {
            allErrors = allErrors.concat(errors);
          });
        })
      ).then(function() {
        return allErrors;
      });
    };
  }
});

// ../../node_modules/.pnpm/rasterizehtml@1.3.1/node_modules/rasterizehtml/dist/rasterizeHTML.js
var require_rasterizeHTML = __commonJS({
  "../../node_modules/.pnpm/rasterizehtml@1.3.1/node_modules/rasterizehtml/dist/rasterizeHTML.js"(exports, module) {
    (function(root, factory) {
      if (root === void 0 && window !== void 0)
        root = window;
      if (typeof define === "function" && define.amd) {
        define(["url", "xmlserializer", "sane-domparser-error", "inlineresources"], function(a0, b1, c2, d3) {
          return root["rasterizeHTML"] = factory(a0, b1, c2, d3);
        });
      } else if (typeof module === "object" && module.exports) {
        module.exports = factory(require_url(), require_xmlserializer(), require_sane_domparser_error(), require_inline());
      } else {
        root["rasterizeHTML"] = factory(root["url"], root["xmlserializer"], root["sanedomparsererror"], root["inlineresources"]);
      }
    })(exports, function(url, xmlserializer, sanedomparsererror, inlineresources) {
      var util = function(url2) {
        "use strict";
        var module2 = {};
        var uniqueIdList = [];
        module2.joinUrl = function(baseUrl, relUrl) {
          if (!baseUrl) {
            return relUrl;
          }
          return url2.resolve(baseUrl, relUrl);
        };
        module2.getConstantUniqueIdFor = function(element) {
          if (uniqueIdList.indexOf(element) < 0) {
            uniqueIdList.push(element);
          }
          return uniqueIdList.indexOf(element);
        };
        module2.clone = function(object) {
          var theClone = {}, i;
          for (i in object) {
            if (object.hasOwnProperty(i)) {
              theClone[i] = object[i];
            }
          }
          return theClone;
        };
        var isObject = function(obj) {
          return typeof obj === "object" && obj !== null;
        };
        var isCanvas = function(obj) {
          return isObject(obj) && Object.prototype.toString.apply(obj).match(/\[object (Canvas|HTMLCanvasElement)\]/i);
        };
        module2.parseOptionalParameters = function(args) {
          var parameters = {
            canvas: null,
            options: {}
          };
          if (args[0] == null || isCanvas(args[0])) {
            parameters.canvas = args[0] || null;
            parameters.options = module2.clone(args[1]);
          } else {
            parameters.options = module2.clone(args[0]);
          }
          return parameters;
        };
        return module2;
      }(url);
      var proxies = function(util2) {
        "use strict";
        var module2 = {};
        var monkeyPatchInstanceMethod = function(object, methodName, proxyFunc) {
          var originalFunc = object[methodName];
          object[methodName] = function() {
            var args = Array.prototype.slice.call(arguments);
            return proxyFunc.apply(this, [args, originalFunc]);
          };
          return originalFunc;
        };
        module2.baseUrlRespectingXhr = function(XHRObject, baseUrl) {
          var xhrConstructor = function() {
            var xhr = new XHRObject();
            monkeyPatchInstanceMethod(
              xhr,
              "open",
              function(args, originalOpen) {
                var method = args.shift(), url2 = args.shift(), joinedUrl = util2.joinUrl(baseUrl, url2);
                return originalOpen.apply(
                  this,
                  [method, joinedUrl].concat(args)
                );
              }
            );
            return xhr;
          };
          return xhrConstructor;
        };
        module2.finishNotifyingXhr = function(XHRObject) {
          var totalXhrCount = 0, doneXhrCount = 0, waitingForPendingToClose = false;
          var checkAllRequestsFinished;
          var promise = new Promise(function(resolve) {
            checkAllRequestsFinished = function() {
              var pendingXhrCount = totalXhrCount - doneXhrCount;
              if (pendingXhrCount <= 0 && waitingForPendingToClose) {
                resolve({ totalCount: totalXhrCount });
              }
            };
          });
          var xhrConstructor = function() {
            var xhr = new XHRObject();
            monkeyPatchInstanceMethod(xhr, "send", function(_, originalSend) {
              totalXhrCount += 1;
              return originalSend.apply(this, arguments);
            });
            xhr.addEventListener("load", function() {
              doneXhrCount += 1;
              checkAllRequestsFinished();
            });
            return xhr;
          };
          xhrConstructor.waitForRequestsToFinish = function() {
            waitingForPendingToClose = true;
            checkAllRequestsFinished();
            return promise;
          };
          return xhrConstructor;
        };
        return module2;
      }(util);
      var documentUtil = function() {
        "use strict";
        var module2 = {};
        var asArray = function(arrayLike) {
          return Array.prototype.slice.call(arrayLike);
        };
        module2.addClassName = function(element, className) {
          element.className += " " + className;
        };
        module2.addClassNameRecursively = function(element, className) {
          module2.addClassName(element, className);
          if (element.parentNode !== element.ownerDocument) {
            module2.addClassNameRecursively(element.parentNode, className);
          }
        };
        var changeCssRule = function(rule, newRuleText) {
          var styleSheet = rule.parentStyleSheet, ruleIdx = asArray(styleSheet.cssRules).indexOf(rule);
          styleSheet.insertRule(newRuleText, ruleIdx + 1);
          styleSheet.deleteRule(ruleIdx);
        };
        var updateRuleSelector = function(rule, updatedSelector) {
          var styleDefinitions = rule.cssText.replace(/^[^\{]+/, ""), newRule = updatedSelector + " " + styleDefinitions;
          changeCssRule(rule, newRule);
        };
        var cssRulesToText = function(cssRules) {
          return asArray(cssRules).reduce(function(cssText, rule) {
            return cssText + rule.cssText;
          }, "");
        };
        var rewriteStyleContent = function(styleElement) {
          styleElement.textContent = cssRulesToText(styleElement.sheet.cssRules);
        };
        var addSheetPropertyToSvgStyleElement = function(svgStyleElement) {
          var doc = document.implementation.createHTMLDocument(""), cssStyleElement = document.createElement("style");
          cssStyleElement.textContent = svgStyleElement.textContent;
          doc.body.appendChild(cssStyleElement);
          svgStyleElement.sheet = cssStyleElement.sheet;
        };
        var matchingSimpleSelectorsRegex = function(simpleSelectorList) {
          return "((?:^|[^.#:\\w])|(?=\\W))(" + simpleSelectorList.join("|") + // one out of the given simple selectors
          ")(?=\\W|$)";
        };
        var replaceSimpleSelectorsBy = function(element, simpleSelectorList, caseInsensitiveReplaceFunc) {
          var selectorRegex = matchingSimpleSelectorsRegex(simpleSelectorList);
          asArray(element.querySelectorAll("style")).forEach(function(styleElement) {
            if (typeof styleElement.sheet === "undefined") {
              addSheetPropertyToSvgStyleElement(styleElement);
            }
            var matchingRules = asArray(styleElement.sheet.cssRules).filter(
              function(rule) {
                return rule.selectorText && new RegExp(selectorRegex, "i").test(rule.selectorText);
              }
            );
            if (matchingRules.length) {
              matchingRules.forEach(function(rule) {
                var newSelector = rule.selectorText.replace(
                  new RegExp(selectorRegex, "gi"),
                  function(_, prefixMatch, selectorMatch) {
                    return prefixMatch + caseInsensitiveReplaceFunc(selectorMatch);
                  }
                );
                if (newSelector !== rule.selectorText) {
                  updateRuleSelector(rule, newSelector);
                }
              });
              rewriteStyleContent(styleElement);
            }
          });
        };
        module2.rewriteCssSelectorWith = function(element, oldSelector, newSelector) {
          replaceSimpleSelectorsBy(element, [oldSelector], function() {
            return newSelector;
          });
        };
        module2.lowercaseCssTypeSelectors = function(element, matchingTagNames) {
          replaceSimpleSelectorsBy(element, matchingTagNames, function(match) {
            return match.toLowerCase();
          });
        };
        module2.findHtmlOnlyNodeNames = function(element) {
          var treeWalker = element.ownerDocument.createTreeWalker(
            element,
            NodeFilter.SHOW_ELEMENT
          ), htmlNodeNames = {}, nonHtmlNodeNames = {}, currentTagName;
          do {
            currentTagName = treeWalker.currentNode.tagName.toLowerCase();
            if (treeWalker.currentNode.namespaceURI === "http://www.w3.org/1999/xhtml") {
              htmlNodeNames[currentTagName] = true;
            } else {
              nonHtmlNodeNames[currentTagName] = true;
            }
          } while (treeWalker.nextNode());
          return Object.keys(htmlNodeNames).filter(function(tagName) {
            return !nonHtmlNodeNames[tagName];
          });
        };
        return module2;
      }();
      var documentHelper = function(documentUtil2) {
        "use strict";
        var module2 = {};
        var asArray = function(arrayLike) {
          return Array.prototype.slice.call(arrayLike);
        };
        var cascadingAction = {
          active: true,
          hover: true,
          focus: false,
          target: false
        };
        module2.fakeUserAction = function(element, selector, action) {
          var elem = element.querySelector(selector), pseudoClass = ":" + action, fakeActionClass = "rasterizehtml" + action;
          if (!elem) {
            return;
          }
          if (cascadingAction[action]) {
            documentUtil2.addClassNameRecursively(elem, fakeActionClass);
          } else {
            documentUtil2.addClassName(elem, fakeActionClass);
          }
          documentUtil2.rewriteCssSelectorWith(
            element,
            pseudoClass,
            "." + fakeActionClass
          );
        };
        module2.persistInputValues = function(doc) {
          var inputs = doc.querySelectorAll("input"), textareas = doc.querySelectorAll("textarea"), isCheckable = function(input) {
            return input.type === "checkbox" || input.type === "radio";
          };
          asArray(inputs).filter(isCheckable).forEach(function(input) {
            if (input.checked) {
              input.setAttribute("checked", "");
            } else {
              input.removeAttribute("checked");
            }
          });
          asArray(inputs).filter(function(input) {
            return !isCheckable(input);
          }).forEach(function(input) {
            input.setAttribute("value", input.value);
          });
          asArray(textareas).forEach(function(textarea) {
            textarea.textContent = textarea.value;
          });
        };
        module2.rewriteTagNameSelectorsToLowerCase = function(element) {
          documentUtil2.lowercaseCssTypeSelectors(
            element,
            documentUtil2.findHtmlOnlyNodeNames(element)
          );
        };
        return module2;
      }(documentUtil);
      var browser = function(util2, proxies2, sanedomparsererror2, theWindow) {
        "use strict";
        var module2 = {};
        var createHiddenElement = function(doc, tagName, width, height) {
          var element = doc.createElement(tagName);
          element.style.visibility = "hidden";
          element.style.width = width + "px";
          element.style.height = height + "px";
          element.style.position = "absolute";
          element.style.top = -1e4 - height + "px";
          element.style.left = -1e4 - width + "px";
          doc.getElementsByTagName("body")[0].appendChild(element);
          return element;
        };
        var wait = function(timeout) {
          if (timeout > 0) {
            return new Promise(function(resolve) {
              setTimeout(resolve, timeout);
            });
          } else {
            return Promise.resolve();
          }
        };
        module2.executeJavascript = function(element, options) {
          return new Promise(function(resolve) {
            var iframe = createHiddenElement(
              theWindow.document,
              "iframe",
              options.width,
              options.height
            ), html = element.outerHTML, iframeErrorsMessages = [], executeJsTimeout = options.executeJsTimeout || 0;
            var cleanUp = function() {
              theWindow.document.getElementsByTagName("body")[0].removeChild(iframe);
            };
            var doResolve = function() {
              var doc = iframe.contentDocument;
              resolve({
                document: doc,
                errors: iframeErrorsMessages,
                cleanUp
              });
            };
            var xhr = iframe.contentWindow.XMLHttpRequest, finishNotifyXhrProxy = proxies2.finishNotifyingXhr(xhr), baseUrlXhrProxy = proxies2.baseUrlRespectingXhr(
              finishNotifyXhrProxy,
              options.baseUrl
            );
            iframe.onload = function() {
              wait(executeJsTimeout).then(finishNotifyXhrProxy.waitForRequestsToFinish).then(doResolve);
            };
            iframe.contentDocument.open();
            iframe.contentWindow.XMLHttpRequest = baseUrlXhrProxy;
            iframe.contentWindow.onerror = function(msg) {
              iframeErrorsMessages.push({
                resourceType: "scriptExecution",
                msg
              });
            };
            iframe.contentDocument.write("<!DOCTYPE html>");
            iframe.contentDocument.write(html);
            iframe.contentDocument.close();
          });
        };
        var createHiddenSandboxedIFrame = function(doc, width, height) {
          var iframe = doc.createElement("iframe");
          iframe.style.width = width + "px";
          iframe.style.height = height + "px";
          iframe.style.visibility = "hidden";
          iframe.style.position = "absolute";
          iframe.style.top = -1e4 - height + "px";
          iframe.style.left = -1e4 - width + "px";
          iframe.style.borderWidth = 0;
          iframe.sandbox = "allow-same-origin";
          iframe.scrolling = "no";
          return iframe;
        };
        var createIframeWithSizeAtZoomLevel1 = function(width, height, zoom) {
          var scaledViewportWidth = Math.floor(width / zoom), scaledViewportHeight = Math.floor(height / zoom);
          return createHiddenSandboxedIFrame(
            theWindow.document,
            scaledViewportWidth,
            scaledViewportHeight
          );
        };
        var calculateZoomedContentSizeAndRoundUp = function(actualViewport, requestedWidth, requestedHeight, zoom) {
          return {
            width: Math.max(actualViewport.width * zoom, requestedWidth),
            height: Math.max(actualViewport.height * zoom, requestedHeight)
          };
        };
        var selectElementOrDescendant = function(element, selector) {
          var descendant = element.querySelector(selector);
          if (descendant) {
            return descendant;
          } else if (element.ownerDocument.querySelector(selector) === element) {
            return element;
          }
          throw {
            message: "Clipping selector not found"
          };
        };
        var calculateContentSize = function(rootElement, selector, requestedWidth, requestedHeight, zoom) {
          var actualViewportWidth = Math.max(
            rootElement.scrollWidth,
            rootElement.clientWidth
          ), actualViewportHeight = Math.max(
            rootElement.scrollHeight,
            rootElement.clientHeight
          ), top, left, originalWidth, originalHeight, rootFontSize, element, rect, contentSize;
          if (selector) {
            element = selectElementOrDescendant(rootElement, selector);
            rect = element.getBoundingClientRect();
            top = rect.top;
            left = rect.left;
            originalWidth = rect.width;
            originalHeight = rect.height;
          } else {
            top = 0;
            left = 0;
            originalWidth = actualViewportWidth;
            originalHeight = actualViewportHeight;
          }
          contentSize = calculateZoomedContentSizeAndRoundUp(
            {
              width: originalWidth,
              height: originalHeight
            },
            requestedWidth,
            requestedHeight,
            zoom
          );
          rootFontSize = theWindow.getComputedStyle(
            rootElement.ownerDocument.documentElement
          ).fontSize;
          return {
            left,
            top,
            width: contentSize.width,
            height: contentSize.height,
            viewportWidth: actualViewportWidth,
            viewportHeight: actualViewportHeight,
            rootFontSize
          };
        };
        var findCorrelatingElement = function(element, documentClone) {
          var tagName = element.tagName;
          return documentClone.querySelector(tagName);
        };
        var elementToFullHtmlDocument = function(element) {
          var tagName = element.tagName.toLowerCase();
          if (tagName === "html" || tagName === "body") {
            return element.outerHTML;
          }
          return '<body style="margin: 0;">' + element.outerHTML + "</body>";
        };
        module2.calculateDocumentContentSize = function(element, options) {
          return new Promise(function(resolve, reject) {
            var zoom = options.zoom || 1, iframe;
            iframe = createIframeWithSizeAtZoomLevel1(
              options.width,
              options.height,
              zoom
            );
            theWindow.document.getElementsByTagName("body")[0].appendChild(iframe);
            iframe.onload = function() {
              var doc = iframe.contentDocument, size;
              try {
                size = calculateContentSize(
                  findCorrelatingElement(element, doc),
                  options.clip,
                  options.width,
                  options.height,
                  zoom
                );
                resolve(size);
              } catch (e) {
                reject(e);
              } finally {
                theWindow.document.getElementsByTagName("body")[0].removeChild(iframe);
              }
            };
            iframe.contentDocument.open();
            iframe.contentDocument.write("<!DOCTYPE html>");
            iframe.contentDocument.write(elementToFullHtmlDocument(element));
            iframe.contentDocument.close();
          });
        };
        module2.parseHtmlFragment = function(htmlFragment) {
          var doc = theWindow.document.implementation.createHTMLDocument("");
          doc.documentElement.innerHTML = htmlFragment;
          var element = doc.querySelector("body").firstChild;
          if (!element) {
            throw "Invalid source";
          }
          return element;
        };
        var addHTMLTagAttributes = function(doc, html) {
          var attributeMatch = /<html((?:\s+[^>]*)?)>/im.exec(html), helperDoc = theWindow.document.implementation.createHTMLDocument(""), htmlTagSubstitute, i, elementSubstitute, attribute;
          if (!attributeMatch) {
            return;
          }
          htmlTagSubstitute = "<div" + attributeMatch[1] + "></div>";
          helperDoc.documentElement.innerHTML = htmlTagSubstitute;
          elementSubstitute = helperDoc.querySelector("div");
          for (i = 0; i < elementSubstitute.attributes.length; i++) {
            attribute = elementSubstitute.attributes[i];
            doc.documentElement.setAttribute(attribute.name, attribute.value);
          }
        };
        module2.parseHTML = function(html) {
          var doc = theWindow.document.implementation.createHTMLDocument("");
          doc.documentElement.innerHTML = html;
          addHTMLTagAttributes(doc, html);
          return doc;
        };
        var failOnInvalidSource = function(doc) {
          try {
            return sanedomparsererror2.failOnParseError(doc);
          } catch (e) {
            throw {
              message: "Invalid source",
              originalError: e
            };
          }
        };
        module2.validateXHTML = function(xhtml) {
          var p = new DOMParser(), doc = p.parseFromString(xhtml, "application/xml");
          failOnInvalidSource(doc);
        };
        var lastCacheDate = null;
        var getUncachableURL = function(url2, cache) {
          if (cache === "none" || cache === "repeated") {
            if (lastCacheDate === null || cache !== "repeated") {
              lastCacheDate = Date.now();
            }
            return url2 + "?_=" + lastCacheDate;
          } else {
            return url2;
          }
        };
        var doDocumentLoad = function(url2, options) {
          return new Promise(function(resolve, reject) {
            var xhr = new window.XMLHttpRequest(), joinedUrl = util2.joinUrl(options.baseUrl, url2), augmentedUrl = getUncachableURL(joinedUrl, options.cache), doReject = function(e) {
              reject({
                message: "Unable to load page",
                originalError: e
              });
            };
            xhr.addEventListener(
              "load",
              function() {
                if (xhr.status === 200 || xhr.status === 0) {
                  resolve(xhr.responseXML);
                } else {
                  doReject(xhr.statusText);
                }
              },
              false
            );
            xhr.addEventListener(
              "error",
              function(e) {
                doReject(e);
              },
              false
            );
            try {
              xhr.open("GET", augmentedUrl, true);
              xhr.responseType = "document";
              xhr.send(null);
            } catch (e) {
              doReject(e);
            }
          });
        };
        module2.loadDocument = function(url2, options) {
          return doDocumentLoad(url2, options).then(function(doc) {
            return failOnInvalidSource(doc);
          });
        };
        return module2;
      }(util, proxies, sanedomparsererror, window);
      var svg2image = function(window2) {
        "use strict";
        var module2 = {};
        var urlForSvg = function(svg, useBlobs) {
          if (useBlobs) {
            return URL.createObjectURL(
              new Blob([svg], { type: "image/svg+xml" })
            );
          } else {
            return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
          }
        };
        var cleanUpUrl = function(url2) {
          if (url2 instanceof Blob) {
            URL.revokeObjectURL(url2);
          }
        };
        var simpleForeignObjectSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"><foreignObject></foreignObject></svg>';
        var supportsReadingObjectFromCanvas = function(url2) {
          return new Promise(function(resolve, reject) {
            var canvas = document.createElement("canvas"), image = new Image();
            image.onload = function() {
              var context = canvas.getContext("2d");
              try {
                context.drawImage(image, 0, 0);
                canvas.toDataURL("image/png");
                resolve(true);
              } catch (e) {
                resolve(false);
              }
            };
            image.onerror = reject;
            image.src = url2;
          });
        };
        var readingBackFromCanvasBenefitsFromOldSchoolDataUris = function() {
          var blobUrl = urlForSvg(simpleForeignObjectSvg, true);
          return supportsReadingObjectFromCanvas(blobUrl).then(
            function(supportsReadingFromBlobs) {
              cleanUpUrl(blobUrl);
              if (supportsReadingFromBlobs) {
                return false;
              }
              return supportsReadingObjectFromCanvas(
                urlForSvg(simpleForeignObjectSvg, false)
              ).then(function(s) {
                return s;
              });
            },
            function() {
              return false;
            }
          );
        };
        var supportsBlobBuilding = function() {
          if (window2.Blob) {
            try {
              new Blob(["<b></b>"], { type: "text/xml" });
              return true;
            } catch (err) {
            }
          }
          return false;
        };
        var checkBlobSupport = function() {
          return new Promise(function(resolve, reject) {
            if (supportsBlobBuilding() && window2.URL) {
              readingBackFromCanvasBenefitsFromOldSchoolDataUris().then(
                function(doesBenefit) {
                  resolve(!doesBenefit);
                },
                function() {
                  reject();
                }
              );
            } else {
              resolve(false);
            }
          });
        };
        var checkForBlobsResult;
        var checkForBlobs = function() {
          if (checkForBlobsResult === void 0) {
            checkForBlobsResult = checkBlobSupport();
          }
          return checkForBlobsResult;
        };
        var buildImageUrl = function(svg) {
          return checkForBlobs().then(function(useBlobs) {
            return urlForSvg(svg, useBlobs);
          });
        };
        module2.renderSvg = function(svg) {
          return new Promise(function(resolve, reject) {
            var url2, image, resetEventHandlers = function() {
              image.onload = null;
              image.onerror = null;
            }, cleanUp = function() {
              if (url2) {
                cleanUpUrl(url2);
              }
            };
            image = new Image();
            image.onload = function() {
              resetEventHandlers();
              cleanUp();
              resolve(image);
            };
            image.onerror = function() {
              cleanUp();
              reject();
            };
            buildImageUrl(svg).then(function(imageUrl) {
              url2 = imageUrl;
              image.src = url2;
            }, reject);
          });
        };
        return module2;
      }(window);
      var document2svg = function(util2, browser2, documentHelper2, xmlserializer2) {
        "use strict";
        var module2 = {};
        var svgAttributes = function(size, zoom) {
          var zoomFactor = zoom || 1;
          var attributes = {
            width: size.width,
            height: size.height,
            "font-size": size.rootFontSize
          };
          if (zoomFactor !== 1) {
            attributes.style = "transform:scale(" + zoomFactor + "); transform-origin: 0 0;";
          }
          return attributes;
        };
        var foreignObjectAttributes = function(size) {
          var closestScaledWith, closestScaledHeight, offsetX, offsetY;
          closestScaledWith = Math.round(size.viewportWidth);
          closestScaledHeight = Math.round(size.viewportHeight);
          offsetX = -size.left;
          offsetY = -size.top;
          var attributes = {
            x: offsetX,
            y: offsetY,
            width: closestScaledWith,
            height: closestScaledHeight
          };
          return attributes;
        };
        var workAroundCollapsingMarginsAcrossSVGElementInWebKitLike = function(attributes) {
          var style = attributes.style || "";
          attributes.style = style + "float: left;";
        };
        var workAroundSafariSometimesNotShowingExternalResources = function(attributes) {
          attributes.externalResourcesRequired = true;
        };
        var workAroundChromeShowingScrollbarsUnderLinuxIfHtmlIsOverflowScroll = function() {
          return '<style scoped="">html::-webkit-scrollbar { display: none; }</style>';
        };
        var serializeAttributes = function(attributes) {
          var keys = Object.keys(attributes);
          if (!keys.length) {
            return "";
          }
          return " " + keys.map(function(key) {
            return key + '="' + attributes[key] + '"';
          }).join(" ");
        };
        var convertElementToSvg = function(element, size, zoomFactor) {
          var xhtml = xmlserializer2.serializeToString(element);
          browser2.validateXHTML(xhtml);
          var foreignObjectAttrs = foreignObjectAttributes(size);
          workAroundCollapsingMarginsAcrossSVGElementInWebKitLike(
            foreignObjectAttrs
          );
          workAroundSafariSometimesNotShowingExternalResources(
            foreignObjectAttrs
          );
          return '<svg xmlns="http://www.w3.org/2000/svg"' + serializeAttributes(svgAttributes(size, zoomFactor)) + ">" + workAroundChromeShowingScrollbarsUnderLinuxIfHtmlIsOverflowScroll() + "<foreignObject" + serializeAttributes(foreignObjectAttrs) + ">" + xhtml + "</foreignObject></svg>";
        };
        module2.getSvgForDocument = function(element, size, zoomFactor) {
          documentHelper2.rewriteTagNameSelectorsToLowerCase(element);
          return convertElementToSvg(element, size, zoomFactor);
        };
        module2.drawDocumentAsSvg = function(element, options) {
          ["hover", "active", "focus", "target"].forEach(function(action) {
            if (options[action]) {
              documentHelper2.fakeUserAction(element, options[action], action);
            }
          });
          return browser2.calculateDocumentContentSize(element, options).then(function(size) {
            return module2.getSvgForDocument(element, size, options.zoom);
          });
        };
        return module2;
      }(util, browser, documentHelper, xmlserializer);
      var rasterize = function(util2, browser2, documentHelper2, document2svg2, svg2image2, inlineresources2) {
        "use strict";
        var module2 = {};
        var generalDrawError = function(e) {
          return {
            message: "Error rendering page",
            originalError: e
          };
        };
        var drawSvgAsImg = function(svg) {
          return svg2image2.renderSvg(svg).then(
            function(image) {
              return {
                image,
                svg
              };
            },
            function(e) {
              throw generalDrawError(e);
            }
          );
        };
        var drawImageOnCanvas = function(image, canvas) {
          try {
            canvas.getContext("2d").drawImage(image, 0, 0);
          } catch (e) {
            throw generalDrawError(e);
          }
        };
        var doDraw = function(element, canvas, options) {
          return document2svg2.drawDocumentAsSvg(element, options).then(drawSvgAsImg).then(function(result) {
            if (canvas) {
              drawImageOnCanvas(result.image, canvas);
            }
            return result;
          });
        };
        var operateJavaScriptOnDocument = function(element, options) {
          return browser2.executeJavascript(element, options).then(function(result) {
            var document2 = result.document;
            documentHelper2.persistInputValues(document2);
            return {
              document: document2,
              errors: result.errors,
              cleanUp: result.cleanUp
            };
          });
        };
        module2.rasterize = function(element, canvas, options) {
          var inlineOptions;
          inlineOptions = util2.clone(options);
          inlineOptions.inlineScripts = options.executeJs === true;
          return inlineresources2.inlineReferences(element, inlineOptions).then(function(errors) {
            if (options.executeJs) {
              return operateJavaScriptOnDocument(element, options).then(
                function(result) {
                  return {
                    element: result.document.documentElement,
                    errors: errors.concat(result.errors),
                    cleanUp: result.cleanUp
                  };
                }
              );
            } else {
              return {
                element,
                errors,
                cleanUp: function() {
                }
              };
            }
          }).then(function(result) {
            return doDraw(result.element, canvas, options).then(function(drawResult) {
              result.cleanUp();
              return {
                image: drawResult.image,
                svg: drawResult.svg,
                errors: result.errors
              };
            });
          });
        };
        return module2;
      }(util, browser, documentHelper, document2svg, svg2image, inlineresources);
      var rasterizeHTML = function(util2, browser2, rasterize2) {
        "use strict";
        var module2 = {};
        var getViewportSize = function(canvas, options) {
          var defaultWidth = 300, defaultHeight = 200, fallbackWidth = canvas ? canvas.width : defaultWidth, fallbackHeight = canvas ? canvas.height : defaultHeight, width = options.width !== void 0 ? options.width : fallbackWidth, height = options.height !== void 0 ? options.height : fallbackHeight;
          return {
            width,
            height
          };
        };
        var constructOptions = function(params) {
          var viewport = getViewportSize(params.canvas, params.options), options;
          options = util2.clone(params.options);
          options.width = viewport.width;
          options.height = viewport.height;
          return options;
        };
        module2.drawDocument = function() {
          var doc = arguments[0], optionalArguments = Array.prototype.slice.call(arguments, 1), params = util2.parseOptionalParameters(optionalArguments);
          var element = doc.documentElement ? doc.documentElement : doc;
          return rasterize2.rasterize(
            element,
            params.canvas,
            constructOptions(params)
          );
        };
        var drawHTML = function(html, canvas, options) {
          var doc = browser2.parseHTML(html);
          return module2.drawDocument(doc, canvas, options);
        };
        module2.drawHTML = function() {
          var html = arguments[0], optionalArguments = Array.prototype.slice.call(arguments, 1), params = util2.parseOptionalParameters(optionalArguments);
          return drawHTML(html, params.canvas, params.options);
        };
        var workAroundFirefoxNotLoadingStylesheetStyles = function(doc, url2, options) {
          var d = document.implementation.createHTMLDocument("");
          d.replaceChild(doc.documentElement, d.documentElement);
          var extendedOptions = options ? util2.clone(options) : {};
          if (!options.baseUrl) {
            extendedOptions.baseUrl = url2;
          }
          return {
            document: d,
            options: extendedOptions
          };
        };
        var drawURL = function(url2, canvas, options) {
          return browser2.loadDocument(url2, options).then(function(doc) {
            var workaround = workAroundFirefoxNotLoadingStylesheetStyles(
              doc,
              url2,
              options
            );
            return module2.drawDocument(
              workaround.document,
              canvas,
              workaround.options
            );
          });
        };
        module2.drawURL = function() {
          var url2 = arguments[0], optionalArguments = Array.prototype.slice.call(arguments, 1), params = util2.parseOptionalParameters(optionalArguments);
          return drawURL(url2, params.canvas, params.options);
        };
        return module2;
      }(util, browser, rasterize);
      return rasterizeHTML;
    });
  }
});
export default require_rasterizeHTML();
/*! Bundled license information:

punycode/punycode.js:
  (*! https://mths.be/punycode v1.4.1 by @mathias *)

rasterizehtml/dist/rasterizeHTML.js:
  (*! rasterizeHTML.js - v1.3.1 - 2022-01-16
  * http://www.github.com/cburgmer/rasterizeHTML.js
  * Copyright (c) 2022 Christoph Burgmer; Licensed MIT *)
*/
//# sourceMappingURL=rasterizehtml.js.map
