import {
  EventStreamContentType,
  fetchEventSource
} from "/node_modules/.vite/deps/@microsoft_fetch-event-source.js?v=b331fb12";
import { convertToBotMessage } from "/@fs/C:/Users/Pradeep/Desktop/fibonalabs_app_pdf/packages/shared/src/lib/utils/index.ts";
class RetriableError extends Error {
}
class FatalError extends Error {
}
export async function createNewChat(title) {
  const response = await fetch("/api/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ title })
  });
  if (!response.ok) {
    throw new Error("Failed to create chat");
  }
  const { chatId, timestamp } = await response.json();
  return { chatId, timestamp };
}
export async function saveUserMessage(chatId, message) {
  const response = await fetch("/api/chat", {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      action: "addUserMessage",
      chatId,
      message
    })
  });
  if (!response.ok) {
    throw new Error("Failed to save user message");
  }
}
export async function saveBotMessage(chatId, text, resources) {
  const response = await fetch("/api/chat", {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      action: "addBotMessage",
      chatId,
      message: text,
      resources
    })
  });
  if (!response.ok) {
    throw new Error("Failed to save bot message");
  }
  const message = await response.json();
  return convertToBotMessage(message);
}
export async function updateRating(chatId, timestamp, rating) {
  const response = await fetch("/api/chat", {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      action: "updateRating",
      chatId,
      timestamp,
      rating
    })
  });
  if (!response.ok) {
    throw new Error("Failed to update feedback");
  }
}
export async function updateReview(chatId, timestamp, review) {
  const response = await fetch("/api/chat", {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      action: "updateReview",
      chatId,
      timestamp,
      review
    })
  });
  if (!response.ok) {
    throw new Error("Failed to update feedback");
  }
}
export async function saveChatTitle(chatId, title, timestamp) {
  const response = await fetch("/api/chat", {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      timestamp,
      chatId,
      title
    })
  });
  if (!response.ok) {
    throw new Error("Failed to update chat title");
  }
}
export function createPayload(config, question, messages) {
  const payload = {
    query: question,
    creativity: config.creativity,
    resourceLimit: config.resourceLimit,
    advanced: {
      expression: config.advancedFilterExpression
    },
    stream: true
  };
  const contextElements = [];
  for (let i = 0; i < messages.length - 1; i = i + 2) {
    const userMessage = messages[i];
    const botMessage = messages[i + 1];
    contextElements.push({
      user: userMessage.text,
      bot: botMessage.text
    });
  }
  if (contextElements.length > 0) {
    payload.context = contextElements;
  }
  return payload;
}
export async function fetchChatResponse(payload, onMessage) {
  const ctrl = new AbortController();
  return fetchEventSource("/api/chat/stream", {
    signal: ctrl.signal,
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload),
    async onopen(response) {
      if (response.ok && response.headers.get("content-type") === EventStreamContentType) {
        return;
      } else if (response.status >= 400 && response.status < 500 && response.status !== 429) {
        throw new FatalError();
      } else {
        throw new RetriableError();
      }
    },
    onmessage(msg) {
      if (msg.event === "FatalError") {
        throw new FatalError(msg.data);
      }
      if (msg.event === "partial" || msg.event === "final") {
        onMessage(msg);
      }
    },
    onclose() {
      ctrl.abort();
    },
    onerror(err) {
      throw err;
    }
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYXQtc2VydmljZS1oZWxwZXJzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgRXZlbnRTdHJlYW1Db250ZW50VHlwZSxcclxuICBmZXRjaEV2ZW50U291cmNlLFxyXG4gIHR5cGUgRXZlbnRTb3VyY2VNZXNzYWdlLFxyXG59IGZyb20gJ0BtaWNyb3NvZnQvZmV0Y2gtZXZlbnQtc291cmNlJztcclxuaW1wb3J0IHR5cGUgeyBDaGF0Q29uZmlnLCBDaGF0UmVxdWVzdFBheWxvYWQsIENvbnRleHRFbGVtZW50LCBEQkJvdE1lc3NhZ2UsIE1lc3NhZ2UgfSBmcm9tICd0eXBlcyc7XHJcbmltcG9ydCB7IGNvbnZlcnRUb0JvdE1lc3NhZ2UgfSBmcm9tICcuLi91dGlscyc7XHJcblxyXG5jbGFzcyBSZXRyaWFibGVFcnJvciBleHRlbmRzIEVycm9yIHt9XHJcbmNsYXNzIEZhdGFsRXJyb3IgZXh0ZW5kcyBFcnJvciB7fVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZU5ld0NoYXQodGl0bGU6IHN0cmluZykge1xyXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJy9hcGkvY2hhdCcsIHtcclxuICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgaGVhZGVyczoge1xyXG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgfSxcclxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdGl0bGUgfSksXHJcbiAgfSk7XHJcblxyXG4gIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIGNyZWF0ZSBjaGF0Jyk7XHJcbiAgfVxyXG5cclxuICBjb25zdCB7IGNoYXRJZCwgdGltZXN0YW1wIH0gPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgcmV0dXJuIHsgY2hhdElkLCB0aW1lc3RhbXAgfTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVVc2VyTWVzc2FnZShjaGF0SWQ6IHN0cmluZywgbWVzc2FnZTogc3RyaW5nKSB7XHJcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCgnL2FwaS9jaGF0Jywge1xyXG4gICAgbWV0aG9kOiAnUEFUQ0gnLFxyXG4gICAgaGVhZGVyczoge1xyXG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgfSxcclxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgYWN0aW9uOiAnYWRkVXNlck1lc3NhZ2UnLFxyXG4gICAgICBjaGF0SWQsXHJcbiAgICAgIG1lc3NhZ2UsXHJcbiAgICB9KSxcclxuICB9KTtcclxuXHJcbiAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQgdG8gc2F2ZSB1c2VyIG1lc3NhZ2UnKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlQm90TWVzc2FnZTxUPihjaGF0SWQ6IHN0cmluZywgdGV4dDogc3RyaW5nLCByZXNvdXJjZXM6IFRbXSkge1xyXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJy9hcGkvY2hhdCcsIHtcclxuICAgIG1ldGhvZDogJ1BBVENIJyxcclxuICAgIGhlYWRlcnM6IHtcclxuICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgIH0sXHJcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgIGFjdGlvbjogJ2FkZEJvdE1lc3NhZ2UnLFxyXG4gICAgICBjaGF0SWQsXHJcbiAgICAgIG1lc3NhZ2U6IHRleHQsXHJcbiAgICAgIHJlc291cmNlcyxcclxuICAgIH0pLFxyXG4gIH0pO1xyXG5cclxuICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byBzYXZlIGJvdCBtZXNzYWdlJyk7XHJcbiAgfVxyXG5cclxuICBjb25zdCBtZXNzYWdlID0gKGF3YWl0IHJlc3BvbnNlLmpzb24oKSkgYXMgREJCb3RNZXNzYWdlPFQ+O1xyXG4gIHJldHVybiBjb252ZXJ0VG9Cb3RNZXNzYWdlKG1lc3NhZ2UpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlUmF0aW5nKGNoYXRJZDogc3RyaW5nLCB0aW1lc3RhbXA6IG51bWJlciwgcmF0aW5nOiBudW1iZXIpIHtcclxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKCcvYXBpL2NoYXQnLCB7XHJcbiAgICBtZXRob2Q6ICdQQVRDSCcsXHJcbiAgICBoZWFkZXJzOiB7XHJcbiAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICB9LFxyXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICBhY3Rpb246ICd1cGRhdGVSYXRpbmcnLFxyXG4gICAgICBjaGF0SWQsXHJcbiAgICAgIHRpbWVzdGFtcCxcclxuICAgICAgcmF0aW5nLFxyXG4gICAgfSksXHJcbiAgfSk7XHJcblxyXG4gIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIHVwZGF0ZSBmZWVkYmFjaycpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVJldmlldyhjaGF0SWQ6IHN0cmluZywgdGltZXN0YW1wOiBudW1iZXIsIHJldmlldzogc3RyaW5nKSB7XHJcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCgnL2FwaS9jaGF0Jywge1xyXG4gICAgbWV0aG9kOiAnUEFUQ0gnLFxyXG4gICAgaGVhZGVyczoge1xyXG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgfSxcclxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgYWN0aW9uOiAndXBkYXRlUmV2aWV3JyxcclxuICAgICAgY2hhdElkLFxyXG4gICAgICB0aW1lc3RhbXAsXHJcbiAgICAgIHJldmlldyxcclxuICAgIH0pLFxyXG4gIH0pO1xyXG5cclxuICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byB1cGRhdGUgZmVlZGJhY2snKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlQ2hhdFRpdGxlKGNoYXRJZDogc3RyaW5nLCB0aXRsZTogc3RyaW5nLCB0aW1lc3RhbXA6IG51bWJlcikge1xyXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJy9hcGkvY2hhdCcsIHtcclxuICAgIG1ldGhvZDogJ1BBVENIJyxcclxuICAgIGhlYWRlcnM6IHtcclxuICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgIH0sXHJcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgIHRpbWVzdGFtcCxcclxuICAgICAgY2hhdElkLFxyXG4gICAgICB0aXRsZSxcclxuICAgIH0pLFxyXG4gIH0pO1xyXG5cclxuICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byB1cGRhdGUgY2hhdCB0aXRsZScpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVBheWxvYWQ8VD4oXHJcbiAgY29uZmlnOiBDaGF0Q29uZmlnLFxyXG4gIHF1ZXN0aW9uOiBzdHJpbmcsXHJcbiAgbWVzc2FnZXM6IE1lc3NhZ2U8VD5bXVxyXG4pOiBDaGF0UmVxdWVzdFBheWxvYWQge1xyXG4gIGNvbnN0IHBheWxvYWQ6IENoYXRSZXF1ZXN0UGF5bG9hZCA9IHtcclxuICAgIHF1ZXJ5OiBxdWVzdGlvbixcclxuICAgIGNyZWF0aXZpdHk6IGNvbmZpZy5jcmVhdGl2aXR5LFxyXG4gICAgcmVzb3VyY2VMaW1pdDogY29uZmlnLnJlc291cmNlTGltaXQsXHJcbiAgICBhZHZhbmNlZDoge1xyXG4gICAgICBleHByZXNzaW9uOiBjb25maWcuYWR2YW5jZWRGaWx0ZXJFeHByZXNzaW9uLFxyXG4gICAgfSxcclxuICAgIHN0cmVhbTogdHJ1ZSxcclxuICB9O1xyXG5cclxuICBjb25zdCBjb250ZXh0RWxlbWVudHM6IENvbnRleHRFbGVtZW50W10gPSBbXTtcclxuXHJcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBtZXNzYWdlcy5sZW5ndGggLSAxOyBpID0gaSArIDIpIHtcclxuICAgIGNvbnN0IHVzZXJNZXNzYWdlID0gbWVzc2FnZXNbaV07XHJcbiAgICBjb25zdCBib3RNZXNzYWdlID0gbWVzc2FnZXNbaSArIDFdO1xyXG4gICAgY29udGV4dEVsZW1lbnRzLnB1c2goe1xyXG4gICAgICB1c2VyOiB1c2VyTWVzc2FnZS50ZXh0LFxyXG4gICAgICBib3Q6IGJvdE1lc3NhZ2UudGV4dCxcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgaWYgKGNvbnRleHRFbGVtZW50cy5sZW5ndGggPiAwKSB7XHJcbiAgICBwYXlsb2FkLmNvbnRleHQgPSBjb250ZXh0RWxlbWVudHM7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gcGF5bG9hZDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQ2hhdFJlc3BvbnNlKFxyXG4gIHBheWxvYWQ6IENoYXRSZXF1ZXN0UGF5bG9hZCxcclxuICBvbk1lc3NhZ2U6IChtc2c6IEV2ZW50U291cmNlTWVzc2FnZSkgPT4gdm9pZFxyXG4pIHtcclxuICBjb25zdCBjdHJsID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG5cclxuICByZXR1cm4gZmV0Y2hFdmVudFNvdXJjZSgnL2FwaS9jaGF0L3N0cmVhbScsIHtcclxuICAgIHNpZ25hbDogY3RybC5zaWduYWwsXHJcbiAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgIGhlYWRlcnM6IHtcclxuICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgIH0sXHJcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwYXlsb2FkKSxcclxuICAgIGFzeW5jIG9ub3BlbihyZXNwb25zZSkge1xyXG4gICAgICBpZiAocmVzcG9uc2Uub2sgJiYgcmVzcG9uc2UuaGVhZGVycy5nZXQoJ2NvbnRlbnQtdHlwZScpID09PSBFdmVudFN0cmVhbUNvbnRlbnRUeXBlKSB7XHJcbiAgICAgICAgcmV0dXJuOyAvLyBldmVyeXRoaW5nJ3MgZ29vZFxyXG4gICAgICB9IGVsc2UgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDAgJiYgcmVzcG9uc2Uuc3RhdHVzIDwgNTAwICYmIHJlc3BvbnNlLnN0YXR1cyAhPT0gNDI5KSB7XHJcbiAgICAgICAgLy8gY2xpZW50LXNpZGUgZXJyb3JzIGFyZSB1c3VhbGx5IG5vbi1yZXRyaWFibGU6XHJcbiAgICAgICAgdGhyb3cgbmV3IEZhdGFsRXJyb3IoKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aHJvdyBuZXcgUmV0cmlhYmxlRXJyb3IoKTtcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIG9ubWVzc2FnZShtc2cpIHtcclxuICAgICAgLy8gaWYgdGhlIHNlcnZlciBlbWl0cyBhbiBlcnJvciBtZXNzYWdlLCB0aHJvdyBhbiBleGNlcHRpb25cclxuICAgICAgLy8gc28gaXQgZ2V0cyBoYW5kbGVkIGJ5IHRoZSBvbmVycm9yIGNhbGxiYWNrIGJlbG93OlxyXG4gICAgICBpZiAobXNnLmV2ZW50ID09PSAnRmF0YWxFcnJvcicpIHtcclxuICAgICAgICB0aHJvdyBuZXcgRmF0YWxFcnJvcihtc2cuZGF0YSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChtc2cuZXZlbnQgPT09ICdwYXJ0aWFsJyB8fCBtc2cuZXZlbnQgPT09ICdmaW5hbCcpIHtcclxuICAgICAgICBvbk1lc3NhZ2UobXNnKTtcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIG9uY2xvc2UoKSB7XHJcbiAgICAgIC8vIGlmIHRoZSBzZXJ2ZXIgY2xvc2VzIHRoZSBjb25uZWN0aW9uIHVuZXhwZWN0ZWRseSwgcmV0cnk6XHJcbiAgICAgIC8vIHRocm93IG5ldyBSZXRyaWFibGVFcnJvcigpO1xyXG4gICAgICBjdHJsLmFib3J0KCk7XHJcbiAgICB9LFxyXG4gICAgb25lcnJvcihlcnIpIHtcclxuICAgICAgdGhyb3cgZXJyO1xyXG4gICAgICAvLyBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgIC8vIGlmIChlcnIgaW5zdGFuY2VvZiBGYXRhbEVycm9yKSB7XHJcbiAgICAgIC8vICAgdGhyb3cgZXJyOyAvLyByZXRocm93IHRvIHN0b3AgdGhlIG9wZXJhdGlvblxyXG4gICAgICAvLyB9IGVsc2Uge1xyXG4gICAgICAvLyAgIGN0cmwuYWJvcnQoKTtcclxuICAgICAgLy8gICAvLyBkbyBub3RoaW5nIHRvIGF1dG9tYXRpY2FsbHkgcmV0cnkuIFlvdSBjYW4gYWxzb1xyXG4gICAgICAvLyAgIC8vIHJldHVybiBhIHNwZWNpZmljIHJldHJ5IGludGVydmFsIGhlcmUuXHJcbiAgICAgIC8vIH1cclxuICAgIH0sXHJcbiAgfSk7XHJcbn1cclxuIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsT0FFSztBQUVQLFNBQVMsMkJBQTJCO0FBRXBDLE1BQU0sdUJBQXVCLE1BQU07QUFBQztBQUNwQyxNQUFNLG1CQUFtQixNQUFNO0FBQUM7QUFFaEMsc0JBQXNCLGNBQWMsT0FBZTtBQUNqRCxRQUFNLFdBQVcsTUFBTSxNQUFNLGFBQWE7QUFBQSxJQUN4QyxRQUFRO0FBQUEsSUFDUixTQUFTO0FBQUEsTUFDUCxnQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLElBQ0EsTUFBTSxLQUFLLFVBQVUsRUFBRSxNQUFNLENBQUM7QUFBQSxFQUNoQyxDQUFDO0FBRUQsTUFBSSxDQUFDLFNBQVMsSUFBSTtBQUNoQixVQUFNLElBQUksTUFBTSx1QkFBdUI7QUFBQSxFQUN6QztBQUVBLFFBQU0sRUFBRSxRQUFRLFVBQVUsSUFBSSxNQUFNLFNBQVMsS0FBSztBQUNsRCxTQUFPLEVBQUUsUUFBUSxVQUFVO0FBQzdCO0FBRUEsc0JBQXNCLGdCQUFnQixRQUFnQixTQUFpQjtBQUNyRSxRQUFNLFdBQVcsTUFBTSxNQUFNLGFBQWE7QUFBQSxJQUN4QyxRQUFRO0FBQUEsSUFDUixTQUFTO0FBQUEsTUFDUCxnQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLElBQ0EsTUFBTSxLQUFLLFVBQVU7QUFBQSxNQUNuQixRQUFRO0FBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILENBQUM7QUFFRCxNQUFJLENBQUMsU0FBUyxJQUFJO0FBQ2hCLFVBQU0sSUFBSSxNQUFNLDZCQUE2QjtBQUFBLEVBQy9DO0FBQ0Y7QUFFQSxzQkFBc0IsZUFBa0IsUUFBZ0IsTUFBYyxXQUFnQjtBQUNwRixRQUFNLFdBQVcsTUFBTSxNQUFNLGFBQWE7QUFBQSxJQUN4QyxRQUFRO0FBQUEsSUFDUixTQUFTO0FBQUEsTUFDUCxnQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLElBQ0EsTUFBTSxLQUFLLFVBQVU7QUFBQSxNQUNuQixRQUFRO0FBQUEsTUFDUjtBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1Q7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILENBQUM7QUFFRCxNQUFJLENBQUMsU0FBUyxJQUFJO0FBQ2hCLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtBQUFBLEVBQzlDO0FBRUEsUUFBTSxVQUFXLE1BQU0sU0FBUyxLQUFLO0FBQ3JDLFNBQU8sb0JBQW9CLE9BQU87QUFDcEM7QUFFQSxzQkFBc0IsYUFBYSxRQUFnQixXQUFtQixRQUFnQjtBQUNwRixRQUFNLFdBQVcsTUFBTSxNQUFNLGFBQWE7QUFBQSxJQUN4QyxRQUFRO0FBQUEsSUFDUixTQUFTO0FBQUEsTUFDUCxnQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLElBQ0EsTUFBTSxLQUFLLFVBQVU7QUFBQSxNQUNuQixRQUFRO0FBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxDQUFDO0FBRUQsTUFBSSxDQUFDLFNBQVMsSUFBSTtBQUNoQixVQUFNLElBQUksTUFBTSwyQkFBMkI7QUFBQSxFQUM3QztBQUNGO0FBRUEsc0JBQXNCLGFBQWEsUUFBZ0IsV0FBbUIsUUFBZ0I7QUFDcEYsUUFBTSxXQUFXLE1BQU0sTUFBTSxhQUFhO0FBQUEsSUFDeEMsUUFBUTtBQUFBLElBQ1IsU0FBUztBQUFBLE1BQ1AsZ0JBQWdCO0FBQUEsSUFDbEI7QUFBQSxJQUNBLE1BQU0sS0FBSyxVQUFVO0FBQUEsTUFDbkIsUUFBUTtBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsQ0FBQztBQUVELE1BQUksQ0FBQyxTQUFTLElBQUk7QUFDaEIsVUFBTSxJQUFJLE1BQU0sMkJBQTJCO0FBQUEsRUFDN0M7QUFDRjtBQUVBLHNCQUFzQixjQUFjLFFBQWdCLE9BQWUsV0FBbUI7QUFDcEYsUUFBTSxXQUFXLE1BQU0sTUFBTSxhQUFhO0FBQUEsSUFDeEMsUUFBUTtBQUFBLElBQ1IsU0FBUztBQUFBLE1BQ1AsZ0JBQWdCO0FBQUEsSUFDbEI7QUFBQSxJQUNBLE1BQU0sS0FBSyxVQUFVO0FBQUEsTUFDbkI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsQ0FBQztBQUVELE1BQUksQ0FBQyxTQUFTLElBQUk7QUFDaEIsVUFBTSxJQUFJLE1BQU0sNkJBQTZCO0FBQUEsRUFDL0M7QUFDRjtBQUVPLGdCQUFTLGNBQ2QsUUFDQSxVQUNBLFVBQ29CO0FBQ3BCLFFBQU0sVUFBOEI7QUFBQSxJQUNsQyxPQUFPO0FBQUEsSUFDUCxZQUFZLE9BQU87QUFBQSxJQUNuQixlQUFlLE9BQU87QUFBQSxJQUN0QixVQUFVO0FBQUEsTUFDUixZQUFZLE9BQU87QUFBQSxJQUNyQjtBQUFBLElBQ0EsUUFBUTtBQUFBLEVBQ1Y7QUFFQSxRQUFNLGtCQUFvQyxDQUFDO0FBRTNDLFdBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxTQUFTLEdBQUcsSUFBSSxJQUFJLEdBQUc7QUFDbEQsVUFBTSxjQUFjLFNBQVMsQ0FBQztBQUM5QixVQUFNLGFBQWEsU0FBUyxJQUFJLENBQUM7QUFDakMsb0JBQWdCLEtBQUs7QUFBQSxNQUNuQixNQUFNLFlBQVk7QUFBQSxNQUNsQixLQUFLLFdBQVc7QUFBQSxJQUNsQixDQUFDO0FBQUEsRUFDSDtBQUVBLE1BQUksZ0JBQWdCLFNBQVMsR0FBRztBQUM5QixZQUFRLFVBQVU7QUFBQSxFQUNwQjtBQUVBLFNBQU87QUFDVDtBQUVBLHNCQUFzQixrQkFDcEIsU0FDQSxXQUNBO0FBQ0EsUUFBTSxPQUFPLElBQUksZ0JBQWdCO0FBRWpDLFNBQU8saUJBQWlCLG9CQUFvQjtBQUFBLElBQzFDLFFBQVEsS0FBSztBQUFBLElBQ2IsUUFBUTtBQUFBLElBQ1IsU0FBUztBQUFBLE1BQ1AsZ0JBQWdCO0FBQUEsSUFDbEI7QUFBQSxJQUNBLE1BQU0sS0FBSyxVQUFVLE9BQU87QUFBQSxJQUM1QixNQUFNLE9BQU8sVUFBVTtBQUNyQixVQUFJLFNBQVMsTUFBTSxTQUFTLFFBQVEsSUFBSSxjQUFjLE1BQU0sd0JBQXdCO0FBQ2xGO0FBQUEsTUFDRixXQUFXLFNBQVMsVUFBVSxPQUFPLFNBQVMsU0FBUyxPQUFPLFNBQVMsV0FBVyxLQUFLO0FBRXJGLGNBQU0sSUFBSSxXQUFXO0FBQUEsTUFDdkIsT0FBTztBQUNMLGNBQU0sSUFBSSxlQUFlO0FBQUEsTUFDM0I7QUFBQSxJQUNGO0FBQUEsSUFDQSxVQUFVLEtBQUs7QUFHYixVQUFJLElBQUksVUFBVSxjQUFjO0FBQzlCLGNBQU0sSUFBSSxXQUFXLElBQUksSUFBSTtBQUFBLE1BQy9CO0FBRUEsVUFBSSxJQUFJLFVBQVUsYUFBYSxJQUFJLFVBQVUsU0FBUztBQUNwRCxrQkFBVSxHQUFHO0FBQUEsTUFDZjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFVBQVU7QUFHUixXQUFLLE1BQU07QUFBQSxJQUNiO0FBQUEsSUFDQSxRQUFRLEtBQUs7QUFDWCxZQUFNO0FBQUEsSUFTUjtBQUFBLEVBQ0YsQ0FBQztBQUNIOyIsIm5hbWVzIjpbXX0=