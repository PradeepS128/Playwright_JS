import { BROWSER, DEV } from "/node_modules/.vite/deps/esm-env.js?v=b331fb12";
export { building, version } from "/@id/__x00__virtual:__sveltekit/environment";

/**
 * `true` if the app is running in the browser.
 */
export const browser = BROWSER;

/**
 * Whether the dev server is running. This is not guaranteed to correspond to `NODE_ENV` or `MODE`.
 */
export const dev = DEV;
