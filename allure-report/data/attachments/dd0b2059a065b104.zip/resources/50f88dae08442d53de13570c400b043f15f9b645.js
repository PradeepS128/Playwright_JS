export const base = globalThis.__sveltekit_dev?.base ?? "";
export const assets = globalThis.__sveltekit_dev?.assets ?? base;