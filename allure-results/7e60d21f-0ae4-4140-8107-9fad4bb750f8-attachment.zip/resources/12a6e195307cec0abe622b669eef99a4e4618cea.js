import {
  PUBLIC_VERSION
} from "/node_modules/.vite/deps/chunk-NPGCKOZ3.js?v=b331fb12";
import "/node_modules/.vite/deps/chunk-V3OIBNHJ.js?v=b331fb12";

// ../../node_modules/.pnpm/svelte@4.2.7/node_modules/svelte/src/runtime/internal/disclose-version/index.js
if (typeof window !== "undefined")
  (window.__svelte || (window.__svelte = { v: /* @__PURE__ */ new Set() })).v.add(PUBLIC_VERSION);
//# sourceMappingURL=svelte_internal_disclose-version.js.map
