import { get } from "/node_modules/.vite/deps/svelte_store.js?v=b331fb12";
import {
  createNewChat,
  createPayload,
  fetchChatResponse,
  saveBotMessage,
  saveUserMessage
} from "/@fs/C:/Users/Pradeep/Desktop/fibonalabs_app_pdf/packages/shared/src/lib/services/chat-service-helpers.ts";
async function onCompletedStream(chatStore) {
  const { chatId, currentBotMessage, currentUserMessage } = get(chatStore);
  if (!chatId || !currentBotMessage || !currentUserMessage) {
    return;
  }
  const botMessage = await saveBotMessage(
    chatId,
    currentBotMessage.text,
    currentBotMessage.resources
  );
  chatStore.addUserMessage(currentUserMessage);
  chatStore.addBotMessage(botMessage);
  chatStore.clearCurrentMessages();
  chatStore.updateBotMessageCompletionState("COMPLETED");
}
function initMessages(chatStore, question) {
  chatStore.updateCurrentUserMessage({
    type: "user",
    text: question,
    timestamp: -1
  });
  chatStore.updateCurrentBotMessage({
    type: "bot",
    text: "Generating...",
    completionState: "IN_PROGRESS",
    resources: [],
    rating: 0,
    timestamp: -1,
    review: ""
  });
}
async function onFirstQuestion(chatStore, question) {
  chatStore.updateChatTitle(question);
  const { chatId, timestamp } = await createNewChat(question);
  chatStore.updateChatId(chatId);
  chatStore.updateCreatedOn(timestamp);
  window.history.replaceState(history.state, "", `/chat/${chatId}`);
}
export const chatService = function() {
  function createInstance(chatStore) {
    return {
      askQuestion: async function(options) {
        const { chatId } = get(chatStore);
        const { chatConfig, question, onError } = options;
        initMessages(chatStore, question);
        try {
          if (!chatId) {
            onFirstQuestion(chatStore, question);
          } else {
            saveUserMessage(chatId, question);
          }
        } catch (err) {
          console.error(err);
          if (err instanceof Error) {
            onError(err);
          } else {
            onError(new Error("An unknown error occurred"));
          }
        }
        const { messages } = get(chatStore);
        const payload = createPayload(chatConfig, question, messages);
        fetchChatResponse(payload, (msg) => {
          const data = JSON.parse(msg.data);
          if (msg.event === "partial") {
            if (data.context) {
              if (data.context.bot.length > 0) {
                chatStore.updateBotMessageText(data.context.bot);
              }
            } else {
              chatStore.updateBotMessageResources(data.resources);
            }
          } else if (msg.event === "final") {
            if (data.context) {
              chatStore.updateBotMessageText(data.context.bot);
            }
            onCompletedStream(chatStore).catch((err) => {
              console.error(err);
              onError(err);
            });
          }
        }).catch((err) => {
          console.error(err);
          onError(err);
        });
      }
    };
  }
  return {
    createInstance
  };
}();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYXQtc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXQgfSBmcm9tICdzdmVsdGUvc3RvcmUnO1xyXG5pbXBvcnQgdHlwZSB7IENoYXRDb25maWcsIEV2ZW50RGF0YSB9IGZyb20gJ3R5cGVzJztcclxuaW1wb3J0IHR5cGUgeyBDaGF0U3RvcmUgfSBmcm9tICcuLi9zdG9yZXMnO1xyXG5pbXBvcnQge1xyXG4gIGNyZWF0ZU5ld0NoYXQsXHJcbiAgY3JlYXRlUGF5bG9hZCxcclxuICBmZXRjaENoYXRSZXNwb25zZSxcclxuICBzYXZlQm90TWVzc2FnZSxcclxuICBzYXZlVXNlck1lc3NhZ2UsXHJcbn0gZnJvbSAnLi9jaGF0LXNlcnZpY2UtaGVscGVycyc7XHJcblxyXG5pbnRlcmZhY2UgUXVlc3Rpb25PcHRpb25zIHtcclxuICBjaGF0Q29uZmlnOiBDaGF0Q29uZmlnO1xyXG4gIHF1ZXN0aW9uOiBzdHJpbmc7XHJcbiAgb25FcnJvcjogKGVycjogRXJyb3IpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmludGVyZmFjZSBDaGF0U2VydmljZSB7XHJcbiAgYXNrUXVlc3Rpb246IChvcHRpb25zOiBRdWVzdGlvbk9wdGlvbnMpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIG9uQ29tcGxldGVkU3RyZWFtPFQ+KGNoYXRTdG9yZTogQ2hhdFN0b3JlPFQ+KSB7XHJcbiAgY29uc3QgeyBjaGF0SWQsIGN1cnJlbnRCb3RNZXNzYWdlLCBjdXJyZW50VXNlck1lc3NhZ2UgfSA9IGdldChjaGF0U3RvcmUpO1xyXG5cclxuICBpZiAoIWNoYXRJZCB8fCAhY3VycmVudEJvdE1lc3NhZ2UgfHwgIWN1cnJlbnRVc2VyTWVzc2FnZSkge1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBjb25zdCBib3RNZXNzYWdlID0gYXdhaXQgc2F2ZUJvdE1lc3NhZ2UoXHJcbiAgICBjaGF0SWQsXHJcbiAgICBjdXJyZW50Qm90TWVzc2FnZS50ZXh0LFxyXG4gICAgY3VycmVudEJvdE1lc3NhZ2UucmVzb3VyY2VzXHJcbiAgKTtcclxuICBjaGF0U3RvcmUuYWRkVXNlck1lc3NhZ2UoY3VycmVudFVzZXJNZXNzYWdlKTtcclxuICBjaGF0U3RvcmUuYWRkQm90TWVzc2FnZShib3RNZXNzYWdlKTtcclxuICBjaGF0U3RvcmUuY2xlYXJDdXJyZW50TWVzc2FnZXMoKTtcclxuICBjaGF0U3RvcmUudXBkYXRlQm90TWVzc2FnZUNvbXBsZXRpb25TdGF0ZSgnQ09NUExFVEVEJyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGluaXRNZXNzYWdlczxUPihjaGF0U3RvcmU6IENoYXRTdG9yZTxUPiwgcXVlc3Rpb246IHN0cmluZykge1xyXG4gIGNoYXRTdG9yZS51cGRhdGVDdXJyZW50VXNlck1lc3NhZ2Uoe1xyXG4gICAgdHlwZTogJ3VzZXInLFxyXG4gICAgdGV4dDogcXVlc3Rpb24sXHJcbiAgICB0aW1lc3RhbXA6IC0xLFxyXG4gIH0pO1xyXG5cclxuICBjaGF0U3RvcmUudXBkYXRlQ3VycmVudEJvdE1lc3NhZ2Uoe1xyXG4gICAgdHlwZTogJ2JvdCcsXHJcbiAgICB0ZXh0OiAnR2VuZXJhdGluZy4uLicsXHJcbiAgICBjb21wbGV0aW9uU3RhdGU6ICdJTl9QUk9HUkVTUycsXHJcbiAgICByZXNvdXJjZXM6IFtdLFxyXG4gICAgcmF0aW5nOiAwLFxyXG4gICAgdGltZXN0YW1wOiAtMSxcclxuICAgIHJldmlldzogJycsXHJcbiAgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIG9uRmlyc3RRdWVzdGlvbjxUPihjaGF0U3RvcmU6IENoYXRTdG9yZTxUPiwgcXVlc3Rpb246IHN0cmluZykge1xyXG4gIGNoYXRTdG9yZS51cGRhdGVDaGF0VGl0bGUocXVlc3Rpb24pO1xyXG4gIGNvbnN0IHsgY2hhdElkLCB0aW1lc3RhbXAgfSA9IGF3YWl0IGNyZWF0ZU5ld0NoYXQocXVlc3Rpb24pO1xyXG4gIGNoYXRTdG9yZS51cGRhdGVDaGF0SWQoY2hhdElkKTtcclxuICBjaGF0U3RvcmUudXBkYXRlQ3JlYXRlZE9uKHRpbWVzdGFtcCk7XHJcbiAgd2luZG93Lmhpc3RvcnkucmVwbGFjZVN0YXRlKGhpc3Rvcnkuc3RhdGUsICcnLCBgL2NoYXQvJHtjaGF0SWR9YCk7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBjaGF0U2VydmljZSA9IChmdW5jdGlvbiAoKSB7XHJcbiAgZnVuY3Rpb24gY3JlYXRlSW5zdGFuY2U8VD4oY2hhdFN0b3JlOiBDaGF0U3RvcmU8VD4pOiBDaGF0U2VydmljZSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBhc2tRdWVzdGlvbjogYXN5bmMgZnVuY3Rpb24gKG9wdGlvbnM6IFF1ZXN0aW9uT3B0aW9ucykge1xyXG4gICAgICAgIGNvbnN0IHsgY2hhdElkIH0gPSBnZXQoY2hhdFN0b3JlKTtcclxuICAgICAgICBjb25zdCB7IGNoYXRDb25maWcsIHF1ZXN0aW9uLCBvbkVycm9yIH0gPSBvcHRpb25zO1xyXG4gICAgICAgIGluaXRNZXNzYWdlcyhjaGF0U3RvcmUsIHF1ZXN0aW9uKTtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGlmICghY2hhdElkKSB7XHJcbiAgICAgICAgICAgIG9uRmlyc3RRdWVzdGlvbihjaGF0U3RvcmUsIHF1ZXN0aW9uKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHNhdmVVc2VyTWVzc2FnZShjaGF0SWQsIHF1ZXN0aW9uKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgICAgICAgICBvbkVycm9yKGVycik7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBvbkVycm9yKG5ldyBFcnJvcignQW4gdW5rbm93biBlcnJvciBvY2N1cnJlZCcpKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHsgbWVzc2FnZXMgfSA9IGdldChjaGF0U3RvcmUpO1xyXG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSBjcmVhdGVQYXlsb2FkKGNoYXRDb25maWcsIHF1ZXN0aW9uLCBtZXNzYWdlcyk7XHJcblxyXG4gICAgICAgIGZldGNoQ2hhdFJlc3BvbnNlKHBheWxvYWQsIChtc2cpID0+IHtcclxuICAgICAgICAgIGNvbnN0IGRhdGEgPSBKU09OLnBhcnNlKG1zZy5kYXRhKSBhcyBFdmVudERhdGE8VD47XHJcbiAgICAgICAgICBpZiAobXNnLmV2ZW50ID09PSAncGFydGlhbCcpIHtcclxuICAgICAgICAgICAgaWYgKGRhdGEuY29udGV4dCkge1xyXG4gICAgICAgICAgICAgIGlmIChkYXRhLmNvbnRleHQuYm90Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIGNoYXRTdG9yZS51cGRhdGVCb3RNZXNzYWdlVGV4dChkYXRhLmNvbnRleHQuYm90KTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgY2hhdFN0b3JlLnVwZGF0ZUJvdE1lc3NhZ2VSZXNvdXJjZXMoZGF0YS5yZXNvdXJjZXMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9IGVsc2UgaWYgKG1zZy5ldmVudCA9PT0gJ2ZpbmFsJykge1xyXG4gICAgICAgICAgICBpZiAoZGF0YS5jb250ZXh0KSB7XHJcbiAgICAgICAgICAgICAgY2hhdFN0b3JlLnVwZGF0ZUJvdE1lc3NhZ2VUZXh0KGRhdGEuY29udGV4dC5ib3QpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9uQ29tcGxldGVkU3RyZWFtKGNoYXRTdG9yZSkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgICBvbkVycm9yKGVycik7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgIG9uRXJyb3IoZXJyKTtcclxuICAgICAgICB9KTtcclxuICAgICAgfSxcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgY3JlYXRlSW5zdGFuY2UsXHJcbiAgfTtcclxufSkoKTtcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFdBQVc7QUFHcEI7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFZUCxlQUFlLGtCQUFxQixXQUF5QjtBQUMzRCxRQUFNLEVBQUUsUUFBUSxtQkFBbUIsbUJBQW1CLElBQUksSUFBSSxTQUFTO0FBRXZFLE1BQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsb0JBQW9CO0FBQ3hEO0FBQUEsRUFDRjtBQUNBLFFBQU0sYUFBYSxNQUFNO0FBQUEsSUFDdkI7QUFBQSxJQUNBLGtCQUFrQjtBQUFBLElBQ2xCLGtCQUFrQjtBQUFBLEVBQ3BCO0FBQ0EsWUFBVSxlQUFlLGtCQUFrQjtBQUMzQyxZQUFVLGNBQWMsVUFBVTtBQUNsQyxZQUFVLHFCQUFxQjtBQUMvQixZQUFVLGdDQUFnQyxXQUFXO0FBQ3ZEO0FBRUEsU0FBUyxhQUFnQixXQUF5QixVQUFrQjtBQUNsRSxZQUFVLHlCQUF5QjtBQUFBLElBQ2pDLE1BQU07QUFBQSxJQUNOLE1BQU07QUFBQSxJQUNOLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFFRCxZQUFVLHdCQUF3QjtBQUFBLElBQ2hDLE1BQU07QUFBQSxJQUNOLE1BQU07QUFBQSxJQUNOLGlCQUFpQjtBQUFBLElBQ2pCLFdBQVcsQ0FBQztBQUFBLElBQ1osUUFBUTtBQUFBLElBQ1IsV0FBVztBQUFBLElBQ1gsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNIO0FBRUEsZUFBZSxnQkFBbUIsV0FBeUIsVUFBa0I7QUFDM0UsWUFBVSxnQkFBZ0IsUUFBUTtBQUNsQyxRQUFNLEVBQUUsUUFBUSxVQUFVLElBQUksTUFBTSxjQUFjLFFBQVE7QUFDMUQsWUFBVSxhQUFhLE1BQU07QUFDN0IsWUFBVSxnQkFBZ0IsU0FBUztBQUNuQyxTQUFPLFFBQVEsYUFBYSxRQUFRLE9BQU8sSUFBSSxTQUFTLE1BQU0sRUFBRTtBQUNsRTtBQUVPLGFBQU0sY0FBZSxXQUFZO0FBQ3RDLFdBQVMsZUFBa0IsV0FBc0M7QUFDL0QsV0FBTztBQUFBLE1BQ0wsYUFBYSxlQUFnQixTQUEwQjtBQUNyRCxjQUFNLEVBQUUsT0FBTyxJQUFJLElBQUksU0FBUztBQUNoQyxjQUFNLEVBQUUsWUFBWSxVQUFVLFFBQVEsSUFBSTtBQUMxQyxxQkFBYSxXQUFXLFFBQVE7QUFFaEMsWUFBSTtBQUNGLGNBQUksQ0FBQyxRQUFRO0FBQ1gsNEJBQWdCLFdBQVcsUUFBUTtBQUFBLFVBQ3JDLE9BQU87QUFDTCw0QkFBZ0IsUUFBUSxRQUFRO0FBQUEsVUFDbEM7QUFBQSxRQUNGLFNBQVMsS0FBSztBQUNaLGtCQUFRLE1BQU0sR0FBRztBQUNqQixjQUFJLGVBQWUsT0FBTztBQUN4QixvQkFBUSxHQUFHO0FBQUEsVUFDYixPQUFPO0FBQ0wsb0JBQVEsSUFBSSxNQUFNLDJCQUEyQixDQUFDO0FBQUEsVUFDaEQ7QUFBQSxRQUNGO0FBRUEsY0FBTSxFQUFFLFNBQVMsSUFBSSxJQUFJLFNBQVM7QUFDbEMsY0FBTSxVQUFVLGNBQWMsWUFBWSxVQUFVLFFBQVE7QUFFNUQsMEJBQWtCLFNBQVMsQ0FBQyxRQUFRO0FBQ2xDLGdCQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksSUFBSTtBQUNoQyxjQUFJLElBQUksVUFBVSxXQUFXO0FBQzNCLGdCQUFJLEtBQUssU0FBUztBQUNoQixrQkFBSSxLQUFLLFFBQVEsSUFBSSxTQUFTLEdBQUc7QUFDL0IsMEJBQVUscUJBQXFCLEtBQUssUUFBUSxHQUFHO0FBQUEsY0FDakQ7QUFBQSxZQUNGLE9BQU87QUFDTCx3QkFBVSwwQkFBMEIsS0FBSyxTQUFTO0FBQUEsWUFDcEQ7QUFBQSxVQUNGLFdBQVcsSUFBSSxVQUFVLFNBQVM7QUFDaEMsZ0JBQUksS0FBSyxTQUFTO0FBQ2hCLHdCQUFVLHFCQUFxQixLQUFLLFFBQVEsR0FBRztBQUFBLFlBQ2pEO0FBQ0EsOEJBQWtCLFNBQVMsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUMxQyxzQkFBUSxNQUFNLEdBQUc7QUFDakIsc0JBQVEsR0FBRztBQUFBLFlBQ2IsQ0FBQztBQUFBLFVBQ0g7QUFBQSxRQUNGLENBQUMsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNoQixrQkFBUSxNQUFNLEdBQUc7QUFDakIsa0JBQVEsR0FBRztBQUFBLFFBQ2IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFNBQU87QUFBQSxJQUNMO0FBQUEsRUFDRjtBQUNGLEVBQUc7IiwibmFtZXMiOltdfQ==