import { LoginError } from "/@fs/C:/Users/Pradeep/Desktop/fibonalabs_app_pdf/packages/types/index.ts";
export async function login(username, password) {
  try {
    const response = await fetch("/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ username, password })
    });
    if (!response.ok) {
      let errorMessage = "Login failed with status " + response.status;
      try {
        const responseBody = await response.json();
        if (responseBody && responseBody.message) {
          errorMessage = responseBody.message;
        }
      } catch (e) {
        console.error("Error parsing response JSON:", e);
      }
      throw new LoginError(response.status, errorMessage);
    }
    return response;
  } catch (error) {
    if (error instanceof LoginError) {
      throw error;
    } else {
      throw new Error("An unexpected error occurred during login.");
    }
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGgtc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMb2dpbkVycm9yIH0gZnJvbSAndHlwZXMnO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvZ2luKHVzZXJuYW1lOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCgnL2FwaS9sb2dpbicsIHtcclxuICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICB9LFxyXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHVzZXJuYW1lLCBwYXNzd29yZCB9KSxcclxuICAgIH0pO1xyXG5cclxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgbGV0IGVycm9yTWVzc2FnZSA9ICdMb2dpbiBmYWlsZWQgd2l0aCBzdGF0dXMgJyArIHJlc3BvbnNlLnN0YXR1cztcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBBdHRlbXB0IHRvIHBhcnNlIEpTT04gZXJyb3IgbWVzc2FnZVxyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlQm9keSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgICBpZiAocmVzcG9uc2VCb2R5ICYmIHJlc3BvbnNlQm9keS5tZXNzYWdlKSB7XHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2UgPSByZXNwb25zZUJvZHkubWVzc2FnZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAvLyBJZiByZXNwb25zZSBpcyBub3QgSlNPTiwgb3IgY2FuJ3QgYmUgcGFyc2VkLCBsb2cgdGhlIGVycm9yXHJcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgcGFyc2luZyByZXNwb25zZSBKU09OOicsIGUpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBUaHJvdyBhIGN1c3RvbSBlcnJvciB3aXRoIHRoZSBzdGF0dXMgY29kZVxyXG4gICAgICB0aHJvdyBuZXcgTG9naW5FcnJvcihyZXNwb25zZS5zdGF0dXMsIGVycm9yTWVzc2FnZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBMb2dpbkVycm9yKSB7XHJcbiAgICAgIC8vIFJlLXRocm93IGN1c3RvbSBlcnJvcnNcclxuICAgICAgdGhyb3cgZXJyb3I7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBGb3IgbmV0d29yayBlcnJvcnMgb3Igb3RoZXIgdW5leHBlY3RlZCBpc3N1ZXMsIHRocm93IGEgZ2VuZXJhbCBlcnJvclxyXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0FuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQgZHVyaW5nIGxvZ2luLicpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsa0JBQWtCO0FBRTNCLHNCQUFzQixNQUFNLFVBQWtCLFVBQWtCO0FBQzlELE1BQUk7QUFDRixVQUFNLFdBQVcsTUFBTSxNQUFNLGNBQWM7QUFBQSxNQUN6QyxRQUFRO0FBQUEsTUFDUixTQUFTO0FBQUEsUUFDUCxnQkFBZ0I7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsTUFBTSxLQUFLLFVBQVUsRUFBRSxVQUFVLFNBQVMsQ0FBQztBQUFBLElBQzdDLENBQUM7QUFFRCxRQUFJLENBQUMsU0FBUyxJQUFJO0FBQ2hCLFVBQUksZUFBZSw4QkFBOEIsU0FBUztBQUMxRCxVQUFJO0FBRUYsY0FBTSxlQUFlLE1BQU0sU0FBUyxLQUFLO0FBQ3pDLFlBQUksZ0JBQWdCLGFBQWEsU0FBUztBQUN4Qyx5QkFBZSxhQUFhO0FBQUEsUUFDOUI7QUFBQSxNQUNGLFNBQVMsR0FBRztBQUVWLGdCQUFRLE1BQU0sZ0NBQWdDLENBQUM7QUFBQSxNQUNqRDtBQUdBLFlBQU0sSUFBSSxXQUFXLFNBQVMsUUFBUSxZQUFZO0FBQUEsSUFDcEQ7QUFFQSxXQUFPO0FBQUEsRUFDVCxTQUFTLE9BQU87QUFDZCxRQUFJLGlCQUFpQixZQUFZO0FBRS9CLFlBQU07QUFBQSxJQUNSLE9BQU87QUFFTCxZQUFNLElBQUksTUFBTSw0Q0FBNEM7QUFBQSxJQUM5RDtBQUFBLEVBQ0Y7QUFDRjsiLCJuYW1lcyI6W119